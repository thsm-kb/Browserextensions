/*
 * Browsertrix Crawl Log Viewer - raw log search worker
 *
 * Runs searches off the main thread so a slow regular expression cannot freeze
 * the viewer. The log arrives as a Blob (for a local file: the file itself, so
 * nothing is copied up front) and is read into the worker's own LineStore, so
 * no single giant string is ever built here either.
 *
 * Work is time-sliced: between slices the worker yields, which lets a newer
 * search request supersede the running one. It posts progress after every
 * slice; the page treats a long silence as a stuck regex (catastrophic
 * backtracking on a single line) and terminates the worker.
 */
importScripts("line-store.js", "raw-search-core.js");

const { compile, createSearch } = self.BTLV_RAW_SEARCH;
const { LineStore, storeFromBlob } = self.BTLV_LINES;

let store = new LineStore();
let ready = Promise.resolve();
let activeId = 0;

function yieldToMessages() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

async function runSearch({ id, query, regex, caseSensitive }) {
  activeId = id;
  await ready;
  if (activeId !== id) return;
  const { re, error } = compile(query, { regex, caseSensitive });
  if (!re) {
    self.postMessage({ type: "result", id, error, empty: !error });
    return;
  }

  const lines = store;
  const search = createSearch(lines.length, i => lines.getLine(i), re);
  while (!search.step(40)) {
    self.postMessage({ type: "progress", id, progress: search.progress() });
    await yieldToMessages();
    if (activeId !== id) return; // superseded by a newer request
  }

  const result = search.result();
  self.postMessage(
    { type: "result", id, ...result },
    [result.lineHits.buffer, result.matchLine.buffer, result.matchStart.buffer, result.matchEnd.buffer]
  );
}

self.onmessage = event => {
  const message = event.data || {};
  if (message.type === "load") {
    activeId = 0;
    store = new LineStore();
    const total = message.blob?.size || 0;
    let lastPost = 0;
    const onProgress = bytes => {
      const now = Date.now();
      if (now - lastPost < 250) return;
      lastPost = now;
      self.postMessage({ type: "loading", progress: total ? bytes / total : 0 });
    };
    ready = (message.blob ? storeFromBlob(message.blob, onProgress) : Promise.resolve(new LineStore()))
      .then(loaded => {
        store = loaded;
        // Heartbeat: the page counts this as progress, not as a stuck search.
        self.postMessage({ type: "loaded", lineCount: loaded.length });
      });
  } else if (message.type === "search") {
    runSearch(message).catch(error => {
      self.postMessage({ type: "result", id: message.id, error: String(error?.message || error) });
    });
  } else if (message.type === "cancel") {
    activeId = 0;
  }
};
