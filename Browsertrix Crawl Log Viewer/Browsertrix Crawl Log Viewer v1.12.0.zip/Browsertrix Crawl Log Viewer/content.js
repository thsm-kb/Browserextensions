(() => {
  // content.js is registered per Browsertrix address and may also be injected
  // into already-open tabs when an address is added; run only once per page.
  if (globalThis.__btlvContentScriptActive) return;
  globalThis.__btlvContentScriptActive = true;

  const LOG_PATH_RE = /^\/api\/orgs\/[^/]+\/crawls\/[^/]+\/logs$/;

  function getAttr(el, name) {
    if (!el || typeof el.getAttribute !== "function") return null;
    return el.getAttribute(name);
  }

  function candidateFromEvent(event) {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [];

    for (const node of path) {
      if (!(node instanceof Element)) continue;

      const href = getAttr(node, "href") || node.href;
      if (!href) continue;

      let url;
      try {
        url = new URL(href, location.href);
      } catch {
        continue;
      }

      if (url.origin !== location.origin) continue;
      if (!LOG_PATH_RE.test(url.pathname)) continue;
      if (!url.searchParams.has("auth_bearer")) continue;

      const filename =
        getAttr(node, "download") ||
        path.map(n => getAttr(n, "download")).find(Boolean) ||
        `browsertrix-${url.pathname.split("/").at(-2) || "crawl"}-logs.log`;

      return { url: url.href, filename };
    }

    // Fallback for clicks on descendants where the composed path does not
    // expose the href-bearing node as expected.
    const target = event.target instanceof Element ? event.target : null;
    const host = target?.closest?.('sl-button[download][href*="/crawls/"][href*="/logs"]');
    if (host) {
      const href = host.getAttribute("href");
      let url = null;
      try {
        url = href ? new URL(href, location.href) : null;
      } catch {
        url = null;
      }
      if (url) {
        if (url.origin === location.origin && LOG_PATH_RE.test(url.pathname) && url.searchParams.has("auth_bearer")) {
          return {
            url: url.href,
            filename: host.getAttribute("download") || "browsertrix-logs.log"
          };
        }
      }
    }

    return null;
  }

  // Fail CLOSED. If the viewer cannot be opened, nothing is downloaded: a
  // normal download would store the signed link (with its auth_bearer token)
  // in Chrome's download history. The user gets a short notice instead. The
  // notice never contains the link, and nothing is logged to the console.
  function showNotice(text) {
    try {
      const host = document.createElement("div");
      host.setAttribute("data-btlv-notice", "");
      const shadow = host.attachShadow({ mode: "closed" });
      const box = document.createElement("div");
      box.setAttribute("role", "alert");
      box.textContent = text;
      box.style.cssText = [
        "position:fixed", "right:16px", "bottom:16px", "z-index:2147483647", "max-width:420px",
        "padding:12px 14px", "border-radius:8px", "background:#17263a", "color:#fff",
        "font:13px/1.45 system-ui,sans-serif", "box-shadow:0 6px 24px rgba(0,0,0,.25)"
      ].join(";");
      shadow.appendChild(box);
      (document.body || document.documentElement).appendChild(host);
      setTimeout(() => host.remove(), 9000);
    } catch (_) { /* nothing else to do; never fall back to a download */ }
  }

  const FAIL_TEXT = "Browsertrix Crawl Log Viewer could not open this log, so nothing was downloaded.";

  window.addEventListener("click", event => {
    if (event.button !== 0 || event.defaultPrevented) return;

    let candidate = candidateFromEvent(event);
    if (!candidate) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    // After the extension is reloaded or updated, scripts left in open tabs
    // lose their connection to it.
    if (!globalThis.chrome?.runtime?.id) {
      candidate = null;
      showNotice(`${FAIL_TEXT} The extension was updated or reloaded: reload this page and click Download Logs again.`);
      return;
    }

    let message = { type: "OPEN_BROWSERTRIX_LOG", url: candidate.url, filename: candidate.filename };
    candidate = null;
    chrome.runtime.sendMessage(message).then(response => {
      if (!response?.ok) {
        showNotice(`${FAIL_TEXT} ${response?.error || "Check the address in the extension’s Settings."}`);
      }
    }).catch(() => {
      showNotice(`${FAIL_TEXT} Reload this page and try again.`);
    });
    message = null;
  }, true);
})();
