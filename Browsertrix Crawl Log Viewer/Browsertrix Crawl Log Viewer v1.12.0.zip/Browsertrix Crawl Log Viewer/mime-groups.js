/*
 * Browsertrix Crawl Log Viewer - MIME grouping helpers
 *
 * MIME names and top-level families follow the IANA Media Types registry:
 * https://www.iana.org/assignments/media-types/media-types.xhtml
 * https://www.iana.org/assignments/top-level-media-types/top-level-media-types.xhtml
 *
 * IANA does not define functional groups such as "Office documents" or
 * "Streaming video". Those are viewer-side QA groups layered on top of
 * registered MIME types plus conservative URL-extension signals.
 */
(() => {
  const EXTENSION_MIMES = Object.freeze({
    html: "text/html", htm: "text/html", xhtml: "application/xhtml+xml",
    css: "text/css", js: "text/javascript", mjs: "text/javascript", cjs: "text/javascript",
    json: "application/json", jsonld: "application/ld+json", xml: "application/xml",
    txt: "text/plain", csv: "text/csv", rtf: "application/rtf",
    jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif",
    webp: "image/webp", svg: "image/svg+xml", avif: "image/avif", ico: "image/vnd.microsoft.icon",
    tif: "image/tiff", tiff: "image/tiff", bmp: "image/bmp", heic: "image/heic", heif: "image/heif",
    mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime", m4v: "video/mp4",
    mpg: "video/mpeg", mpeg: "video/mpeg", ogv: "video/ogg", avi: "video/x-msvideo",
    mp3: "audio/mpeg", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/ogg",
    wav: "audio/wav", m4a: "audio/mp4", aac: "audio/aac", flac: "audio/flac",
    m3u8: "application/vnd.apple.mpegurl", m3u: "audio/x-mpegurl", mpd: "application/dash+xml",
    ts: "video/mp2t", m4s: "application/mp4", cmfv: "video/iso.segment", cmfa: "audio/mp4",
    pdf: "application/pdf", doc: "application/msword",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    xls: "application/vnd.ms-excel",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ppt: "application/vnd.ms-powerpoint",
    pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    odt: "application/vnd.oasis.opendocument.text", ods: "application/vnd.oasis.opendocument.spreadsheet",
    odp: "application/vnd.oasis.opendocument.presentation", odg: "application/vnd.oasis.opendocument.graphics",
    epub: "application/epub+zip",
    zip: "application/zip", gz: "application/gzip", tgz: "application/gzip", tar: "application/x-tar",
    bz2: "application/x-bzip2", xz: "application/x-xz", zst: "application/zstd",
    rar: "application/vnd.rar", "7z": "application/x-7z-compressed",
    warc: "application/warc", wacz: "application/wacz+zip",
    woff: "font/woff", woff2: "font/woff2", ttf: "font/ttf", otf: "font/otf",
    wasm: "application/wasm"
  });

  const OFFICE_MIMES = new Set([
    "application/pdf", "application/msword", "application/rtf", "text/rtf",
    "application/vnd.ms-excel", "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
    "application/vnd.openxmlformats-officedocument.presentationml.template"
  ]);

  const ARCHIVE_MIMES = new Set([
    "application/zip", "application/gzip", "application/x-gzip", "application/x-tar",
    "application/x-gtar", "application/x-bzip2", "application/x-xz", "application/zstd",
    "application/x-7z-compressed", "application/vnd.rar", "application/x-rar-compressed",
    "application/vnd.ms-cab-compressed", "application/x-apple-diskimage", "application/warc",
    "application/wacz+zip"
  ]);

  const STREAM_MANIFEST_MIMES = new Set([
    "application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl",
    "audio/x-mpegurl", "application/dash+xml", "application/vnd.ms-sstr+xml"
  ]);

  const STREAM_VIDEO_MIMES = new Set([
    "video/mp2t", "video/iso.segment"
  ]);


  const EBOOK_MIMES = new Set([
    "application/epub+zip", "application/vnd.amazon.ebook", "application/x-mobipocket-ebook"
  ]);

  function cleanMime(value) {
    if (typeof value !== "string") return "";
    const clean = value.split(";", 1)[0].trim().toLowerCase();
    return /^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(clean) ? clean : "";
  }

  function mimeFromHeaders(details) {
    if (!details || typeof details !== "object") return "";
    const candidates = [details.headers, details.responseHeaders, details.response_headers];
    for (const headers of candidates) {
      if (!headers) continue;
      if (Array.isArray(headers)) {
        for (const h of headers) {
          const name = String(h?.name || "").toLowerCase();
          if (name === "content-type") {
            const mime = cleanMime(h?.value);
            if (mime) return mime;
          }
        }
      } else if (typeof headers === "object") {
        for (const [key, value] of Object.entries(headers)) {
          if (String(key).toLowerCase() === "content-type") {
            const mime = cleanMime(String(value));
            if (mime) return mime;
          }
        }
      }
    }
    return "";
  }

  function mimeFromDetails(details) {
    if (!details || typeof details !== "object") return "";
    const candidates = [
      details.mimeType, details.mimetype, details.mime, details.contentType,
      details.content_type, details.mediaType
    ];
    for (const value of candidates) {
      const mime = cleanMime(value);
      if (mime) return mime;
    }
    return mimeFromHeaders(details);
  }

  // Remembered per load: the same URL is classified on many log lines.
  const extensionCache = new Map();
  function clearCaches() {
    extensionCache.clear();
  }

  function extensionFromUrl(url) {
    if (!url) return "";
    const cached = extensionCache.get(url);
    if (cached !== undefined) return cached;
    const result = computeExtension(url);
    if (extensionCache.size >= 400000) extensionCache.clear();
    extensionCache.set(url, result);
    return result;
  }

  function computeExtension(url) {
    try {
      const pathname = new URL(url).pathname.toLowerCase();
      if (pathname.endsWith(".warc.gz")) return "warc.gz";
      const filename = pathname.split("/").pop() || "";
      const match = filename.match(/\.([a-z0-9]{1,10})$/i);
      return match ? match[1].toLowerCase() : "";
    } catch (_) {
      return "";
    }
  }

  function mimeFromUrl(url) {
    const ext = extensionFromUrl(url);
    if (ext === "warc.gz") return "application/warc";
    return EXTENSION_MIMES[ext] || "";
  }

  const STREAM_MANIFEST_EXTS = ["m3u8", "m3u", "mpd"];
  const STREAM_SEGMENT_EXTS = ["ts", "m4s", "cmfv", "cmfa"];
  const GENERIC_MIMES = new Set(["", "application/octet-stream", "binary/octet-stream", "application/x-octet-stream"]);

  // A URL extension is only a streaming signal when the logged MIME does not
  // contradict it. Example: ".ts" is also TypeScript; a .ts file logged as
  // application/typescript or text/plain must not become "Streaming video".
  function streamExtensionApplies(ext, mime) {
    if (GENERIC_MIMES.has(mime)) return true;
    if (STREAM_MANIFEST_EXTS.includes(ext)) {
      return STREAM_MANIFEST_MIMES.has(mime) || mime === "text/plain" ||
        mime === "application/xml" || mime === "text/xml";
    }
    if (STREAM_SEGMENT_EXTS.includes(ext)) {
      return mime.startsWith("video/") || mime.startsWith("audio/") || mime === "application/mp4";
    }
    return false;
  }

  function isStreamingUrl(url, mime = "") {
    const ext = extensionFromUrl(url);
    return (STREAM_MANIFEST_EXTS.includes(ext) || STREAM_SEGMENT_EXTS.includes(ext)) &&
      streamExtensionApplies(ext, mime);
  }

  function isOfficeMime(mime) {
    if (OFFICE_MIMES.has(mime)) return true;
    return mime.startsWith("application/vnd.oasis.opendocument.");
  }

  function isStructuredMime(mime) {
    return mime === "application/json" || mime === "application/ld+json" ||
      mime === "application/xml" || mime === "text/xml" || mime === "text/csv" ||
      mime.endsWith("+json") || mime.endsWith("+xml") || mime === "application/cbor";
  }

  function groupFor({ mime = "", url = "", fileType = "", isPageEvent = false } = {}) {
    mime = cleanMime(mime);
    if (isPageEvent || fileType === "Page") return "Web pages";

    const ext = extensionFromUrl(url);
    const extApplies = streamExtensionApplies(ext, mime);
    if (STREAM_MANIFEST_MIMES.has(mime) || (STREAM_MANIFEST_EXTS.includes(ext) && extApplies)) {
      return "Streaming manifests / playlists";
    }
    if (STREAM_VIDEO_MIMES.has(mime)) return "Streaming video";
    if (extApplies) {
      if (ext === "cmfa") return "Streaming audio";
      if (ext === "ts" || ext === "cmfv") return "Streaming video";
      if (ext === "m4s") {
        if (mime.startsWith("audio/")) return "Streaming audio";
        if (mime.startsWith("video/")) return "Streaming video";
        return "Streaming media segments";
      }
    }

    if (mime.startsWith("image/")) return "Images";
    if (mime.startsWith("audio/")) return isStreamingUrl(url, mime) ? "Streaming audio" : "Audio files";
    if (mime.startsWith("video/")) return isStreamingUrl(url, mime) ? "Streaming video" : "Video files";
    if (mime.startsWith("font/") || mime === "application/font-woff" || mime === "application/vnd.ms-fontobject") return "Fonts";
    if (isOfficeMime(mime)) return "Office / documents";
    if (EBOOK_MIMES.has(mime)) return "E-books";
    if (ARCHIVE_MIMES.has(mime)) return "Archives / compressed";
    if (isStructuredMime(mime)) return "Structured data";
    if (mime === "text/css") return "Stylesheets";
    if (mime.includes("javascript") || mime.includes("typescript") || mime === "application/ecmascript" || mime === "text/ecmascript" || mime === "application/wasm") return "Scripts / web code";
    if (mime.startsWith("text/")) return mime === "text/html" ? "Web pages" : "Text";
    if (mime.startsWith("model/")) return "3D / models";
    if (mime.startsWith("message/") || mime.startsWith("multipart/")) return "Messages / multipart";
    if (mime === "application/octet-stream") return "Binary / unknown";
    if (mime.startsWith("application/")) return "Application / other";

    // Useful fallback when Browsertrix does not log a MIME type but the viewer
    // has already made a conservative file-type classification.
    const ft = String(fileType || "").toLowerCase();
    if (ft.startsWith("image")) return "Images";
    if (ft.startsWith("audio")) return "Audio files";
    if (ft.startsWith("video")) return "Video files";
    if (ft.startsWith("stream")) return "Streaming manifests / playlists";
    if (ft.startsWith("document") || ft.startsWith("spreadsheet") || ft.startsWith("presentation")) return "Office / documents";
    if (ft.startsWith("archive")) return "Archives / compressed";
    if (ft.startsWith("font")) return "Fonts";
    if (ft === "javascript" || ft === "webassembly") return "Scripts / web code";
    if (ft === "css") return "Stylesheets";
    if (["json", "xml", "csv"].includes(ft)) return "Structured data";
    if (ft === "text") return "Text";
    if (ft === "html") return "Web pages";
    return "Unclassified";
  }

  function detect(details, url, fileType, isPageEvent = false) {
    const loggedMime = mimeFromDetails(details);
    const inferredMime = loggedMime || mimeFromUrl(url);
    const hasResourceSignal = Boolean(isPageEvent || inferredMime || fileType || url);
    return {
      mimeType: inferredMime,
      mimeSource: loggedMime ? "log" : (inferredMime ? "extension" : ""),
      mimeGroup: hasResourceSignal ? groupFor({ mime: inferredMime, url, fileType, isPageEvent }) : ""
    };
  }

  // ---------------------------------------------------------------------
  // Human-readable file-type labels (the table's Type column). Moved here
  // from viewer.js in v1.6.1 so all MIME/extension knowledge has one home.
  const EXTENSION_TYPES = Object.freeze({
    html: "HTML", htm: "HTML", xhtml: "HTML",
    css: "CSS", js: "JavaScript", mjs: "JavaScript", cjs: "JavaScript",
    json: "JSON", jsonld: "JSON", xml: "XML", txt: "Text", csv: "CSV",
    jpg: "Image · JPG", jpeg: "Image · JPEG", png: "Image · PNG", gif: "Image · GIF",
    webp: "Image · WebP", svg: "Image · SVG", avif: "Image · AVIF", ico: "Image · ICO",
    tif: "Image · TIFF", tiff: "Image · TIFF", bmp: "Image · BMP", heic: "Image · HEIC", heif: "Image · HEIF",
    mp4: "Video · MP4", webm: "Video · WebM", mov: "Video · MOV", m4v: "Video · M4V",
    mpg: "Video · MPEG", mpeg: "Video · MPEG", ogv: "Video · OGG", avi: "Video · AVI",
    mp3: "Audio · MP3", ogg: "Audio · OGG", oga: "Audio · OGG", opus: "Audio · OPUS", wav: "Audio · WAV",
    m4a: "Audio · M4A", aac: "Audio · AAC", flac: "Audio · FLAC",
    m3u8: "Stream · HLS", m3u: "Stream · M3U", mpd: "Stream · DASH", ts: "Stream · TS",
    m4s: "Stream · M4S", cmfv: "Stream · video segment", cmfa: "Stream · audio segment",
    pdf: "Document · PDF", doc: "Document · DOC", docx: "Document · DOCX", rtf: "Document · RTF",
    odt: "Document · ODT", xls: "Spreadsheet · XLS", xlsx: "Spreadsheet · XLSX", ods: "Spreadsheet · ODS",
    ppt: "Presentation · PPT", pptx: "Presentation · PPTX", odp: "Presentation · ODP", odg: "Document · ODG",
    epub: "E-book · EPUB",
    zip: "Archive · ZIP", gz: "Archive · GZ", tgz: "Archive · TGZ", tar: "Archive · TAR", bz2: "Archive · BZ2",
    xz: "Archive · XZ", zst: "Archive · ZSTD", rar: "Archive · RAR", "7z": "Archive · 7Z",
    warc: "Archive · WARC", wacz: "Archive · WACZ",
    woff: "Font · WOFF", woff2: "Font · WOFF2", ttf: "Font · TTF", otf: "Font · OTF",
    wasm: "WebAssembly"
  });

  function typeLabelForMime(mime) {
    if (typeof mime !== "string") return "";
    const clean = mime.split(";", 1)[0].trim().toLowerCase();
    if (!clean.includes("/")) return "";
    const common = {
      "application/pdf": "Document · PDF",
      "application/msword": "Document · DOC",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "Document · DOCX",
      "application/vnd.ms-excel": "Spreadsheet · XLS",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "Spreadsheet · XLSX",
      "application/vnd.ms-powerpoint": "Presentation · PPT",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": "Presentation · PPTX",
      "application/vnd.oasis.opendocument.text": "Document · ODT",
      "application/vnd.oasis.opendocument.spreadsheet": "Spreadsheet · ODS",
      "application/vnd.oasis.opendocument.presentation": "Presentation · ODP",
      "application/rtf": "Document · RTF",
      "text/rtf": "Document · RTF",
      "application/epub+zip": "E-book · EPUB",
      "application/zip": "Archive · ZIP",
      "application/gzip": "Archive · GZIP",
      "application/x-gzip": "Archive · GZIP",
      "application/x-tar": "Archive · TAR",
      "application/x-bzip2": "Archive · BZ2",
      "application/x-xz": "Archive · XZ",
      "application/zstd": "Archive · ZSTD",
      "application/x-7z-compressed": "Archive · 7Z",
      "application/vnd.rar": "Archive · RAR",
      "application/vnd.apple.mpegurl": "Stream · HLS",
      "application/x-mpegurl": "Stream · HLS",
      "application/dash+xml": "Stream · DASH",
      "video/mp2t": "Stream · TS",
      "video/iso.segment": "Stream · video segment",
      "application/wasm": "WebAssembly"
    };
    if (common[clean]) return common[clean];
    if (clean === "text/html" || clean === "application/xhtml+xml") return "HTML";
    if (clean === "text/plain") return "Text";
    if (clean === "text/csv") return "CSV";
    if (clean.includes("javascript")) return "JavaScript";
    if (clean === "text/css") return "CSS";
    if (clean.includes("json")) return "JSON";
    if (clean.includes("xml")) return "XML";
    if (clean === "application/octet-stream") return "";

    const [major, minor = ""] = clean.split("/", 2);
    const prettyMinor = minor.replace(/^x-/, "").toUpperCase();
    if (major === "image") return `Image · ${prettyMinor}`;
    if (major === "audio") return `Audio · ${prettyMinor}`;
    if (major === "video") return `Video · ${prettyMinor}`;
    if (major === "font") return `Font · ${prettyMinor}`;
    return clean;
  }

  // Only the final filename segment of the URL path is inspected, and only
  // recognised extensions count: hostnames/TLDs (.dk, .com) are never types.
  function typeLabelForUrl(url) {
    const ext = extensionFromUrl(url);
    if (ext === "warc.gz") return "Archive · WARC.GZ";
    return EXTENSION_TYPES[ext] || "";
  }

  globalThis.BTLV_MIME = Object.freeze({
    cleanMime,
    mimeFromDetails,
    mimeFromUrl,
    extensionFromUrl,
    groupFor,
    detect,
    typeLabelForMime,
    typeLabelForUrl,
    clearCaches
  });
})();
