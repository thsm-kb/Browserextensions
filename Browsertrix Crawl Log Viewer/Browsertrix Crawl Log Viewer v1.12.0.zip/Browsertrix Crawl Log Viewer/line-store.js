/*
 * Browsertrix Crawl Log Viewer - line store
 *
 * Holds a log as many modest text chunks plus typed arrays of line offsets,
 * so a log of any size never has to exist as ONE JavaScript string (V8 caps a
 * string at about 536 million characters, roughly a 500 MB log).
 *
 * Line numbering matches text.split(/\r?\n/): every "\n" ends a line, a "\r"
 * directly before it is not part of the line, and a final newline does not
 * start an extra empty line. Line index i is source line number i + 1.
 *
 * Used by viewer.js (parsing, table search), raw-view.js (rendering) and
 * raw-search-worker.js (search), so all three agree on line numbers.
 */
(() => {
  class LineStore {
    constructor() {
      this.chunks = [];
      this.length = 0;
      this.maxLen = 0;
      this.chars = 0;
      this._cap = 0;
      this._chunk = new Uint32Array(0);
      this._start = new Uint32Array(0);
      this._end = new Uint32Array(0);
    }

    _grow(min) {
      let cap = Math.max(1024, this._cap * 2);
      while (cap < min) cap *= 2;
      const grow = old => {
        const next = new Uint32Array(cap);
        next.set(old.subarray(0, this.length));
        return next;
      };
      this._chunk = grow(this._chunk);
      this._start = grow(this._start);
      this._end = grow(this._end);
      this._cap = cap;
    }

    // Adds text that consists of complete lines only. If `final` is false the
    // text must end with "\n". Returns [firstLineIndex, endLineIndex).
    _addChunk(text, final) {
      const first = this.length;
      if (!text) return [first, first];
      const chunkIndex = this.chunks.length;
      this.chunks.push(text);
      this.chars += text.length;
      let pos = 0;
      while (pos < text.length) {
        let nl = text.indexOf("\n", pos);
        const hasNewline = nl !== -1;
        if (!hasNewline) {
          if (!final) throw new Error("LineStore: incomplete line in a non-final chunk");
          nl = text.length;
        }
        let end = nl;
        if (hasNewline && end > pos && text.charCodeAt(end - 1) === 13) end--; // "\r\n"
        if (this.length >= this._cap) this._grow(this.length + 1);
        this._chunk[this.length] = chunkIndex;
        this._start[this.length] = pos;
        this._end[this.length] = end;
        if (end - pos > this.maxLen) this.maxLen = end - pos;
        this.length++;
        pos = nl + 1;
      }
      return [first, this.length];
    }

    getLine(i) {
      if (i < 0 || i >= this.length) return "";
      return this.chunks[this._chunk[i]].slice(this._start[i], this._end[i]);
    }

    lineLength(i) {
      return i >= 0 && i < this.length ? this._end[i] - this._start[i] : 0;
    }
  }

  // Feeds decoded text pieces (of any size, split anywhere) into a LineStore.
  class LineSplitter {
    constructor(store) {
      this.store = store;
      this.carry = "";
    }

    // Returns the range of lines that became complete.
    push(piece) {
      if (!piece) return [this.store.length, this.store.length];
      const text = this.carry ? this.carry + piece : piece;
      const lastNl = text.lastIndexOf("\n");
      if (lastNl === -1) {
        this.carry = text;
        return [this.store.length, this.store.length];
      }
      this.carry = text.slice(lastNl + 1);
      return this.store._addChunk(text.slice(0, lastNl + 1), false);
    }

    // Call once at the end of the input.
    finish() {
      const rest = this.carry;
      this.carry = "";
      return this.store._addChunk(rest, true);
    }
  }

  // Reads a Blob/File into a LineStore without building one big string.
  async function storeFromBlob(blob, onProgress) {
    const store = new LineStore();
    const splitter = new LineSplitter(store);
    const reader = blob.stream().getReader();
    const decoder = new TextDecoder("utf-8", { fatal: false });
    let bytes = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      splitter.push(decoder.decode(value, { stream: true }));
      onProgress?.(bytes);
    }
    splitter.push(decoder.decode());
    splitter.finish();
    return store;
  }

  globalThis.BTLV_LINES = Object.freeze({ LineStore, LineSplitter, storeFromBlob });
})();
