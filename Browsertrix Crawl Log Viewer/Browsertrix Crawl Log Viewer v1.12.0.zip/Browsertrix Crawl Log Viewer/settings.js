/*
 * Browsertrix Crawl Log Viewer - Settings
 *
 * Lets each user connect their own Browsertrix address(es). Adding an address
 * asks Chrome for permission to that one site; background.js then registers
 * content.js there. Nothing is hard-coded in the extension.
 */
(() => {
  const H = globalThis.BTLV_HOSTS;
  const $ = id => document.getElementById(id);
  const els = {
    input: $("hostInput"),
    add: $("addHost"),
    message: $("message"),
    list: $("hostList"),
    empty: $("emptyHosts"),
    welcome: $("welcome"),
    updateNotice: $("updateNotice")
  };
  const VERIFY_TIMEOUT_MS = 8000;

  function say(text, tone = "") {
    els.message.textContent = text;
    els.message.className = `message${tone ? ` ${tone}` : ""}`;
  }

  async function syncBackground() {
    try {
      return await chrome.runtime.sendMessage({ type: "BTLV_RECONCILE" });
    } catch (_) {
      return null; // background will also re-sync from the storage event
    }
  }

  // Browsertrix answers GET /api/settings without login (registrationEnabled,
  // jwtTokenLifetime, ...). Used only to confirm a typo-free address.
  async function looksLikeBrowsertrix(origin) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), VERIFY_TIMEOUT_MS);
    try {
      const response = await fetch(`${origin}/api/settings`, {
        credentials: "omit",
        cache: "no-store",
        signal: controller.signal
      });
      if (!response.ok) return false;
      const data = await response.json();
      return !!data && typeof data === "object" && "registrationEnabled" in data && "jwtTokenLifetime" in data;
    } catch (_) {
      return false;
    } finally {
      clearTimeout(timer);
    }
  }

  async function statuses() {
    const hosts = await H.getHosts();
    let registered = [];
    try {
      registered = await chrome.scripting.getRegisteredContentScripts();
    } catch (_) { /* treated as not yet active */ }
    const ids = new Set(registered.map(script => script.id));
    return Promise.all(hosts.map(async origin => ({
      origin,
      granted: await chrome.permissions.contains({ origins: [H.matchPattern(origin)] }),
      active: ids.has(H.scriptId(origin))
    })));
  }

  async function render() {
    const items = await statuses();
    els.list.replaceChildren();
    els.empty.hidden = items.length > 0;

    for (const item of items) {
      const li = document.createElement("li");
      const origin = document.createElement("span");
      origin.className = "host-origin";
      origin.textContent = item.origin;

      const status = document.createElement("span");
      if (item.granted && item.active) {
        status.className = "status connected";
        status.textContent = "Connected";
      } else if (item.granted) {
        status.className = "status waiting";
        status.textContent = "Connecting…";
      } else {
        status.className = "status missing";
        status.textContent = "Permission needed";
        status.title = "Chrome's permission for this site is missing. Click “Allow access”.";
      }
      li.append(origin, status);

      if (!item.granted) {
        const grant = document.createElement("button");
        grant.type = "button";
        grant.className = "button small";
        grant.textContent = "Allow access";
        grant.addEventListener("click", () => grantAccess(item.origin));
        li.appendChild(grant);
      }

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "button small quiet";
      remove.textContent = "Remove";
      remove.setAttribute("aria-label", `Remove ${item.origin}`);
      remove.addEventListener("click", () => removeHost(item.origin));
      li.appendChild(remove);

      els.list.appendChild(li);
    }
  }

  async function addHost() {
    const parsed = H.normalizeOrigin(els.input.value);
    if (parsed.error) {
      say(parsed.error, "bad");
      els.input.focus();
      return;
    }
    const { origin } = parsed;

    // permissions.request must run directly in the click handler (user
    // gesture), so it comes before any other asynchronous step.
    let granted = false;
    try {
      granted = await chrome.permissions.request({ origins: [H.matchPattern(origin)] });
    } catch (error) {
      say(`Chrome could not ask for permission: ${error?.message || error}`, "bad");
      return;
    }
    if (!granted) {
      say("The address was not added, because Chrome’s permission was not given. Click Add again and choose Allow.", "bad");
      return;
    }

    const hosts = await H.getHosts();
    const already = hosts.includes(origin);
    await H.setHosts([...hosts, origin]);
    await syncBackground();
    await render();
    els.input.value = "";

    say(`Checking ${origin}…`);
    const confirmed = await looksLikeBrowsertrix(origin);
    const pathNote = parsed.pathIgnored ? " Only the address part of what you pasted is used." : "";
    if (confirmed) {
      say(`${already ? "Already connected" : "Connected"}: ${origin}. Browsertrix confirmed.${pathNote} Click Download Logs in Browsertrix to try it.`, "ok");
    } else {
      say(`${already ? "Already connected" : "Connected"}: ${origin}, but it did not answer like Browsertrix.${pathNote} If Download Logs is not caught there, check the address (copy it from the address bar while Browsertrix is open).`, "warn");
    }
  }

  async function grantAccess(origin) {
    let granted = false;
    try {
      granted = await chrome.permissions.request({ origins: [H.matchPattern(origin)] });
    } catch (error) {
      say(`Chrome could not ask for permission: ${error?.message || error}`, "bad");
      return;
    }
    await syncBackground();
    await render();
    say(granted ? `Access allowed for ${origin}.` : "Permission was not given.", granted ? "ok" : "bad");
  }

  async function removeHost(origin) {
    const hosts = await H.getHosts();
    const remaining = hosts.filter(host => host !== origin);
    await H.setHosts(remaining);
    // Take back Chrome's permission too, unless another saved address uses the
    // same host name (permissions are per host name, not per port).
    const pattern = H.matchPattern(origin);
    if (!remaining.some(host => H.matchPattern(host) === pattern)) {
      await chrome.permissions.remove({ origins: [pattern] }).catch(() => false);
    }
    await syncBackground();
    await render();
    say(`Removed ${origin}. Download Logs there is no longer caught.`, "ok");
  }

  els.add.addEventListener("click", addHost);
  els.input.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      addHost();
    }
  });

  // Keep the list right when site access is changed in chrome://extensions.
  chrome.permissions.onAdded.addListener(() => syncBackground().then(render));
  chrome.permissions.onRemoved.addListener(() => syncBackground().then(render));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[H.STORAGE_KEY]) render();
  });

  const reason = location.hash.slice(1);
  els.welcome.hidden = reason !== "welcome";
  els.updateNotice.hidden = reason !== "update";

  syncBackground().then(render);
  if (reason) els.input.focus();
})();
