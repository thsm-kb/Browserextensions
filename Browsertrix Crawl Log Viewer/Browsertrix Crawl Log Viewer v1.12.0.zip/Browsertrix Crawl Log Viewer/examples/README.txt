Examples / development references
================================

example-browsertrix-crawl.log
  A real Browsertrix crawl log (NDJSON), REDACTED for publication:
  - host names are replaced with reserved example domains (example.org,
    example.net, media.example.org), which never point to real sites;
  - every URL path word is replaced with a lorem-ipsum word, keeping file
    extensions, and the same original always gets the same replacement;
  - file names, browser IDs and other identifying values are neutral.
  Browsertrix's own messages, log levels, contexts, HTTP statuses, sizes, MIME
  types and timestamps are unchanged, so the log still exercises parsing,
  pages/resources, sizes, MIME groups, memory telemetry, soft-404 comparison
  and provenance exactly like the original.
