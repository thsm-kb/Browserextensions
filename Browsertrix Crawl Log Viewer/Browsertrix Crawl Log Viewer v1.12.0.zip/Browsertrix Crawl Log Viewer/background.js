importScripts("browsertrix-hosts.js");

const H = globalThis.BTLV_HOSTS;
const KEY_PREFIX = "btrixLog:";

/*
 * auth_bearer token handling (see Instructions_for_agents.txt, TOKEN RULES).
 * The signed log link is handed from content.js to the viewer through
 * chrome.storage.session, which lives in memory only and is locked to the
 * extension's own pages. The viewer deletes the entry the moment it reads it.
 * An entry nobody picked up (the viewer tab was closed at once) is deleted
 * after HANDOFF_TTL_MS by an alarm, and session storage is wiped by Chrome
 * when the browser closes.
 */
const HANDOFF_TTL_MS = 2 * 60 * 1000;
const PURGE_ALARM = "btlv-purge-handoff";

// Never let content scripts read session storage (Chrome's default, made explicit).
chrome.storage.session.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" }).catch(() => {});

function logError(...parts) {
  console.error("Browsertrix Crawl Log Viewer:", ...parts.map(part => H.redactSecrets(part?.message ?? part)));
}

async function pruneOldEntries() {
  const all = await chrome.storage.session.get(null);
  const cutoff = Date.now() - HANDOFF_TTL_MS;
  const remove = Object.entries(all)
    .filter(([key, value]) => key.startsWith(KEY_PREFIX) && (!value?.createdAt || value.createdAt < cutoff))
    .map(([key]) => key);
  if (remove.length) await chrome.storage.session.remove(remove);
}

// The filename comes from the Browsertrix page; make sure it can never carry
// a token or a path.
function safeFilename(name) {
  const clean = H.redactSecrets(String(name || "")).replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").slice(0, 120);
  return clean && !/redacted/i.test(clean) ? clean : "browsertrix-logs.log";
}

async function openViewer(logUrl, filename) {
  await pruneOldEntries().catch(() => {});
  const id = crypto.randomUUID();
  const key = KEY_PREFIX + id;

  // Keep the signed URL only in session storage. It is not placed in the
  // viewer URL, browsing history, bookmarks, or persistent extension storage.
  await chrome.storage.session.set({
    [key]: {
      url: logUrl,
      filename: safeFilename(filename),
      createdAt: Date.now()
    }
  });
  // Delete it even if the viewer never picks it up.
  chrome.alarms.create(PURGE_ALARM, { delayInMinutes: HANDOFF_TTL_MS / 60000 + 0.1 });

  await chrome.tabs.create({
    url: chrome.runtime.getURL(`viewer.html#${encodeURIComponent(id)}`),
    active: true
  });
}

// ---------------------------------------------------------------------------
// Content-script registration. The manifest has no fixed content script and no
// fixed host permission: content.js runs only on the Browsertrix addresses the
// user added in Settings AND granted in Chrome's permission prompt.

let reconcileChain = Promise.resolve();

async function reconcileNow() {
  const hosts = await H.getHosts();
  const desired = new Map();
  for (const origin of hosts) {
    if (await chrome.permissions.contains({ origins: [H.matchPattern(origin)] })) {
      desired.set(H.scriptId(origin), origin);
    }
  }

  const ours = (await chrome.scripting.getRegisteredContentScripts())
    .filter(script => script.id.startsWith(H.SCRIPT_ID_PREFIX));
  const stale = ours.filter(script => !desired.has(script.id)).map(script => script.id);
  if (stale.length) await chrome.scripting.unregisterContentScripts({ ids: stale });

  const existing = new Set(ours.map(script => script.id));
  const added = [...desired]
    .filter(([id]) => !existing.has(id))
    .map(([id, origin]) => ({
      id,
      matches: [H.matchPattern(origin)],
      js: ["content.js"],
      runAt: "document_start",
      persistAcrossSessions: true
    }));

  if (added.length) {
    await chrome.scripting.registerContentScripts(added);
    // Activate Browsertrix tabs that are already open, so no reload is needed.
    // content.js guards against running twice in the same page.
    for (const script of added) {
      const tabs = await chrome.tabs.query({ url: script.matches }).catch(() => []);
      for (const tab of tabs) {
        chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }).catch(() => {});
      }
    }
  }
  return { connected: [...desired.values()] };
}

// Serialised: storage and permission events can fire together, and registering
// the same script id twice is an error.
function reconcile() {
  const run = reconcileChain.then(reconcileNow, reconcileNow);
  reconcileChain = run.catch(error => logError(error));
  return run;
}

chrome.runtime.onInstalled.addListener(async details => {
  await reconcile().catch(() => {});
  const hosts = await H.getHosts().catch(() => []);
  // First install, or an update from a version with a built-in address: the
  // user has to connect their own Browsertrix once.
  if (details.reason === "install" || (details.reason === "update" && hosts.length === 0)) {
    const reason = details.reason === "install" ? "welcome" : "update";
    await chrome.tabs.create({ url: chrome.runtime.getURL(`settings.html#${reason}`), active: true });
  }
});

chrome.runtime.onStartup.addListener(() => { reconcile().catch(() => {}); });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === PURGE_ALARM) pruneOldEntries().catch(() => {});
});
chrome.permissions.onAdded.addListener(() => { reconcile().catch(() => {}); });
chrome.permissions.onRemoved.addListener(() => { reconcile().catch(() => {}); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[H.STORAGE_KEY]) reconcile().catch(() => {});
});

// ---------------------------------------------------------------------------

async function handleOpenLog(message, sender) {
  if (typeof message.url !== "string") throw new Error("Missing log link.");
  let url;
  try {
    url = new URL(message.url);
  } catch {
    throw new Error("The log link is not a valid address."); // never echo the link
  }

  // The log link must come from the page that sent it...
  let senderOrigin = sender.origin;
  if (!senderOrigin && sender.url) senderOrigin = new URL(sender.url).origin;
  if (!senderOrigin || url.origin !== senderOrigin) {
    throw new Error(`Blocked log link from a different site (${url.origin} sent by ${senderOrigin || "unknown"}).`);
  }
  // ...and that page must be a Browsertrix address the user added.
  const hosts = await H.getHosts();
  if (!hosts.includes(url.origin)) {
    throw new Error(`Blocked log link from an address that is not in Settings: ${url.origin}`);
  }
  if (!H.LOG_PATH_RE.test(url.pathname)) {
    throw new Error("URL does not look like a Browsertrix crawl log endpoint.");
  }
  await openViewer(message.url, message.filename);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "OPEN_BROWSERTRIX_LOG") {
    handleOpenLog(message, sender)
      .then(() => sendResponse({ ok: true }))
      .catch(error => {
        logError(error);
        sendResponse({ ok: false, error: H.redactSecrets(error?.message || error) });
      });
    return true;
  }
  // Only the extension's own pages (Settings) may ask for a re-sync.
  if (message?.type === "BTLV_RECONCILE" && sender.id === chrome.runtime.id &&
      typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL(""))) {
    reconcile()
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(error => sendResponse({ ok: false, error: H.redactSecrets(error?.message || error) }));
    return true;
  }
  return undefined;
});

chrome.action.onClicked.addListener(async () => {
  await chrome.tabs.create({
    url: chrome.runtime.getURL("viewer.html"),
    active: true
  });
});
