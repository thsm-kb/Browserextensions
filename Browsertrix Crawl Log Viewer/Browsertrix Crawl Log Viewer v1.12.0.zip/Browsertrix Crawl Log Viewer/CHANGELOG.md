# Changelog

All notable changes to **Browsertrix Crawl Log Viewer**.

## 1.12.0

### Changed
- **Large logs no longer hang the viewer.** Lines are parsed while the log downloads, in short slices, so the page stays responsive and the progress (percentage, bytes, lines, then each analysis step) keeps moving. Measured on a 228 MB log: the page used to freeze for 16 seconds; the longest pause is now under one second.
- **Faster loading.** URL parsing, which took almost half the load time, is now done once per URL: a 75 MB log loads in 2.7 s instead of 6 s, a 228 MB log in 7 s instead of 16 s.
- **No size limit from JavaScript strings.** The log is never held as one piece of text, so logs larger than about 500 MB, which could not load before, now load (a 607 MB log in about 23 s). Memory is the practical limit: roughly 3–4 times the log size.
- **Less memory.** The table search no longer keeps a second, lowercased copy of every event; it searches the original lines. Results are unchanged.
- **The example log is redacted.** Host names are reserved example domains, URL paths are lorem ipsum, and file names and IDs are neutral; it still behaves exactly like the original in the viewer. The unrelated BBC reference file was removed.

## 1.11.0 (security)

### Changed
- **The `auth_bearer` token can no longer escape.**
  - **Read once:** the viewer deletes the handed-over link from Chrome's session memory the moment it reads it, and a link nobody picks up is deleted after 2 minutes (previously up to an hour, or until a download succeeded).
  - **Fails closed:** if the viewer can't be opened, the extension shows a notice in Browsertrix and downloads nothing. It previously fell back to a normal download, which stored the link with its token in Chrome's download history.
  - **Strict fetch:** the log is fetched without following redirects and without a Referer, in addition to the existing no cookies and no disk cache.
  - **Scrubbed messages:** every message the extension shows or logs is scrubbed of tokens, and invalid links are reported without being echoed. Session storage is explicitly locked to the extension's own pages.
- A failed download is retried with a new **Retry** button; reloading the viewer tab no longer retries, because the link isn't stored anywhere.
- New `alarms` permission (no warning at install) to delete unclaimed links on time.

## 1.10.0

### Added
- **A notice when Gemini Nano can't run.** The Gemini button no longer just goes grey. It reads **Why is Gemini Nano unavailable?**, and clicking it explains the reason for this browser and what to do: use Google Chrome (not Edge, Brave, Opera …), update a Chrome older than 138, turn built-in AI back on (setting, organisation policy or flags), or check the computer requirements. The same notice appears if Chrome refuses while the analysis starts.

## 1.9.0

### Added
- **Works with any Browsertrix.** A new **Settings** page connects the extension to your own Browsertrix: paste its address, click **Add**, and allow access when Chrome asks. Several addresses are supported. Settings opens by itself on first install, and from the **Settings** button in the viewer or *Extension options* in `chrome://extensions`.
- Settings checks the address and confirms when it is a Browsertrix, so typos are caught.

### Changed
- **No built-in Browsertrix address.** The extension no longer contains any institution's address, and it is installed without access to any website. It gets access only to the addresses you add, and loses it again when you remove them.
- A log link is opened only if it comes from the same connected address as the page it was clicked on. Only `https://` addresses are accepted (plain `http://` only for `localhost`).

### Upgrade note
- After updating, Settings opens: add your Browsertrix address once.

## 1.8.0

### Changed
- The **Details** column is gone. The details toggle (*N fields*) now sits at the end of each **Message** cell and still opens the full `details` JSON and the link to the raw log line. The Message column is wider to make room.
- The extension, its folder and its download are now all named **Browsertrix Crawl Log Viewer**.
- New README in the same form as the other extensions in this repository, with installation steps for a downloaded zip. This changelog replaces `README.txt`.

### Upgrade note
- The folder name changed. Chrome identifies an unpacked extension by its folder, so loading the new folder next to the old one installs a **second copy**. Remove the old card in `chrome://extensions` first, or copy the new files into your existing folder. See the README.

## 1.7.0
- Table columns can be moved left and right by dragging their headers. A blue line shows where the column will land; the dragged header stays inside the table, and the table scrolls when you hold it near an edge. Esc cancels a drag.
- Keyboard: focus a header with Tab, Alt+←/→ moves it, Enter sorts.
- Columns can only be moved, never hidden or removed. The order is remembered; **Reset column order** below the table restores the default.
- A click without dragging still sorts the column.

## 1.6.1 (review fixes)
- Logs with very many memory samples (large `--logging debug` crawls) no longer fail to load (stack overflow in the diagnostics).
- Crawl-limit detection uses Browsertrix's own stop messages (size, time, failed-page and disk-utilization thresholds, page limit). *Retry limit reached* for one page is no longer reported as a crawl limit, and page limit 0 is shown as *no page limit configured*.
- Disk-utilization stops (logged at info level) count as storage issues.
- Page outcomes follow Browsertrix semantics: completed, failed (retry limit reached or empty non-200), skipped, started.
- A `.ts` file with a non-video MIME type (TypeScript) is no longer classified as streaming video.
- The blocking and RAM chips state their limits: HTTP status is only logged for failed pages, and RSS is the crawler's Node.js process, not Chrome.
- Gemini Nano: real line breaks in the prompt, the expected JSON shape is described, finding severities are shown, and the caveats are passed on as facts.
- Less memory per row; the file size is no longer measured by copying the log.
- The log is fetched without cookies. The signed URL is kept until the download succeeds, so a failed download can be retried by reloading.
- Removed the unneeded `tabs` permission. MIME/type label tables now live only in `mime-groups.js`.

## 1.6.0
- New **Raw log** tab showing the original log as code: line numbers (the same as the table's source line), JSON syntax colouring, and gutter marks for warn, error/fatal and malformed lines.
- Plain-text or regular-expression search with match case, next/previous (Enter, Shift+Enter, F3), **Only matching lines** (grep-style) and **Wrap lines** toggles, and Go to line.
- Search runs in a Web Worker; a regular expression that stalls for 8 seconds is stopped.
- Every expanded table row links to its line in the raw view.

## 1.5.1
- Added a GitHub-ready `README.md` with installation, features, MIME methodology, privacy and security, diagnostics, development notes and version history.

## 1.5.0
- New **Guide** page with feature explanations, technical workflow, interpretation caveats, privacy notes and MIME-grouping documentation. The guide title shows the live extension version and the byline *made by Thomas Smedebøl, Royal Danish Library*.
- Added `Instructions_for_agents.txt` with architecture, decisions, requirements, testing notes and continuation guidance for another developer or AI agent.
- New sortable **MIME group** column and MIME-group filter. Grouping is based on the IANA Media Types registry and top-level media type families, with a documented functional overlay for QA (Images, Office / documents, Audio files, Video files, Streaming manifests / playlists, Streaming audio, Streaming video, Streaming media segments, Archives / compressed, Structured data, Scripts / web code, Stylesheets, Fonts, E-books, 3D / models, Messages / multipart, Application / other, Binary / unknown).
- Streaming classification is conservative: ordinary `audio/*` and `video/*` are not called streaming without an HLS/DASH/segment-specific MIME or URL signal.
- MIME values come from Browsertrix details/headers where available. When a MIME is missing, a small explicit list of recognized filename extensions may infer one. Hostnames and TLDs are never used as file extensions.

## 1.4.0
- Prominent *Fetching Browsertrix crawl log…* state with streaming download progress: percentage and received/total bytes when a reliable `Content-Length` is known, otherwise an indeterminate bar with received bytes.
- **Pages** as a first-class option in the file-type filter.
- URL-aware file-type detection; `.dk`, `.com`, `.org` are never file types.
- **Domain** column.
- Deterministic crawl diagnostics and the optional on-device **Gemini Nano** report.

## 1.3.1
- Runtime host-permission fix.

## 1.3.0
- URL provenance / origin tracing: EXACT for `details.page` and explicit source/referrer/parent metadata, INFERRED for queued page URLs in single-worker crawls when timing makes it defensible, INITIAL for URLs queued before page processing starts.

## 1.2.0
- Soft-404 probe against `<first-seed origin>/browsertrixsoft404detect`, with suspected soft-404 marking by host, normalized type and approximately equal size (±8 % or ±2 KB, whichever is larger).
- Filter-dependent resource totals: unique count, known sizes, combined size, average, median and largest.
- Compact first-seed / seed count / scope / crawler-version header.

## 1.1.0
- Resource type and size support.

## 1.0.0
- Initial viewer: intercepts Browsertrix **Download Logs** and opens the log in a sortable, filterable table.
