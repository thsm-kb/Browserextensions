/*
 * Browsertrix Crawl Log Viewer - Settings: "While a crawl log loads"
 * Cards on/off (default on) and web-archiving news on/off (default off).
 * Turning news on asks Chrome for access to the news feeds' sites; turning it
 * off deletes cached news and gives that access back (except for sites that
 * are also saved Browsertrix addresses).
 */
(() => {
  const N = globalThis.BTLV_NEWS;
  const C = globalThis.BTLV_NEWS_CONFIG;
  const H = globalThis.BTLV_HOSTS;
  const $ = id => document.getElementById(id);
  const els = {
    cards: $("cardsEnabled"), news: $("newsEnabled"), details: $("newsDetails"),
    sources: $("newsSources"), refresh: $("newsRefresh"), info: $("newsInfo"), message: $("loadingMessage")
  };
  if (!N || !els.cards) return;

  function say(text, tone = "") {
    els.message.textContent = text;
    els.message.className = `message${tone ? ` ${tone}` : ""}`;
  }

  async function renderNews() {
    const { news } = await N.prefs();
    els.details.hidden = !news;
    if (!news) return;
    const s = await N.status();
    els.sources.replaceChildren(...C.SOURCES.map(source => {
      const li = document.createElement("li");
      const name = document.createElement("span");
      name.textContent = source.name;
      const st = document.createElement("span");
      const h = s.health[source.id];
      if (!h) { st.textContent = "not checked yet"; st.className = "src-quiet"; }
      else if (!h.ok) { st.textContent = `unavailable: ${h.error}`; st.className = "src-bad"; }
      else if (!h.fresh) { st.textContent = "nothing new in the last 30 days"; st.className = "src-quiet"; }
      else { st.textContent = `${h.fresh} fresh item${h.fresh === 1 ? "" : "s"}`; st.className = "src-ok"; }
      li.append(name, st);
      return li;
    }));
    els.info.textContent = s.lastRefresh
      ? `${s.cards.length} news card${s.cards.length === 1 ? "" : "s"} ready · last checked ${new Date(s.lastRefresh).toLocaleString()}`
      : "";
  }

  async function refreshNow() {
    els.refresh.disabled = true;
    els.info.textContent = "Checking news sources…";
    try {
      await N.refresh({ force: true, onProgress: () => {} });
    } finally {
      els.refresh.disabled = false;
      await renderNews();
    }
  }

  els.cards.addEventListener("change", async () => {
    await N.setPref("cards", els.cards.checked);
    say(els.cards.checked ? "Cards will be shown while a crawl log loads." : "Cards are turned off.", "ok");
  });

  els.news.addEventListener("change", async () => {
    if (els.news.checked) {
      // Must be the first await in the click handler (user gesture).
      let granted = false;
      try {
        granted = await chrome.permissions.request({ origins: N.hostPatterns() });
      } catch (error) {
        say(`Chrome could not ask for permission: ${error?.message || error}`, "bad");
      }
      if (!granted) {
        els.news.checked = false;
        say("News was not turned on, because Chrome’s permission was not given.", "bad");
        return;
      }
      await N.setPref("news", true);
      say("News is on. Checking the news sources now…", "ok");
      await renderNews();
      await refreshNow();
      say("News is on.", "ok");
    } else {
      await N.setPref("news", false);
      await N.clearNews();
      // Give back the news sites' access, unless a site is also a Browsertrix address.
      const keep = new Set((await H.getHosts()).map(o => H.matchPattern(o)));
      const release = N.hostPatterns().filter(p => !keep.has(p));
      if (release.length) await chrome.permissions.remove({ origins: release }).catch(() => false);
      await renderNews();
      say("News is off. Cached news was deleted and access to the news sites given back.", "ok");
    }
  });

  els.refresh.addEventListener("click", refreshNow);

  (async () => {
    const p = await N.prefs();
    els.cards.checked = p.cards;
    // If access was taken away in chrome://extensions, news cannot stay on.
    if (p.news && !(await N.hasPermission())) await N.setPref("news", false);
    els.news.checked = (await N.prefs()).news;
    await renderNews();
  })();
})();
