/*
 * Browsertrix Crawl Log Viewer - raw log view
 *
 * Shows the original log text as code: line numbers that match the table's
 * "source line", light JSON syntax colouring, plain-text or regular-expression
 * search, optional line wrapping and an "only matching lines" (grep) mode.
 *
 * Rendering is block-virtualised so large logs stay responsive: lines are
 * grouped into blocks of BLOCK lines; only blocks near the viewport hold DOM
 * nodes, the rest are empty placeholders with a known or estimated height.
 */
(() => {
  const S = globalThis.BTLV_RAW_SEARCH;
  const BLOCK = 200;
  const LINE_H = 18; // px; must match --raw-line-h in viewer.css
  const SYNTAX_MAX_CHARS = 20000; // longer lines are shown without syntax colour
  const HIGHLIGHT_MAX_PER_LINE = 5000;
  const STALL_MS = 8000; // no worker progress for this long => stuck regex
  const SEARCH_DEBOUNCE_MS = 220;
  const MIN_WIDTH_MAX_CH = 200000;
  const PREF_KEY = "btlv.rawView.prefs.v1";

  const $ = id => document.getElementById(id);
  const els = {
    panel: $("rawPanel"),
    search: $("rawSearch"),
    regex: $("rawRegex"),
    caseSensitive: $("rawCase"),
    prev: $("rawPrev"),
    next: $("rawNext"),
    status: $("rawSearchStatus"),
    onlyMatches: $("rawOnlyMatches"),
    wrap: $("rawWrap"),
    goto: $("rawGoto"),
    scroller: $("rawScroller"),
    content: $("rawContent"),
    footer: $("rawFooter")
  };
  if (!els.panel || !S) return;

  // The log comes as a line source: { lineCount, getLine(i), maxLen, getBlob() }.
  // It is never one big string (see line-store.js).
  const EMPTY_SOURCE = { lineCount: 0, getLine: () => "", maxLen: 0, getBlob: () => new Blob([]) };

  const raw = {
    source: EMPTY_SOURCE,
    prepared: false,
    markerSpec: null,
    markers: null,
    markerCounts: { warn: 0, error: 0, malformed: 0 },
    maxLen: 0,
    visible: false,
    dirty: true,

    wrap: false,
    onlyMatches: false,
    regex: false,
    caseSensitive: false,

    re: null,
    result: null,
    current: -1,
    searchId: 0,
    searching: false,
    error: "",
    debounce: null,
    stallTimer: null,

    viewLines: null,
    blocks: [],
    rendered: new Set(),
    heights: [],
    measuredPx: 0,
    measuredLines: 0,
    targetLine: -1,
    observer: null,
    lastWidth: 0,

    worker: null,
    workerBroken: false
  };

  // ---------------------------------------------------------------- prefs

  function loadPrefs() {
    try {
      const prefs = JSON.parse(localStorage.getItem(PREF_KEY) || "{}");
      raw.wrap = !!prefs.wrap;
      raw.onlyMatches = !!prefs.onlyMatches;
      raw.regex = !!prefs.regex;
      raw.caseSensitive = !!prefs.caseSensitive;
    } catch (_) { /* defaults */ }
  }

  function savePrefs() {
    try {
      localStorage.setItem(PREF_KEY, JSON.stringify({
        wrap: raw.wrap, onlyMatches: raw.onlyMatches, regex: raw.regex, caseSensitive: raw.caseSensitive
      }));
    } catch (_) { /* storage unavailable: preferences are per session only */ }
  }

  function syncControls() {
    els.regex.setAttribute("aria-pressed", String(raw.regex));
    els.caseSensitive.setAttribute("aria-pressed", String(raw.caseSensitive));
    els.onlyMatches.checked = raw.onlyMatches;
    els.wrap.checked = raw.wrap;
    els.scroller.classList.toggle("wrap", raw.wrap);
    els.search.placeholder = raw.regex ? "Search raw log (regular expression)" : "Search raw log";
  }

  // ---------------------------------------------------------------- lines

  function ensureLines() {
    if (raw.prepared) return;
    raw.prepared = true;
    const n = raw.source.lineCount;
    raw.maxLen = raw.source.maxLen;

    raw.markers = new Uint8Array(n);
    const counts = { warn: 0, error: 0, malformed: 0 };
    const spec = raw.markerSpec || {};
    const mark = (lineNumbers, value, key) => {
      for (const ln of lineNumbers || []) {
        const i = ln - 1;
        if (i >= 0 && i < n && raw.markers[i] < value) {
          raw.markers[i] = value;
          counts[key]++;
        }
      }
    };
    mark(spec.warn, 1, "warn");
    mark(spec.error, 2, "error");
    mark(spec.malformed, 3, "malformed");
    raw.markerCounts = counts;

    els.content.style.setProperty("--raw-gutter", `${String(n).length + 1}ch`);
    renderFooter();
  }

  function renderFooter() {
    const n = raw.source.lineCount;
    const c = raw.markerCounts;
    els.footer.replaceChildren();
    const add = (text, cls) => {
      const span = document.createElement("span");
      if (cls) {
        const swatch = document.createElement("i");
        swatch.className = `raw-swatch ${cls}`;
        swatch.setAttribute("aria-hidden", "true");
        span.appendChild(swatch);
      }
      span.append(text);
      els.footer.appendChild(span);
    };
    add(`${n.toLocaleString()} lines`);
    if (c.warn) add(`${c.warn.toLocaleString()} warn`, "m1");
    if (c.error) add(`${c.error.toLocaleString()} error / fatal`, "m2");
    if (c.malformed) add(`${c.malformed.toLocaleString()} malformed (not in table)`, "m3");
    const note = document.createElement("span");
    note.className = "raw-footer-note";
    note.textContent = "Line numbers match the table’s source line.";
    els.footer.appendChild(note);
  }

  function viewCount() {
    return raw.viewLines ? raw.viewLines.length : raw.source.lineCount;
  }

  function lineAt(pos) {
    return raw.viewLines ? raw.viewLines[pos] : pos;
  }

  function lowerBound(arr, value) {
    let lo = 0;
    let hi = arr.length;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (arr[mid] < value) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  function posOfLine(line) {
    if (!raw.viewLines) return line >= 0 && line < viewCount() ? line : -1;
    const i = lowerBound(raw.viewLines, line);
    return raw.viewLines[i] === line ? i : -1;
  }

  function lineHasHit(line) {
    const hits = raw.result?.lineHits;
    if (!hits || !hits.length) return false;
    const i = lowerBound(hits, line);
    return hits[i] === line;
  }

  // ---------------------------------------------------------------- syntax

  const TOKEN_RE = /("(?:[^"\\]|\\.)*")|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)|(true|false|null)\b|([{}[\],:])|(\s+)|([^"\s{}[\],:]+|")/y;
  const LEVEL_CLASSES = new Set(["debug", "info", "warn", "error", "interrupt", "fatal"]);

  function tokenize(line) {
    const tokens = [];
    TOKEN_RE.lastIndex = 0;
    let lastKey = "";
    let m;
    while (TOKEN_RE.lastIndex < line.length && (m = TOKEN_RE.exec(line)) !== null) {
      const s = m.index;
      const e = TOKEN_RE.lastIndex;
      let c = "";
      if (m[1] !== undefined) {
        let j = e;
        while (j < line.length && (line[j] === " " || line[j] === "\t")) j++;
        if (line[j] === ":") {
          c = "t-k";
          lastKey = m[1];
        } else {
          c = "t-s";
          if (lastKey === '"logLevel"') {
            const level = m[1].slice(1, -1).toLowerCase();
            if (LEVEL_CLASSES.has(level)) c += ` t-lv-${level}`;
          } else if (lastKey === '"message"') {
            c += " t-msg";
          }
        }
      } else if (m[2] !== undefined) c = "t-n";
      else if (m[3] !== undefined) c = "t-b";
      else if (m[4] !== undefined) {
        c = "t-p";
        if (m[4] === "," || m[4] === "{" || m[4] === "}") lastKey = "";
      }
      tokens.push({ s, e, c });
    }
    if (!tokens.length || tokens[tokens.length - 1].e < line.length) {
      tokens.push({ s: tokens.length ? tokens[tokens.length - 1].e : 0, e: line.length, c: "" });
    }
    return tokens;
  }

  function esc(text) {
    return text.replace(/[&<>]/g, ch => (ch === "&" ? "&amp;" : ch === "<" ? "&lt;" : "&gt;"));
  }

  // Merges syntax tokens with search-match ranges into HTML for one line.
  function lineHtml(index) {
    const line = raw.source.getLine(index);
    if (!line) return "";

    let matches = [];
    if (raw.re && lineHasHit(index)) {
      matches = S.matchesInLine(raw.re, line, [], HIGHLIGHT_MAX_PER_LINE);
    }
    const tokens = line.length <= SYNTAX_MAX_CHARS ? tokenize(line) : [{ s: 0, e: line.length, c: "" }];
    if (!matches.length && tokens.length === 1 && !tokens[0].c) return esc(line);

    let curS = -1;
    let curE = -1;
    if (raw.current >= 0 && raw.result && raw.result.matchLine[raw.current] === index) {
      curS = raw.result.matchStart[raw.current];
      curE = raw.result.matchEnd[raw.current];
    }

    const spans = matches.filter(([s, e]) => e > s);
    const zeros = matches.filter(([s, e]) => e === s);
    const cutSet = new Set([0, line.length]);
    for (const t of tokens) { cutSet.add(t.s); cutSet.add(t.e); }
    for (const [s, e] of spans) { cutSet.add(s); cutSet.add(e); }
    const cuts = [...cutSet].sort((a, b) => a - b);

    let out = "";
    let ti = 0;
    let mi = 0;
    let zi = 0;
    for (let k = 0; k < cuts.length; k++) {
      const a = cuts[k];
      while (zi < zeros.length && zeros[zi][0] < a) zi++;
      while (zi < zeros.length && zeros[zi][0] === a) {
        const cur = a === curS && a === curE;
        out += `<mark class="hit zero${cur ? " cur" : ""}" data-s="${a}"></mark>`;
        zi++;
      }
      if (k === cuts.length - 1) break;
      const b = cuts[k + 1];
      while (ti < tokens.length && tokens[ti].e <= a) ti++;
      const cls = ti < tokens.length && tokens[ti].s <= a ? tokens[ti].c : "";
      while (mi < spans.length && spans[mi][1] <= a) mi++;
      const hit = mi < spans.length && spans[mi][0] <= a ? spans[mi] : null;
      const text = esc(line.slice(a, b));
      if (hit) {
        const cur = hit[0] === curS && hit[1] === curE;
        out += `<mark class="hit${cur ? " cur" : ""}${cls ? ` ${cls}` : ""}" data-s="${hit[0]}">${text}</mark>`;
      } else if (cls) {
        out += `<span class="${cls}">${text}</span>`;
      } else {
        out += text;
      }
    }
    return out;
  }

  const MARKER_TITLES = ["", "warn", "error / fatal", "Malformed JSON: skipped by the table"];

  function blockHtml(b) {
    const start = b * BLOCK;
    const end = Math.min(start + BLOCK, viewCount());
    let html = "";
    for (let pos = start; pos < end; pos++) {
      const index = lineAt(pos);
      const marker = raw.markers[index];
      const classes = `raw-line${marker ? ` m${marker}` : ""}${index === raw.targetLine ? " target" : ""}`;
      const title = marker === 3 ? ` title="${MARKER_TITLES[3]}"` : "";
      html += `<div class="${classes}" data-line="${index}"${title}><span class="ln">${index + 1}</span><span class="code">${lineHtml(index)}</span></div>`;
    }
    return html;
  }

  // ---------------------------------------------------------- virtualisation

  function estimateHeight(b) {
    if (raw.heights[b] != null) return raw.heights[b];
    const n = Math.min(BLOCK, viewCount() - b * BLOCK);
    const factor = raw.wrap && raw.measuredLines ? raw.measuredPx / (raw.measuredLines * LINE_H) : 1;
    return Math.round(n * LINE_H * Math.max(1, factor));
  }

  function renderBlock(b) {
    if (raw.rendered.has(b) || !raw.blocks[b]) return;
    const div = raw.blocks[b];
    div.innerHTML = blockHtml(b);
    div.style.height = "";
    raw.rendered.add(b);
    measureBlock(b);
    if (raw.source.ensure) fillFromDisk(b);
  }

  // Large-log mode: a block's lines are read from disk, then shown.
  function fillFromDisk(b) {
    const start = b * BLOCK;
    const end = Math.min(start + BLOCK, viewCount());
    const indices = [];
    for (let pos = start; pos < end; pos++) indices.push(lineAt(pos));
    if (indices.every(i => raw.source.has(i))) return;
    const token = raw.loadToken;
    raw.blocks[b].classList.add("loading");
    raw.source.ensure(indices).then(() => {
      if (token !== raw.loadToken || !raw.rendered.has(b)) return;
      raw.blocks[b].innerHTML = blockHtml(b);
      raw.blocks[b].classList.remove("loading");
      if (raw.wrap) {
        raw.heights[b] = undefined;
        measureBlock(b);
      }
      if (raw.current >= 0) setCurrentMarks(true);
    }).catch(() => {});
  }

  function measureBlock(b) {
    if (!raw.visible) return;
    const h = raw.blocks[b].offsetHeight;
    if (!h) return;
    if (raw.wrap && raw.heights[b] == null) {
      raw.measuredPx += h;
      raw.measuredLines += Math.min(BLOCK, viewCount() - b * BLOCK);
    }
    raw.heights[b] = h;
  }

  function unrenderBlock(b) {
    if (!raw.rendered.has(b)) return;
    const div = raw.blocks[b];
    div.style.height = `${estimateHeight(b)}px`;
    div.textContent = "";
    raw.rendered.delete(b);
  }

  function rerenderVisibleBlocks() {
    for (const b of raw.rendered) {
      raw.blocks[b].innerHTML = blockHtml(b);
      if (raw.wrap) {
        raw.heights[b] = undefined;
        measureBlock(b);
      }
    }
  }

  function resetMeasurements() {
    raw.heights = [];
    raw.measuredPx = 0;
    raw.measuredLines = 0;
  }

  function buildBlocks() {
    raw.observer?.disconnect();
    raw.rendered.clear();
    raw.blocks = [];
    resetMeasurements();

    const count = viewCount();
    els.content.replaceChildren();
    els.content.style.minWidth = raw.wrap
      ? ""
      : `calc(var(--raw-gutter) + ${Math.min(raw.maxLen, MIN_WIDTH_MAX_CH)}ch + 48px)`;

    if (!count) {
      const empty = document.createElement("div");
      empty.className = "raw-empty";
      empty.textContent = raw.onlyMatches && raw.result
        ? "No lines match the search. Clear the search or turn off “Only matching lines” to see the full log."
        : "The log is empty.";
      els.content.appendChild(empty);
      return;
    }

    raw.observer = new IntersectionObserver(entries => {
      // Wrapped blocks are often taller than estimated; if the user was at the
      // end of the log, keep them there once real heights are known.
      const sc = els.scroller;
      const atBottom = sc.scrollTop > 0 && sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4;
      for (const entry of entries) {
        const b = Number(entry.target.dataset.b);
        if (entry.isIntersecting) renderBlock(b);
        else unrenderBlock(b);
      }
      if (atBottom) sc.scrollTop = sc.scrollHeight;
    }, { root: els.scroller, rootMargin: "1600px 0px" });

    const fragment = document.createDocumentFragment();
    const nBlocks = Math.ceil(count / BLOCK);
    for (let b = 0; b < nBlocks; b++) {
      const div = document.createElement("div");
      div.className = "raw-block";
      div.dataset.b = String(b);
      div.style.height = `${estimateHeight(b)}px`;
      raw.blocks.push(div);
      fragment.appendChild(div);
    }
    els.content.appendChild(fragment);
    for (const div of raw.blocks) raw.observer.observe(div);
  }

  // Scrolls so that the display position is visible. align: "center" | "top".
  function revealPos(pos, align = "center") {
    if (pos < 0 || pos >= viewCount()) return null;
    const b = Math.floor(pos / BLOCK);
    renderBlock(b);
    const line = lineAt(pos);
    const lineEl = raw.blocks[b].querySelector(`.raw-line[data-line="${line}"]`);
    if (!lineEl) return null;
    const scroller = els.scroller;
    const sRect = scroller.getBoundingClientRect();
    const lRect = lineEl.getBoundingClientRect();
    const offset = lRect.top - sRect.top;
    scroller.scrollTop += align === "top" ? offset : offset - (scroller.clientHeight - lRect.height) / 2;
    return lineEl;
  }

  function scrollMarkIntoView(mark) {
    if (!mark || raw.wrap) return;
    const scroller = els.scroller;
    const sRect = scroller.getBoundingClientRect();
    const mRect = mark.getBoundingClientRect();
    const gutter = scroller.querySelector(".raw-line .ln")?.getBoundingClientRect().width || 0;
    const left = sRect.left + gutter + 24;
    const right = sRect.left + scroller.clientWidth - 24;
    if (mRect.left < left || mRect.right > right) {
      scroller.scrollLeft += mRect.left - (sRect.left + gutter + scroller.clientWidth * 0.3);
    }
  }

  function topVisibleLine() {
    if (!raw.rendered.size) return 0;
    const top = els.scroller.getBoundingClientRect().top;
    const blocks = [...raw.rendered].sort((a, b) => a - b);
    for (const b of blocks) {
      const div = raw.blocks[b];
      if (div.getBoundingClientRect().bottom <= top) continue;
      for (const lineEl of div.children) {
        if (lineEl.getBoundingClientRect().bottom > top) return Number(lineEl.dataset.line);
      }
    }
    return lineAt(0);
  }

  // Rebuild the view and try to keep the given line at the top.
  function rebuildKeepingLine(line) {
    buildBlocks();
    if (!viewCount()) return;
    let pos = posOfLine(line);
    if (pos < 0 && raw.viewLines) pos = Math.min(lowerBound(raw.viewLines, line), viewCount() - 1);
    if (pos < 0) pos = 0;
    els.scroller.scrollTop = 0;
    revealPos(pos, "top");
  }

  // ------------------------------------------------------------------ search

  function setStatus(text, tone = "") {
    els.status.textContent = text;
    els.status.className = `raw-search-status${tone ? ` ${tone}` : ""}`;
  }

  function updateStatus() {
    const r = raw.result;
    els.search.removeAttribute("aria-invalid");
    if (raw.error) {
      els.search.setAttribute("aria-invalid", "true");
      setStatus(raw.error, "bad");
    } else if (raw.searching) {
      return;
    } else if (!r) {
      setStatus("");
    } else if (!r.total) {
      setStatus("No matches", "warn");
    } else {
      const plus = r.totalCapped ? "+" : "";
      const position = raw.current >= 0 ? `${(raw.current + 1).toLocaleString()} of ` : "";
      let text = `${position}${r.total.toLocaleString()}${plus} matches on ${r.lineHits.length.toLocaleString()} lines`;
      if (r.storedCapped) text += ` · first ${S.MATCH_STORE_CAP.toLocaleString()} navigable`;
      setStatus(text);
    }
    const navigable = !!(r && r.matchLine.length);
    els.prev.disabled = !navigable;
    els.next.disabled = !navigable;
  }

  function clearStall() {
    clearTimeout(raw.stallTimer);
    raw.stallTimer = null;
  }

  function armStall(id) {
    clearStall();
    raw.stallTimer = setTimeout(() => {
      if (id !== raw.searchId) return;
      raw.worker?.terminate();
      raw.worker = null;
      raw.searching = false;
      raw.result = null;
      raw.re = null;
      raw.current = -1;
      raw.error = `Search stopped: no progress for ${STALL_MS / 1000} s. The regular expression is probably backtracking catastrophically on a long line. Simplify the pattern (avoid nested quantifiers such as (a+)+).`;
      applyResultToView(-1);
      updateStatus();
    }, STALL_MS);
  }

  function ensureWorker() {
    if (raw.worker) return true;
    if (raw.workerBroken || typeof Worker !== "function") return false;
    try {
      raw.worker = new Worker("raw-search-worker.js");
      raw.worker.onmessage = onWorkerMessage;
      raw.worker.onerror = event => {
        event.preventDefault?.();
        raw.worker?.terminate();
        raw.worker = null;
        raw.workerBroken = true;
        if (raw.searching) startSearch();
      };
      raw.worker.postMessage({ type: "load", blob: raw.source.getBlob(), stream: !!raw.source.stream });
      return true;
    } catch (_) {
      raw.workerBroken = true;
      return false;
    }
  }

  function onWorkerMessage(event) {
    const msg = event.data || {};
    // While the worker reads a large log, its heartbeats count as progress so
    // the stuck-regex watchdog does not fire.
    if (msg.type === "loading" || msg.type === "loaded") {
      if (raw.searching) {
        armStall(raw.searchId);
        if (msg.type === "loading") setStatus(`Preparing search… ${Math.round(msg.progress * 100)}%`);
      }
      return;
    }
    if (msg.id !== raw.searchId) return;
    if (msg.type === "progress") {
      armStall(msg.id);
      setStatus(`Searching… ${Math.round(msg.progress * 100)}%`);
    } else if (msg.type === "result") {
      clearStall();
      finishSearch(msg);
    }
  }

  function finishSearch(msg) {
    const topLine = raw.visible ? topVisibleLine() : 0;
    raw.searching = false;
    if (msg.error || msg.empty) {
      raw.error = msg.error || "";
      raw.result = null;
      raw.re = null;
      raw.current = -1;
    } else {
      raw.error = "";
      raw.result = msg;
      raw.re = S.compile(els.search.value, { regex: raw.regex, caseSensitive: raw.caseSensitive }).re;
      // Start at the first match at or below the current viewport, like an editor.
      const first = msg.matchLine.length ? lowerBound(msg.matchLine, topLine) : -1;
      raw.current = msg.matchLine.length ? (first < msg.matchLine.length ? first : 0) : -1;
    }
    applyResultToView(topLine);
    updateStatus();
    if (raw.current >= 0) revealMatch(raw.current);
  }

  function applyResultToView(topLine) {
    const nextView = raw.onlyMatches && raw.result ? raw.result.lineHits : null;
    if (nextView !== raw.viewLines) {
      raw.viewLines = nextView;
      if (raw.visible) rebuildKeepingLine(topLine);
      else raw.dirty = true;
    } else if (raw.visible) {
      rerenderVisibleBlocks();
    }
  }

  function fallbackSearch(id, re) {
    if (raw.source.stream) {
      finishSearch({ id, error: "Searching a large log needs the background search worker, which could not start." });
      return;
    }
    const search = S.createSearch(raw.source.lineCount, raw.source.getLine, re);
    const tick = () => {
      if (id !== raw.searchId) return;
      if (search.step(16)) {
        finishSearch({ id, ...search.result() });
      } else {
        setStatus(`Searching… ${Math.round(search.progress() * 100)}%`);
        setTimeout(tick, 0);
      }
    };
    tick();
  }

  function startSearch() {
    clearTimeout(raw.debounce);
    raw.debounce = null;
    clearStall();
    ensureLines();
    const id = ++raw.searchId;
    const query = els.search.value;
    const { re, error } = S.compile(query, { regex: raw.regex, caseSensitive: raw.caseSensitive });

    if (!query || error) {
      raw.worker?.postMessage({ type: "cancel" });
      raw.searching = false;
      const topLine = raw.visible ? topVisibleLine() : 0;
      raw.result = null;
      raw.re = null;
      raw.current = -1;
      raw.error = error ? `Invalid regular expression: ${error.replace(/^Invalid regular expression:\s*/i, "")}` : "";
      applyResultToView(topLine);
      updateStatus();
      return;
    }

    raw.searching = true;
    raw.error = "";
    setStatus("Searching…");
    if (ensureWorker()) {
      raw.worker.postMessage({ type: "search", id, query, regex: raw.regex, caseSensitive: raw.caseSensitive });
      armStall(id);
    } else {
      fallbackSearch(id, re);
    }
  }

  function scheduleSearch() {
    clearTimeout(raw.debounce);
    raw.debounce = setTimeout(startSearch, SEARCH_DEBOUNCE_MS);
  }

  function setCurrentMarks(on) {
    if (raw.current < 0 || !raw.result) return null;
    const line = raw.result.matchLine[raw.current];
    const s = raw.result.matchStart[raw.current];
    const lineEl = els.content.querySelector(`.raw-line[data-line="${line}"]`);
    if (!lineEl) return null;
    const marks = lineEl.querySelectorAll(`mark[data-s="${s}"]`);
    marks.forEach(mark => mark.classList.toggle("cur", on));
    return marks[0] || null;
  }

  function revealMatch(i) {
    if (!raw.result || i < 0 || i >= raw.result.matchLine.length) return;
    setCurrentMarks(false);
    raw.current = i;
    const pos = posOfLine(raw.result.matchLine[i]);
    if (pos < 0) return;
    revealPos(pos, "center");
    scrollMarkIntoView(setCurrentMarks(true));
    updateStatus();
  }

  function step(direction) {
    if (raw.searching || raw.debounce) return;
    const n = raw.result?.matchLine.length || 0;
    if (!n) return;
    revealMatch((raw.current + direction + n) % n);
  }

  // ------------------------------------------------------------------- lines

  function setTargetLine(index) {
    els.content.querySelectorAll(".raw-line.target").forEach(lineEl => lineEl.classList.remove("target"));
    raw.targetLine = index;
    const lineEl = els.content.querySelector(`.raw-line[data-line="${index}"]`);
    lineEl?.classList.add("target");
  }

  function goToLine(lineNumber) {
    ensureLines();
    const n = raw.source.lineCount;
    if (!n) return;
    const index = Math.min(n, Math.max(1, Math.round(lineNumber))) - 1;
    if (posOfLine(index) < 0 && raw.onlyMatches) {
      // The requested line is hidden by grep mode; show the full log instead.
      raw.onlyMatches = false;
      savePrefs();
      syncControls();
      raw.viewLines = null;
      buildBlocks();
    }
    raw.targetLine = index;
    revealPos(posOfLine(index), "center");
    setTargetLine(index);
  }

  // ------------------------------------------------------------------ events

  els.search.addEventListener("input", scheduleSearch);
  els.search.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      // Run a pending (debounced) search now; otherwise move between matches.
      if (raw.debounce || (els.search.value && !raw.result && !raw.searching && !raw.error)) {
        startSearch();
        return;
      }
      step(event.shiftKey ? -1 : 1);
    } else if (event.key === "Escape" && els.search.value) {
      event.preventDefault();
      event.stopPropagation();
      els.search.value = "";
      startSearch();
    }
  });

  els.regex.addEventListener("click", () => {
    raw.regex = !raw.regex;
    savePrefs();
    syncControls();
    startSearch();
  });

  els.caseSensitive.addEventListener("click", () => {
    raw.caseSensitive = !raw.caseSensitive;
    savePrefs();
    syncControls();
    startSearch();
  });

  els.prev.addEventListener("click", () => step(-1));
  els.next.addEventListener("click", () => step(1));

  els.onlyMatches.addEventListener("change", () => {
    const topLine = topVisibleLine();
    raw.onlyMatches = els.onlyMatches.checked;
    savePrefs();
    applyResultToView(topLine);
  });

  els.wrap.addEventListener("change", () => {
    const topLine = topVisibleLine();
    raw.wrap = els.wrap.checked;
    savePrefs();
    syncControls();
    if (raw.visible) rebuildKeepingLine(topLine);
    else raw.dirty = true;
    if (raw.current >= 0) setCurrentMarks(true);
  });

  els.goto.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    const value = Number(els.goto.value);
    if (Number.isFinite(value) && value >= 1) goToLine(value);
  });

  document.addEventListener("keydown", event => {
    if (!raw.visible) return;
    const mod = event.ctrlKey || event.metaKey;
    if (mod && !event.altKey && event.key.toLowerCase() === "f") {
      event.preventDefault();
      els.search.focus();
      els.search.select();
    } else if (event.key === "F3") {
      event.preventDefault();
      step(event.shiftKey ? -1 : 1);
    }
  });

  // Wrapped line heights depend on the panel width.
  if (typeof ResizeObserver === "function") {
    let frame = 0;
    new ResizeObserver(() => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const width = els.scroller.clientWidth;
        if (!raw.visible || !raw.wrap || width === raw.lastWidth) {
          raw.lastWidth = width;
          return;
        }
        raw.lastWidth = width;
        resetMeasurements();
        for (const b of raw.rendered) measureBlock(b);
        raw.blocks.forEach((div, b) => {
          if (!raw.rendered.has(b)) div.style.height = `${estimateHeight(b)}px`;
        });
      });
    }).observe(els.scroller);
  }

  // --------------------------------------------------------------------- API

  function load(source, markerSpec) {
    raw.loadToken = (raw.loadToken || 0) + 1;
    raw.source = source || EMPTY_SOURCE;
    raw.markerSpec = markerSpec || null;
    raw.prepared = false;
    raw.markers = null;
    raw.result = null;
    raw.re = null;
    raw.current = -1;
    raw.error = "";
    raw.searching = false;
    raw.viewLines = null;
    raw.targetLine = -1;
    raw.searchId++;
    clearStall();
    raw.dirty = true;
    // A running worker gets the new log; otherwise it is created on first search.
    raw.worker?.postMessage({ type: "load", blob: raw.source.getBlob(), stream: !!raw.source.stream });
    els.goto.value = "";
    if (raw.visible) show();
    else updateStatus();
  }

  function show() {
    raw.visible = true;
    els.panel.hidden = false;
    ensureLines();
    els.goto.max = String(raw.source.lineCount);
    if (raw.dirty) {
      raw.dirty = false;
      raw.lastWidth = els.scroller.clientWidth;
      buildBlocks();
      if (els.search.value && !raw.result && !raw.searching) startSearch();
    } else if (raw.wrap && els.scroller.clientWidth !== raw.lastWidth) {
      rebuildKeepingLine(topVisibleLine());
    }
    updateStatus();
  }

  function hide() {
    raw.visible = false;
    els.panel.hidden = true;
  }

  function showLine(lineNumber) {
    if (!raw.visible) show();
    goToLine(lineNumber);
    els.scroller.focus({ preventScroll: true });
  }

  loadPrefs();
  syncControls();

  globalThis.BTLV_RAW = Object.freeze({
    load,
    show,
    hide,
    showLine,
    isVisible: () => raw.visible
  });
})();
