/*
 * Browsertrix Crawl Log Viewer - loading-card content
 *
 * Short "good to know" cards shown while a crawl log loads. Edit freely:
 * each card is { cat, title, text, link? }. Limits (checked by the tests):
 * title at most 60 characters, text at most 240, link must be https.
 * Categories control the card's label and symbol (see CATEGORY_INFO).
 */
(() => {
  const CATEGORY_INFO = {
    precrawl: { label: "Pre-crawl assessment", icon: "🔎" },
    robots: { label: "robots.txt", icon: "🤖" },
    sitemaps: { label: "Sitemaps", icon: "🗺️" },
    http: { label: "HTTP", icon: "🌐" },
    scope: { label: "Scope & seeds", icon: "🎯" },
    heritrix: { label: "Heritrix", icon: "🕷️" },
    browsertrix: { label: "Browsertrix", icon: "🧭" },
    behaviors: { label: "Behaviors", icon: "🖱️" },
    selectors: { label: "CSS selectors", icon: "🧩" },
    warc: { label: "WARC & WACZ", icon: "📦" },
    qa: { label: "QA & replay", icon: "✅" },
    webtech: { label: "Web technology", icon: "⚙️" },
    practice: { label: "Good practice", icon: "🌱" },
    viewer: { label: "About this viewer", icon: "💡" }
  };

  const TIPS = [
    // ---------------------------------------------------------------- pre-crawl
    { cat: "precrawl", title: "Look before you crawl", text: "Five minutes in a normal browser tells you a lot: does content load with JavaScript off, is there infinite scroll, a login wall or a cookie wall? Choose the crawler and settings from what you see." },
    { cat: "precrawl", title: "Test the 404 page", text: "Request a URL that cannot exist. If the site answers 200 instead of 404, it serves soft 404s, and a crawl may fill up with copies of an error page." },
    { cat: "precrawl", title: "Check for a WAF first", text: "Cloudflare, Akamai or Azure Front Door in front of a site can challenge or block crawlers. Check response headers and a test fetch before planning a large crawl." },
    { cat: "precrawl", title: "Server-rendered or JavaScript?", text: "View the page source (not the inspector). If the text you need is there, a classic crawler like Heritrix may be enough. If it only appears after scripts run, use a browser-based crawler." },
    { cat: "precrawl", title: "Estimate size with a sample", text: "A short sample crawl with a page limit tells you more about real size, traps and errors than any guess. Pause it, inspect the log and replay, then decide." },
    { cat: "precrawl", title: "Find the site’s own APIs", text: "Open the browser’s network panel while browsing. JSON calls behind the page often reveal pagination, IDs and hidden content that links alone never show." },
    { cat: "precrawl", title: "Look for downloadable exports", text: "Some sites offer data dumps, RSS feeds or bulk exports. For preservation, these can be a valuable complement to a crawl, not a replacement for it." },
    { cat: "precrawl", title: "Note the site’s timezone", text: "Dates on pages, in sitemaps and in HTTP headers may use different timezones. Archives record UTC; keep that in mind when you compare crawl times with site events." },

    // ---------------------------------------------------------------- robots.txt
    { cat: "robots", title: "robots.txt has a standard", text: "Since 2022 the Robots Exclusion Protocol is RFC 9309. It defines groups by user agent, Allow and Disallow rules, and how crawlers must handle errors.", link: "https://www.rfc-editor.org/rfc/rfc9309.html" },
    { cat: "robots", title: "One robots.txt per host", text: "robots.txt applies only to the exact scheme, host and port it is served from. www.example.org and example.org each have their own file.", link: "https://www.rfc-editor.org/rfc/rfc9309.html" },
    { cat: "robots", title: "The most specific rule wins", text: "Under RFC 9309 the rule with the longest matching path applies. If an Allow and a Disallow match equally, Allow wins.", link: "https://www.rfc-editor.org/rfc/rfc9309.html" },
    { cat: "robots", title: "Server errors mean “stay out”", text: "If robots.txt returns a server error (5xx), RFC 9309 says crawlers must assume everything is disallowed. A 404 for robots.txt means everything is allowed.", link: "https://www.rfc-editor.org/rfc/rfc9309.html" },
    { cat: "robots", title: "Crawl-delay is not in the RFC", text: "Crawl-delay is a widely used extension, but RFC 9309 does not define it. Crawlers treat it differently; Heritrix can respect it up to a configurable limit." },
    { cat: "robots", title: "robots.txt can point to sitemaps", text: "Many sites list their sitemaps in robots.txt with “Sitemap:” lines. It is often the quickest way to find them, even when the sitemap URL is unusual." },
    { cat: "robots", title: "meta robots is about indexing", text: "<meta name=\"robots\" content=\"noindex\"> and the X-Robots-Tag header tell search engines what to index. They are not crawl rules; check your institution’s policy on how to treat them." },
    { cat: "robots", title: "Know your mandate", text: "Legal deposit and archival mandates may let an institution crawl content that robots.txt excludes. Follow your own policy, and document the decision for each case." },

    // ---------------------------------------------------------------- sitemaps
    { cat: "sitemaps", title: "Sitemap limits", text: "One sitemap file may hold at most 50,000 URLs and 50 MB uncompressed. Bigger sites split their URLs over several files listed in a sitemap index.", link: "https://www.sitemaps.org/protocol.html" },
    { cat: "sitemaps", title: "Sitemap indexes nest", text: "A sitemap index lists other sitemaps, not pages. Follow the index to all child sitemaps; some are gzip-compressed (.xml.gz).", link: "https://www.sitemaps.org/protocol.html" },
    { cat: "sitemaps", title: "Sitemaps are hints", text: "A sitemap lists what the site owner wants found, not everything that exists. Pages missing from it may still be reachable by links, and listed pages may be gone." },
    { cat: "sitemaps", title: "lastmod is useful, if honest", text: "The lastmod date can steer re-crawls to changed pages. Some sites set it to “now” on every request; compare several fetches before trusting it.", link: "https://www.sitemaps.org/protocol.html" },
    { cat: "sitemaps", title: "Sitemaps reveal structure", text: "Sitemap file names often mirror the site’s sections (news, products, archive years). They are a quick map of what the site contains and how big each part is." },
    { cat: "sitemaps", title: "Seed from a sitemap", text: "Crawling URLs from a sitemap catches pages that are hard to reach by links, such as deep archive pages. Combine it with link discovery for best coverage." },

    // ---------------------------------------------------------------- HTTP
    { cat: "http", title: "301 and 308 are permanent", text: "301 and 308 mean a permanent move; 302 and 307 a temporary one. 307 and 308 keep the request method, so a POST stays a POST.", link: "https://www.rfc-editor.org/rfc/rfc9110.html#name-redirection-3xx" },
    { cat: "http", title: "429 means slow down", text: "429 Too Many Requests is the server asking for fewer requests. Look for a Retry-After header, and lower the crawl rate rather than retrying harder.", link: "https://www.rfc-editor.org/rfc/rfc6585.html#section-4" },
    { cat: "http", title: "503 can be a soft block", text: "503 Service Unavailable may be a real outage, maintenance, or a protection system holding back crawlers. Several 503s in a row on a healthy site are a warning sign." },
    { cat: "http", title: "410 Gone is honest", text: "410 means the content was removed on purpose and will not return. It is a useful signal when you track what disappears from a site over time.", link: "https://www.rfc-editor.org/rfc/rfc9110.html#name-410-gone" },
    { cat: "http", title: "451: unavailable for legal reasons", text: "Status 451 means content is blocked for legal reasons, such as a court order. It is worth recording, as it documents why something could not be archived.", link: "https://www.rfc-editor.org/rfc/rfc7725.html" },
    { cat: "http", title: "206 means part of a file", text: "206 Partial Content answers a Range request with only part of a file. Media players use it a lot; archives must store enough to replay the whole file." },
    { cat: "http", title: "304 saves bandwidth", text: "A conditional request with If-None-Match or If-Modified-Since gets 304 Not Modified when nothing changed. Re-crawls can use this to skip unchanged files." },
    { cat: "http", title: "Content-Type can lie", text: "Servers sometimes send the wrong Content-Type, for example text/html for a PDF. Browsers sniff the real type; archive tools and analyses should not trust the header blindly." },
    { cat: "http", title: "Vary changes the response", text: "The Vary header says the response depends on request headers such as Accept-Language or User-Agent. The same URL can then return different content to different crawlers." },
    { cat: "http", title: "Encoding vs. transfer", text: "Content-Encoding (like gzip) belongs to the content; Transfer-Encoding (like chunked) only to the delivery. WARC records keep the response as received." },
    { cat: "http", title: "HTTP/2 and HTTP/3 look different", text: "Browsers speak HTTP/2 or HTTP/3 to many sites. Archives still record the exchange in an HTTP/1.1-style form, so the recorded headers are a representation, not a byte copy." },
    { cat: "http", title: "Canonical links show the main URL", text: "<link rel=\"canonical\"> names the preferred URL for a page. It helps spot duplicates created by tracking parameters or session IDs." },
    { cat: "http", title: "Query strings can explode", text: "Calendars, filters and sort options can create endless URL variations. Watch the crawl log for one path repeated with ever-changing query strings: that is a crawler trap." },

    // ---------------------------------------------------------------- scope & seeds
    { cat: "scope", title: "Seeds are where crawls start", text: "A seed is a starting URL. The scope decides which discovered links are followed. A good seed list plus a clear scope beats a huge seed list with a vague scope." },
    { cat: "scope", title: "Prefix scope is often right", text: "Limiting a crawl to everything under one URL path (a prefix) keeps it focused on a section of a site, such as /news/, without pulling in the whole domain." },
    { cat: "scope", title: "Watch subdomains", text: "Content often lives on other subdomains: media.example.org, cdn.example.org, blog.example.org. Decide deliberately whether they are in scope." },
    { cat: "scope", title: "Embeds vs. links", text: "Embedded resources (images, CSS, scripts) are needed to render a page and are usually fetched even outside scope. Linked pages are only followed when in scope." },
    { cat: "scope", title: "Extra hops add context", text: "Allowing one extra hop outside scope captures the pages your site links to, without crawling those sites further. Use it sparingly; it can grow a crawl quickly." },
    { cat: "scope", title: "Exclude crawler traps early", text: "Calendars, faceted search and print versions can create endless URLs. Add exclusion rules for them before the crawl, not after the budget is spent." },
    { cat: "scope", title: "Test regexes on real URLs", text: "Before using an include or exclude regex in a crawl, test it against a list of real URLs from the site. One missing escape (\\.) can include far more than intended." },
    { cat: "scope", title: "Normalize, don’t duplicate", text: "The same page can appear with different URLs: http/https, www or not, trailing slash, tracking parameters. Know which variants your crawler treats as the same." },
    { cat: "scope", title: "Limits are safety nets", text: "Page, size and time limits stop runaway crawls. Set them generously enough for the real site, and check afterwards whether a crawl stopped because a limit was hit." },

    // ---------------------------------------------------------------- Heritrix
    { cat: "heritrix", title: "Heritrix is configured in Spring", text: "A Heritrix job is described in crawler-beans.cxml, a Spring configuration. Scope, politeness, extractors and writers are all beans you can adjust per job.", link: "https://heritrix.readthedocs.io/" },
    { cat: "heritrix", title: "Decide rules: the last one wins", text: "Heritrix scope is a sequence of decide rules. Each rule may accept, reject or pass; the last rule that does not pass decides whether a URL is in scope.", link: "https://heritrix.readthedocs.io/" },
    { cat: "heritrix", title: "SURTs sort URLs by host", text: "Heritrix uses SURT form, which reverses the host: http://(org,example,www,)/path. It groups a domain’s hosts together and makes prefix rules easy to write." },
    { cat: "heritrix", title: "Politeness is per queue", text: "Heritrix keeps one queue per host by default and waits between requests to the same queue. Delay settings scale the wait with how long the last fetch took." },
    { cat: "heritrix", title: "Read the hop path", text: "In Heritrix logs the hop path shows how a URL was found: L for a link, E for an embed, R for a redirect, X for a speculative find, P for a prerequisite such as robots.txt." },
    { cat: "heritrix", title: "Negative status codes", text: "In Heritrix’s crawl.log a negative status means no HTTP response was obtained. For example, -9998 means the URL was blocked by robots.txt." },
    { cat: "heritrix", title: "DNS lookups are logged too", text: "Heritrix fetches DNS records as dns: URIs before contacting a host. They appear in crawl.log, and a failed lookup explains why a whole host was never crawled." },
    { cat: "heritrix", title: "Speculative links can be junk", text: "Heritrix guesses URLs from JavaScript strings. This finds hidden resources but also creates nonsense URLs; check how many X-hop URLs end in 404." },
    { cat: "heritrix", title: "Checkpoints for long crawls", text: "Heritrix can write checkpoints so a long crawl can be resumed after a crash or restart. Take them before risky changes to a running job." },
    { cat: "heritrix", title: "Heritrix does not run JavaScript", text: "Heritrix fetches and parses what the server sends; it does not execute scripts. Content that only appears through JavaScript needs a browser-based crawler." },
    { cat: "heritrix", title: "Budgets keep queues fair", text: "Queue budgets limit how much one host may consume. They stop a single huge host from swallowing a broad crawl at the expense of thousands of small ones." },
    { cat: "heritrix", title: "NetarchiveSuite runs Heritrix", text: "NetarchiveSuite schedules and distributes Heritrix harvests, from selective crawls to national broad crawls, and keeps per-domain limits and harvest history.", link: "https://github.com/netarchivesuite/netarchivesuite" },

    // ---------------------------------------------------------------- Browsertrix
    { cat: "browsertrix", title: "A real browser does the crawling", text: "Browsertrix Crawler loads pages in Chromium and records all network traffic. Whatever the browser fetches, including script-loaded content, ends up in the WARC.", link: "https://crawler.docs.browsertrix.com/" },
    { cat: "browsertrix", title: "Scope types to know", text: "Browsertrix Crawler scopes include page, page-spa, prefix, host, domain, any and custom. Pick the narrowest one that still covers what you need.", link: "https://crawler.docs.browsertrix.com/user-guide/crawl-scope/" },
    { cat: "browsertrix", title: "Debug logging tells more", text: "Crawling with --logging debug adds resource statuses, memory telemetry and page timestamps to the log. The log grows a lot, but analysis gets much richer." },
    { cat: "browsertrix", title: "Fewer browser windows, fewer blocks", text: "Sites that rate-limit react to many parallel requests. Running fewer browser windows plus a delay between pages often avoids blocks, at the cost of speed." },
    { cat: "browsertrix", title: "Browser profiles for logins", text: "A browser profile stores a logged-in session. Use one for sites that need a login, and keep it up to date; an expired session silently crawls logged-out pages.", link: "https://docs.browsertrix.com/user-guide/browser-profiles/" },
    { cat: "browsertrix", title: "Pause a crawl to test it", text: "In Browsertrix you can pause a crawl, inspect replay and logs, adjust settings and resume. It is an efficient way to run a test crawl on a large site." },
    { cat: "browsertrix", title: "Linked files become “pages”", text: "When a page links to a PDF or video, Browsertrix may crawl it as a page of its own. It is fetched directly, not rendered, and appears in the pages list." },
    { cat: "browsertrix", title: "Screenshots are optional", text: "Browsertrix can store view, thumbnail and full-page screenshots in the WARC. They help QA, but they are created by the crawler, not content from the site." },
    { cat: "browsertrix", title: "Extracted text can be saved", text: "Browsertrix can extract page text into the archive. It is useful for full-text search and QA comparison without re-rendering every page." },
    { cat: "browsertrix", title: "Crawls end in WACZ files", text: "Browsertrix packages each crawl as one or more WACZ files: WARCs plus indexes, a page list and logs. Large crawls are split into several WACZ files." },
    { cat: "browsertrix", title: "Rate-limited is a crawl state", text: "Browsertrix can detect when a crawl is being rate-limited and pause it automatically after a while, so you can adjust settings instead of archiving error pages.", link: "https://docs.browsertrix.com/user-guide/running-crawl/" },
    { cat: "browsertrix", title: "Deduplication saves storage", text: "With deduplication, a crawl can reference identical content already in a collection using revisit records, instead of storing it again.", link: "https://docs.browsertrix.com/user-guide/deduplication/" },

    // ---------------------------------------------------------------- behaviors
    { cat: "behaviors", title: "Behaviors make pages move", text: "Behaviors are scripts the crawler runs on each page: scrolling, playing media, clicking. They capture content that only appears after interaction.", link: "https://crawler.docs.browsertrix.com/user-guide/behaviors/" },
    { cat: "behaviors", title: "Built-in behaviors", text: "Browsertrix includes autoscroll, autoplay, autofetch, autoclick and site-specific behaviors for some social media sites. Enable only what a site needs." },
    { cat: "behaviors", title: "Autoclick takes a selector", text: "Autoclick clicks matching elements without leaving the page. By default it clicks links; give it a CSS selector to click “Load more” buttons instead." },
    { cat: "behaviors", title: "Custom behaviors in JavaScript", text: "A custom behavior is a class with an id, an isMatch test for which pages it applies to, and a run method that performs the actions step by step.", link: "https://crawler.docs.browsertrix.com/user-guide/behaviors/#creating-custom-behaviors" },
    { cat: "behaviors", title: "Record a behavior, no code", text: "Chrome DevTools Recorder can record your clicks as a JSON user flow. Browsertrix can replay such a flow as a behavior while crawling." },
    { cat: "behaviors", title: "Give behaviors time", text: "A behavior that is stopped by its timeout leaves content uncaptured. Check the log for behavior timeouts on pages with long feeds or galleries." },
    { cat: "behaviors", title: "Behaviors log what they do", text: "Behaviors write messages to the crawl log. A missing “done” message, or many errors, shows a behavior that did not work on that page." },
    { cat: "behaviors", title: "Test behaviors on a few pages", text: "Run a new behavior on a handful of URLs first and check replay. A behavior that clicks the wrong element can make every page in a crawl worse." },

    // ---------------------------------------------------------------- selectors
    { cat: "selectors", title: "Test selectors in DevTools", text: "In the browser console, $$(\"selector\") returns all matching elements. Test a selector there before putting it into a behavior or crawl setting." },
    { cat: "selectors", title: "Match file links by ending", text: "a[href$=\".pdf\"] matches links ending in .pdf. [href^=\"https://\"] matches a prefix, and [href*=\"download\"] matches anywhere in the value." },
    { cat: "selectors", title: "Avoid generated class names", text: "Class names like css-1x9k2ab change with every deployment. Prefer stable hooks: IDs, data-* attributes, aria-labels or the element structure." },
    { cat: "selectors", title: ":has() selects by content", text: "article:has(video) matches articles containing a video. :has() is supported in current browsers and is very handy for targeting the right container." },
    { cat: "selectors", title: ":not() narrows a match", text: "button:not([disabled]) skips disabled buttons. Combine :not() with attributes to avoid clicking things a behavior should leave alone." },
    { cat: "selectors", title: "Combinators describe structure", text: "“A B” finds B anywhere inside A, “A > B” only direct children, “A + B” the next sibling and “A ~ B” any later sibling." },
    { cat: "selectors", title: "Select by data attributes", text: "Modern sites mark elements with data-* attributes, like [data-testid=\"load-more\"]. They are often more stable than visible text or classes." },
    { cat: "selectors", title: "XPath when CSS is not enough", text: "CSS cannot select by visible text. XPath can: //button[contains(., 'Load more')]. In DevTools, test it with $x(\"…\")." },

    // ---------------------------------------------------------------- WARC & WACZ
    { cat: "warc", title: "WARC is an ISO standard", text: "WARC 1.1 is ISO 28500:2017. It stores requests, responses and metadata as records, so an archive keeps exactly what was exchanged with the server.", link: "https://iipc.github.io/warc-specifications/" },
    { cat: "warc", title: "WARC record types", text: "warcinfo, request, response, resource, metadata, revisit, conversion and continuation. Most of a crawl is request and response records." },
    { cat: "warc", title: "Revisits avoid duplicates", text: "A revisit record says “same content as an earlier capture” instead of storing the payload again. Replay needs the earlier record to be available." },
    { cat: "warc", title: "Per-record gzip", text: "WARC files are compressed one record at a time. That is why a .warc.gz can be read at any record offset without decompressing the whole file." },
    { cat: "warc", title: "Payload digests catch changes", text: "WARC-Payload-Digest holds a hash of the content. Identical digests across crawls mean unchanged content, which is the basis for deduplication." },
    { cat: "warc", title: "WACZ bundles a whole crawl", text: "A WACZ file is a ZIP with WARCs, a CDXJ index, a pages list, logs and a datapackage.json with checksums. It can be replayed directly in the browser.", link: "https://specs.webrecorder.net/wacz/latest/" },
    { cat: "warc", title: "CDXJ is the lookup index", text: "A CDXJ index lists each capture by SURT URL and timestamp, with JSON details such as offset and length. Replay tools use it to find records fast." },
    { cat: "warc", title: "pages.jsonl lists the pages", text: "Inside a WACZ, pages/pages.jsonl lists the crawl’s pages with URL, title and timestamp. It is the quickest way to see what a crawl regarded as pages." },
    { cat: "warc", title: "Never edit WARCs in place", text: "Treat WARC files as evidence: never modify them. If records need correcting, write new files and document the relationship." },

    // ---------------------------------------------------------------- QA & replay
    { cat: "qa", title: "Replay is the real test", text: "A crawl log can look clean while replay is broken. Always open a sample of pages in replay, including deep pages, not just the home page." },
    { cat: "qa", title: "Check the network panel in replay", text: "Open DevTools during replay: requests for resources that were never captured show up as errors. They point to missed embeds and scripts." },
    { cat: "qa", title: "Leaks to the live web", text: "If replay quietly loads resources from the live web, the archive looks complete when it is not. Test replay offline or with live-web blocking." },
    { cat: "qa", title: "Compare screenshots", text: "Comparing a crawl-time screenshot with a replay screenshot quickly shows missing styles, images or blocked content. Browsertrix QA automates this." },
    { cat: "qa", title: "Sample, don’t check everything", text: "For large crawls, check a structured sample: each section, each page type, and pages with the most warnings. Record what you checked and what you found." },
    { cat: "qa", title: "Memento links time and URL", text: "Memento (RFC 7089) lets clients ask an archive for a page as it was at a given time, using TimeGates and TimeMaps.", link: "https://www.rfc-editor.org/rfc/rfc7089.html" },
    { cat: "qa", title: "pywb and ReplayWeb.page", text: "pywb is a server-side wayback machine; ReplayWeb.page replays WACZ and WARC files entirely in the browser with a service worker." },
    { cat: "qa", title: "Fuzzy matching in replay", text: "Replay tools match requests that differ only in timestamps or random parameters to captured URLs. It explains why some pages work despite changing URLs." },

    // ---------------------------------------------------------------- web technology
    { cat: "webtech", title: "Single-page apps change the URL", text: "SPAs swap content with JavaScript and update the address with history.pushState. A link-only crawler may see one page where users see hundreds." },
    { cat: "webtech", title: "Lazy loading needs scrolling", text: "Images with loading=\"lazy\" or IntersectionObserver only load when scrolled into view. Without scrolling, the archive misses them." },
    { cat: "webtech", title: "srcset picks one image", text: "With srcset, the browser chooses one image size for its screen. The archive may only hold that size, so replay on another screen can miss images." },
    { cat: "webtech", title: "Infinite scroll hides content", text: "Feeds that load more items as you scroll need a scrolling behavior and enough time. Pagination links, if they exist, are more reliable." },
    { cat: "webtech", title: "WebSockets are hard to archive", text: "Live updates over WebSockets are not recorded as ordinary requests and usually cannot be replayed. Look for an HTTP fallback or an API." },
    { cat: "webtech", title: "POST requests and replay", text: "Content loaded with POST requests, such as GraphQL APIs, is harder to replay because the request body matters. Check these pages specifically in QA." },
    { cat: "webtech", title: "Service workers on live sites", text: "Some sites install service workers that cache and rewrite requests. They can change what a crawler sees on repeat visits; start crawls with a clean profile." },
    { cat: "webtech", title: "Cookie banners get archived", text: "Consent banners may cover the content in every capture. Some crawls use a browser profile where consent was already given; follow your own policy." },
    { cat: "webtech", title: "CSS can load more files", text: "Background images and web fonts are referenced in CSS files, not in the HTML. Crawlers must parse CSS to find them." },
    { cat: "webtech", title: "Streaming video comes in pieces", text: "HLS and DASH video arrives as a playlist plus many small segments. Capturing one quality level fully is better than many levels partly." },
    { cat: "webtech", title: "iframes are separate pages", text: "Embedded maps, videos and widgets often load in iframes from other domains. They need to be captured too, or replay shows empty boxes." },
    { cat: "webtech", title: "Bot challenges serve fake pages", text: "A JavaScript challenge or CAPTCHA page often returns 200 or 403 with a short HTML body. Many identical small pages in a crawl are a sign of blocking." },

    // ---------------------------------------------------------------- good practice
    { cat: "practice", title: "Identify your crawler", text: "Use a user agent that names your institution and links to a page about your crawling. Site owners can then contact you instead of blocking you." },
    { cat: "practice", title: "Be polite", text: "Spread requests over time and respect signs of overload. A crawl that takes a site down harms the site and the reputation of web archiving." },
    { cat: "practice", title: "Document decisions", text: "Write down why a site was crawled, with which scope and settings, and what was excluded. Future curators and researchers will need that context." },
    { cat: "practice", title: "Keep the crawl log", text: "The crawl log is the provenance of the archive: what was fetched, when, and what went wrong. Store it with the WARCs." },
    { cat: "practice", title: "Crawl before it’s gone", text: "Announced shutdowns rarely come with much warning. Keep an eye on shutdown watch lists and crawl important sites well before the deadline." },
    { cat: "practice", title: "Respect personal data", text: "Logged-in areas and user profiles may hold personal data. Crawl them only with a clear mandate and follow your institution’s data-protection rules." },
    { cat: "practice", title: "Re-crawl to see change", text: "Repeated captures show how a site evolves. A schedule that matches how often a site changes is more valuable than one perfect snapshot." },
    { cat: "practice", title: "Share what works", text: "Behaviors, scope rules and tips for hard sites help others. The web-archiving community (IIPC, Webrecorder, forums) thrives on shared experience." },

    // ---------------------------------------------------------------- this viewer
    { cat: "viewer", title: "These cards appear while loading", text: "These tips are shown while a crawl log loads. Click Next for another, or turn them off in the extension’s Settings under “While a crawl log loads”." },
    { cat: "viewer", title: "Search the raw log with regex", text: "In the Raw log tab, press .* to search with a regular expression and Aa to match case. Enter and Shift+Enter jump between matches." },
    { cat: "viewer", title: "Show only matching lines", text: "In the Raw log tab, “Only matching lines” works like grep: it hides everything else but keeps the original line numbers." },
    { cat: "viewer", title: "Jump from table to raw line", text: "Open a row’s fields button and click “Show source line … in raw log” to see exactly where the event is in the original log." },
    { cat: "viewer", title: "Move columns around", text: "Drag a column header left or right to reorder the table, or focus a header and press Alt+←/→. Columns can be moved but never hidden." },
    { cat: "viewer", title: "Totals follow your filters", text: "The totals line under the filters counts unique resources, known sizes, average and median for whatever is currently filtered." },
    { cat: "viewer", title: "Crawler-made items", text: "Screenshots, extracted text and page info are created by the crawler itself. The viewer groups them as “Crawler-made” and never counts them as site content." },
    { cat: "viewer", title: "Run the soft-404 test", text: "The soft-404 test asks the first seed’s host for a page that cannot exist. If it answers 200, similar-looking resources are marked SOFT404? for review." },
    { cat: "viewer", title: "Provenance is labelled honestly", text: "The viewer shows where URLs came from: EXACT when the log says so, INFERRED when timing suggests it, and never presents a guess as a fact." },
    { cat: "viewer", title: "Gemini Nano stays on your computer", text: "The optional Gemini Nano report runs on-device in Chrome. It receives a short fact summary, never the raw log or your login token." },
    { cat: "viewer", title: "Connect several Browsertrix sites", text: "Settings accepts several Browsertrix addresses, for example test and production. Download Logs is caught on every address you add." },
    { cat: "viewer", title: "The login token never leaves", text: "The token in Browsertrix’s log link is kept only in memory and deleted the moment the log is fetched. It is never stored, logged or shown." },
    { cat: "viewer", title: "Big logs stay responsive", text: "Large logs are read and parsed in small slices while they download, so the page keeps responding. Even logs of several hundred MB load." },
    { cat: "viewer", title: "Debug logs give richer analysis", text: "Crawls logged at debug level include memory figures and every page’s HTTP status. The diagnostics and charts get much more to work with." },
    { cat: "viewer", title: "Download the raw log", text: "“Download raw log” saves the original log file exactly as loaded, ready for your own scripts, grep or archiving." },
    { cat: "viewer", title: "Read the guide", text: "The Guide button explains every column, filter and finding, including the caveats that matter when you interpret a crawl log." }
  ];

  globalThis.BTLV_CARD_DATA = Object.freeze({ CATEGORY_INFO, TIPS });
})();
