/*
 * Browsertrix Crawl Log Viewer - raw log search worker
 *
 * Runs searches off the main thread so a slow regular expression cannot freeze
 * the viewer. The log arrives as a Blob (for a local file: the file itself, so
 * nothing is copied up front) and is read into the worker's own LineStore, so
 * no single giant string is ever built here either.
 *
 * Work is time-sliced: between slices the worker yields, which lets a newer
 * search request supersede the running one. It posts progress after every
 * slice; the page treats a long silence as a stuck regex (catastrophic
 * backtracking on a single line) and terminates the worker.
 */
importScripts("line-store.js", "raw-search-core.js");

const { compile, createSearch } = self.BTLV_RAW_SEARCH;
const { LineStore, storeFromBlob } = self.BTLV_LINES;

let store = new LineStore();
let ready = Promise.resolve();
let activeId = 0;
// Large-log mode: the log stays on disk; every search streams the file.
let streamBlob = null;

function yieldToMessages() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

// Streams the log from disk and searches it line by line, keeping only the
// results (same caps and result format as createSearch). detailsOnly: test
// only the part of each line after "details" (the table's search semantics).
async function streamSearch(id, re, detailsOnly) {
  const S = self.BTLV_RAW_SEARCH;
  const reader = streamBlob.stream().getReader();
  const decoder = new TextDecoder("utf-8", { fatal: false });
  const lineHits = [];
  const matchLine = [];
  const matchStart = [];
  const matchEnd = [];
  let total = 0;
  let totalCapped = false;
  let index = 0;
  let carry = "";
  let bytes = 0;
  const scratch = [];
  const size = streamBlob.size || 1;
  let lastPost = 0;

  const testLine = line => {
    if (detailsOnly) {
      const at = line.indexOf('"details"');
      if (at >= 0) line = line.slice(at + 9);
    }
    if (totalCapped) {
      re.lastIndex = 0;
      if (re.test(line)) lineHits.push(index);
    } else {
      scratch.length = 0;
      S.matchesInLine(re, line, scratch, S.MATCH_COUNT_CAP - total + 1);
      if (scratch.length) {
        lineHits.push(index);
        for (const [a, b] of scratch) {
          if (matchLine.length < S.MATCH_STORE_CAP) {
            matchLine.push(index);
            matchStart.push(a);
            matchEnd.push(b);
          }
        }
        total += scratch.length;
        if (total > S.MATCH_COUNT_CAP) {
          total = S.MATCH_COUNT_CAP;
          totalCapped = true;
        }
      }
    }
    index++;
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    bytes += value.byteLength;
    const text = carry + decoder.decode(value, { stream: true });
    let pos = 0;
    let nl;
    while ((nl = text.indexOf("\n", pos)) !== -1) {
      let line = text.slice(pos, nl);
      if (line.endsWith("\r")) line = line.slice(0, -1);
      testLine(line);
      pos = nl + 1;
    }
    carry = text.slice(pos);
    const now = Date.now();
    if (now - lastPost > 200) {
      lastPost = now;
      self.postMessage({ type: "progress", id, progress: bytes / size });
      await yieldToMessages();
      if (activeId !== id) {
        reader.cancel().catch(() => {});
        return null;
      }
    }
  }
  const rest = carry + decoder.decode();
  if (rest) testLine(rest);
  return {
    lineHits: Int32Array.from(lineHits),
    matchLine: Int32Array.from(matchLine),
    matchStart: Int32Array.from(matchStart),
    matchEnd: Int32Array.from(matchEnd),
    total,
    totalCapped,
    storedCapped: total > matchLine.length
  };
}

async function runSearch({ id, query, regex, caseSensitive, detailsOnly }) {
  activeId = id;
  await ready;
  if (activeId !== id) return;
  const { re, error } = compile(query, { regex, caseSensitive });
  if (!re) {
    self.postMessage({ type: "result", id, error, empty: !error });
    return;
  }
  if (streamBlob) {
    const result = await streamSearch(id, re, !!detailsOnly);
    if (!result) return; // superseded
    self.postMessage(
      { type: "result", id, ...result },
      [result.lineHits.buffer, result.matchLine.buffer, result.matchStart.buffer, result.matchEnd.buffer]
    );
    return;
  }

  const lines = store;
  const search = createSearch(lines.length, i => lines.getLine(i), re);
  while (!search.step(40)) {
    self.postMessage({ type: "progress", id, progress: search.progress() });
    await yieldToMessages();
    if (activeId !== id) return; // superseded by a newer request
  }

  const result = search.result();
  self.postMessage(
    { type: "result", id, ...result },
    [result.lineHits.buffer, result.matchLine.buffer, result.matchStart.buffer, result.matchEnd.buffer]
  );
}

self.onmessage = event => {
  const message = event.data || {};
  if (message.type === "load" && message.stream) {
    activeId = 0;
    store = new LineStore();
    streamBlob = message.blob || null;
    ready = Promise.resolve();
    self.postMessage({ type: "loaded", lineCount: -1 });
  } else if (message.type === "load") {
    activeId = 0;
    streamBlob = null;
    store = new LineStore();
    const total = message.blob?.size || 0;
    let lastPost = 0;
    const onProgress = bytes => {
      const now = Date.now();
      if (now - lastPost < 250) return;
      lastPost = now;
      self.postMessage({ type: "loading", progress: total ? bytes / total : 0 });
    };
    ready = (message.blob ? storeFromBlob(message.blob, onProgress) : Promise.resolve(new LineStore()))
      .then(loaded => {
        store = loaded;
        // Heartbeat: the page counts this as progress, not as a stuck search.
        self.postMessage({ type: "loaded", lineCount: loaded.length });
      });
  } else if (message.type === "search") {
    runSearch(message).catch(error => {
      self.postMessage({ type: "result", id: message.id, error: String(error?.message || error) });
    });
  } else if (message.type === "cancel") {
    activeId = 0;
  }
};
