const KEY_PREFIX = "btrixLog:";
const SOFT404_PATH = "/browsertrixsoft404detect";
const SOFT404_TOLERANCE_RATIO = 0.08;
const SOFT404_TOLERANCE_MIN_BYTES = 2048;

// ------------------------------------------------------------ column order
// Columns can be reordered but never hidden or removed: the order is always a
// complete permutation of the columns declared in viewer.html.
const COLUMN_ORDER_KEY = "btlv.table.columnOrder.v1";
const headerRow = document.querySelector("#logTable thead tr");
const DEFAULT_COLUMN_ORDER = Object.freeze([...headerRow.querySelectorAll("th[data-key]")].map(th => th.dataset.key));

function sanitizeColumnOrder(order) {
  const known = new Set(DEFAULT_COLUMN_ORDER);
  const seen = new Set();
  const result = [];
  if (Array.isArray(order)) {
    for (const key of order) {
      if (known.has(key) && !seen.has(key)) {
        seen.add(key);
        result.push(key);
      }
    }
  }
  // Any column missing from a saved order (or added in a later version) is
  // appended, so a column can never disappear.
  for (const key of DEFAULT_COLUMN_ORDER) if (!seen.has(key)) result.push(key);
  return result;
}

function loadColumnOrder() {
  try {
    return sanitizeColumnOrder(JSON.parse(localStorage.getItem(COLUMN_ORDER_KEY) || "null"));
  } catch (_) {
    return [...DEFAULT_COLUMN_ORDER];
  }
}

const state = {
  columnOrder: loadColumnOrder(),
  rows: [],
  filtered: [],
  lines: null,
  rawBlob: null,
  filename: "browsertrix-logs.log",
  sortKey: "timestamp",
  sortDir: 1,
  page: 1,
  pageSize: 250,
  search: "",
  level: "",
  context: "",
  fileType: "",
  mimeGroup: "",
  provenanceByUrl: new Map(),
  pageUrls: new Set(),
  pageStatusByUrl: new Map(),
  diagnostics: null,
  ai: {
    diagnosis: null,
    availability: "unknown",
    state: "idle",
    report: null
  },
  meta: {
    firstSeed: "",
    seedCount: null,
    scopeType: "",
    maxDepth: null,
    maxExtraHops: null,
    crawlerVersion: ""
  },
  soft404: {
    state: "idle", // idle | permission | running | detected | clear | error | unavailable
    origin: "",
    host: "",
    testUrl: "",
    finalUrl: "",
    status: null,
    statusText: "",
    fileType: "",
    contentType: "",
    bodySize: NaN,
    headerSize: NaN,
    suspectUrls: new Set(),
    error: ""
  }
};

const $ = id => document.getElementById(id);
const els = {
  filename: $("filename"),
  crawlMeta: $("crawlMeta"),
  statusPanel: $("statusPanel"),
  statusText: $("statusText"),
  statusDetail: $("statusDetail"),
  statusSpinner: $("statusSpinner"),
  loadProgress: $("loadProgress"),
  loadProgressBar: $("loadProgressBar"),
  soft404Panel: $("soft404Panel"),
  soft404Title: $("soft404Title"),
  soft404Text: $("soft404Text"),
  soft404Test: $("soft404Test"),
  analysisPanel: $("analysisPanel"),
  diagnosticFacts: $("diagnosticFacts"),
  aiAnalyze: $("aiAnalyze"),
  aiStatus: $("aiStatus"),
  aiProgress: $("aiProgress"),
  aiProgressBar: $("aiProgressBar"),
  aiReport: $("aiReport"),
  summary: $("summary"),
  filteredStats: $("filteredStats"),
  controls: $("controls"),
  tableWrap: $("tableWrap"),
  tbody: document.querySelector("#logTable tbody"),
  pager: $("pager"),
  search: $("search"),
  levelFilter: $("levelFilter"),
  contextFilter: $("contextFilter"),
  typeFilter: $("typeFilter"),
  mimeGroupFilter: $("mimeGroupFilter"),
  statusFilter: $("statusFilter"),
  statusOverview: $("statusOverview"),
  pageSize: $("pageSize"),
  clearFilters: $("clearFilters"),
  matchCount: $("matchCount"),
  pageInfo: $("pageInfo"),
  firstPage: $("firstPage"),
  prevPage: $("prevPage"),
  nextPage: $("nextPage"),
  lastPage: $("lastPage"),
  downloadRaw: $("downloadRaw"),
  fileInput: $("fileInput"),
  provenancePanel: $("provenancePanel"),
  provenanceTitle: $("provenanceTitle"),
  provenanceBody: $("provenanceBody"),
  provenanceClose: $("provenanceClose"),
  provenanceBackdrop: $("provenanceBackdrop"),
  viewTabs: $("viewTabs"),
  resetColumns: $("resetColumns"),
  columnAnnounce: $("columnAnnounce"),
  retryRemote: $("retryRemote"),
  aiNotice: $("aiNotice"),
  aiNoticeTitle: $("aiNoticeTitle"),
  aiNoticeDetail: $("aiNoticeDetail"),
  aiNoticeSteps: $("aiNoticeSteps"),
  aiNoticeClose: $("aiNoticeClose"),
  tabTable: $("tabTable"),
  tabRaw: $("tabRaw"),
  tableView: $("tableView")
};

function redact(text) {
  return globalThis.BTLV_HOSTS ? globalThis.BTLV_HOSTS.redactSecrets(text) : String(text);
}

function setStatus(text, isError = false) {
  els.retryRemote.hidden = true;
  els.statusText.textContent = redact(text);
  els.statusDetail.textContent = "";
  els.statusPanel.classList.remove("loading");
  els.statusPanel.classList.toggle("error", isError);
  els.loadProgress.hidden = true;
  els.statusPanel.hidden = false;
}

function setLoadingStatus(text, receivedBytes = 0, totalBytes = NaN) {
  els.retryRemote.hidden = true;
  els.statusText.textContent = redact(text);
  els.statusPanel.classList.add("loading");
  els.statusPanel.classList.remove("error");
  els.statusPanel.hidden = false;
  els.loadProgress.hidden = false;

  const hasTotal = Number.isFinite(totalBytes) && totalBytes > 0;
  if (hasTotal) {
    const pct = Math.min(100, Math.max(0, (receivedBytes / totalBytes) * 100));
    els.statusDetail.textContent = `${pct.toFixed(0)}% · ${formatBytes(receivedBytes)} / ${formatBytes(totalBytes)}`;
    els.loadProgressBar.classList.remove("indeterminate");
    els.loadProgressBar.style.width = `${pct}%`;
    els.loadProgress.setAttribute("aria-valuenow", pct.toFixed(0));
  } else {
    els.statusDetail.textContent = receivedBytes > 0 ? `${formatBytes(receivedBytes)} received` : "";
    els.loadProgressBar.classList.add("indeterminate");
    els.loadProgressBar.style.width = "35%";
    els.loadProgress.removeAttribute("aria-valuenow");
  }
}

function hideStatus() {
  els.statusPanel.hidden = true;
  els.statusPanel.classList.remove("loading", "error");
  els.loadProgress.hidden = true;
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let n = bytes;
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
}

function firstFiniteNumber(...values) {
  for (const value of values) {
    if (value === "" || value == null) continue;
    const n = Number(value);
    if (Number.isFinite(n) && n >= 0) return n;
  }
  return NaN;
}

function extractSizeBytes(details) {
  if (!details || typeof details !== "object") return NaN;
  let size = firstFiniteNumber(
    details.size,
    details.actualSize,
    details.contentLen,
    details.contentLength,
    details.content_length,
    details.bytes,
    details.byteLength,
    details.encodedDataLength
  );
  if (Number.isFinite(size)) return size;

  if (typeof details.range === "string") {
    const match = details.range.match(/\/([0-9]+)\s*$/);
    if (match) return Number(match[1]);
  }

  return firstFiniteNumber(details.expected);
}

// File-type labels live in mime-groups.js (single home for MIME/extension logic).
const mimeToType = BTLV_MIME.typeLabelForMime;
const typeFromUrl = BTLV_MIME.typeLabelForUrl;

function resourceTypeToFileType(resourceType) {
  const value = String(resourceType || "").toLowerCase();
  const map = {
    document: "Page",
    stylesheet: "CSS",
    script: "JavaScript",
    image: "Image",
    media: "Media",
    font: "Font",
    manifest: "Manifest",
    websocket: "WebSocket"
  };
  return map[value] || "";
}

function extractFileType(details, url) {
  if (details && typeof details === "object") {
    const mimeCandidates = [
      details.mimeType, details.mimetype, details.mime, details.contentType,
      details.content_type, details.mediaType
    ];
    for (const candidate of mimeCandidates) {
      const type = mimeToType(candidate);
      if (type) return type;
    }

    const fromResourceType = resourceTypeToFileType(details.resourceType);
    if (fromResourceType && fromResourceType !== "Page") return fromResourceType;
  }

  const fromUrl = typeFromUrl(url);
  if (fromUrl) return fromUrl;

  if (details && typeof details.resourceType === "string") {
    const value = details.resourceType.toLowerCase();
    if (value === "xhr") return "XHR";
    if (value === "fetch") return "Fetch";
  }
  return "";
}

function domainFromUrl(url) {
  const normalized = asHttpUrl(url);
  if (!normalized) return "";
  const cached = domainCache.get(normalized);
  if (cached !== undefined) return cached;
  let host = "";
  try {
    host = new URL(normalized).hostname.toLowerCase();
  } catch (_) {
    host = "";
  }
  if (domainCache.size >= URL_CACHE_LIMIT) domainCache.clear();
  domainCache.set(normalized, host);
  return host;
}

function isPageLifecycleRow(row) {
  const message = row.message;
  if ([
    "Queued new page URL",
    "Starting page",
    "Page Finished",
    "Awaiting page load",
    "Setting page timestamp"
  ].includes(message)) return true;
  if (row.context === "pageStatus") return true;
  if (row.details?.type === "pageinfo") return true;
  if (String(row.details?.resourceType || "").toLowerCase() === "document") return true;
  return false;
}

// Final page outcomes as Browsertrix Crawler logs them (context pageStatus):
//   "Page Finished"                                      -> completed
//   "<reason>: retry limit reached" (error)              -> failed
//   "Page is an empty non-200 response, not retrying"    -> failed (no retry)
//   "Page Load Blocked, skipping" /
//   "Page dynamically changed to seen page, skipping"    -> skipped
// "<reason>: will retry" is NOT an outcome; the page is attempted again.
// "Seed Page Load Failed, failing crawl" is logged without a page URL.
function pageOutcome(row) {
  const message = row.message;
  if (message === "Page Finished") return "completed";
  if (row.context !== "pageStatus") return "";
  if (/: will retry$/i.test(message)) return "";
  if (/: retry limit reached$/i.test(message) || /^Page is an empty non-200 response/i.test(message)) return "failed";
  if (/^Page Load Blocked, skipping$/i.test(message) || /^Page dynamically changed to seen page, skipping$/i.test(message)) return "skipped";
  if (["error", "fatal"].includes(row.logLevel.toLowerCase())) return "failed";
  return "";
}

function formatDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return "—";
  const sec = Math.round(ms / 1000);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h) return `${h}h ${m}m ${s}s`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

// ------------------------------------------------------- crawler-made items
// Records the crawler CREATES ITSELF and stores in the WARC under a urn:
// address; they are not content downloaded from a crawled site. Recognised
// only by Browsertrix Crawler's own log signals (crawler source):
//   screenshots.ts  "WARC Record Written", details.resource "screenshot",
//                   details.type view | thumbnail | fullPage
//   textextract.ts  "WARC Record Written", details.resource "text"
//   recorder.ts     "WARC Record Written", details.type "pageinfo"
//   any line whose details.url is a urn: address (e.g. "Skipping writing
//   pageinfo for blocked page", url "urn:pageinfo:<page>")
const CRAWLER_MADE = "Crawler-made";
const SCREENSHOT_KINDS = { view: "view", thumbnail: "thumbnail", fullPage: "full page" };

function isHtmlMime(mime) {
  return /^(text\/html|application\/xhtml\+xml)$/i.test(String(mime || "").split(";")[0].trim());
}

function crawlerMadeKind(message, details) {
  const d = details && typeof details === "object" ? details : {};
  if (message === "WARC Record Written") {
    if (d.resource === "screenshot") return `screenshot (${SCREENSHOT_KINDS[d.type] || d.type || "view"})`;
    if (d.resource === "text") return "extracted text";
    if (d.type === "pageinfo") return "page info";
  }
  if (typeof d.url === "string" && /^urn:/i.test(d.url)) {
    const kind = d.url.split(":")[1] || "";
    if (kind === "pageinfo") return "page info";
    if (kind in SCREENSHOT_KINDS) return `screenshot (${SCREENSHOT_KINDS[kind]})`;
    if (/^text/i.test(kind)) return "extracted text";
    return "record";
  }
  return "";
}

function crawlerMadeLabel(kind) {
  return kind === "record" ? CRAWLER_MADE : `${CRAWLER_MADE} · ${kind}`;
}

function extractUrl(details, key) {
  const value = details && typeof details === "object" ? details[key] : "";
  return typeof value === "string" ? value : "";
}


// URL parsing was ~45% of load time: the same page/resource URLs appear on
// thousands of lines. Results are remembered per load (bounded).
const URL_CACHE_LIMIT = 400000;
const httpUrlCache = new Map();
const domainCache = new Map();

function resetUrlCaches() {
  httpUrlCache.clear();
  domainCache.clear();
  BTLV_MIME.clearCaches?.();
}

function asHttpUrl(value) {
  if (typeof value !== "string" || !value) return "";
  const cached = httpUrlCache.get(value);
  if (cached !== undefined) return cached;
  let result = "";
  if (value.trim()) {
    try {
      const u = new URL(value);
      result = u.protocol === "http:" || u.protocol === "https:" ? u.href : "";
    } catch (_) {
      result = "";
    }
  }
  if (httpUrlCache.size >= URL_CACHE_LIMIT) httpUrlCache.clear();
  httpUrlCache.set(value, result);
  return result;
}

function sameUrl(a, b) {
  const aa = asHttpUrl(a);
  const bb = asHttpUrl(b);
  return !!aa && !!bb && aa === bb;
}

function firstDetailUrl(details, keys) {
  if (!details || typeof details !== "object") return "";
  for (const key of keys) {
    const url = asHttpUrl(details[key]);
    if (url) return url;
  }
  return "";
}

const PROVENANCE_SOURCE_KEYS = [
  "sourceUrl", "sourceURL", "fromPage", "parentUrl", "parentURL",
  "referrer", "referrerUrl", "referringPage", "discoveredFrom", "source"
];
const PROVENANCE_TARGET_KEYS = ["targetUrl", "targetURL", "target", "link", "href"];

function provenanceRank(confidence) {
  if (confidence === "exact") return 3;
  if (confidence === "inferred") return 2;
  if (confidence === "initial") return 1;
  return 0;
}

function addProvenance(map, target, item) {
  target = asHttpUrl(target);
  if (!target || !item) return;
  const entry = map.get(target) || { target, items: [] };
  const normalized = {
    target,
    origin: asHttpUrl(item.origin),
    confidence: item.confidence || "unknown",
    relation: item.relation || "Discovered from",
    method: item.method || "",
    lineNumber: Number(item.lineNumber) || null,
    timestamp: item.timestamp || ""
  };
  const duplicate = entry.items.some(x =>
    x.origin === normalized.origin && x.confidence === normalized.confidence &&
    x.relation === normalized.relation && x.method === normalized.method
  );
  if (!duplicate) entry.items.push(normalized);
  entry.items.sort((a, b) => provenanceRank(b.confidence) - provenanceRank(a.confidence) || (a.lineNumber || 0) - (b.lineNumber || 0));
  map.set(target, entry);
}

function bestProvenance(map, target) {
  const entry = map.get(asHttpUrl(target));
  return entry?.items?.[0] || null;
}

function applyProvenance(rows) {
  const provenanceByUrl = new Map();

  // First collect explicit source -> target metadata. This also supports custom behavior logs
  // such as {source: window.location.href, target: link}.
  for (const row of rows) {
    const source = firstDetailUrl(row.details, PROVENANCE_SOURCE_KEYS);
    const target = firstDetailUrl(row.details, PROVENANCE_TARGET_KEYS) || (source ? asHttpUrl(row.url) : "");
    if (source && target && !sameUrl(source, target)) {
      addProvenance(provenanceByUrl, target, {
        origin: source,
        confidence: "exact",
        relation: row.context === "behavior" || row.context === "behaviorScript" ? "Added by behavior" : "Explicit source metadata",
        method: "log metadata",
        lineNumber: row.lineNumber,
        timestamp: row.timestamp
      });
    }
  }

  let declaredWorkers = null;
  const workerIds = new Set();
  for (const row of rows) {
    if (row.workerid !== "" && row.workerid != null) workerIds.add(String(row.workerid));
    const m = row.message.match(/^Creating\s+(\d+)\s+workers?$/i);
    if (m) declaredWorkers = Number(m[1]);
  }
  const singleWorker = declaredWorkers === 1 || (declaredWorkers == null && workerIds.size <= 1);
  const firstStartIndex = rows.findIndex(r => r.message === "Starting page");
  const activeByWorker = new Map();
  let activeGlobal = "";

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const workerKey = row.workerid === "" || row.workerid == null ? "" : String(row.workerid);

    if (row.message === "Starting page") {
      const page = asHttpUrl(row.page || row.details?.page || row.url);
      if (page) {
        if (workerKey) activeByWorker.set(workerKey, page);
        if (singleWorker) activeGlobal = page;
      }
    }

    // Resources generally carry the exact page that caused the request.
    if (row.url && row.page && !sameUrl(row.url, row.page)) {
      row.provenance = row.isLean ? sharedExactProvenance(row) : {
        target: asHttpUrl(row.url),
        origin: asHttpUrl(row.page),
        confidence: "exact",
        relation: "Requested by page",
        method: "details.page",
        lineNumber: row.lineNumber,
        timestamp: row.timestamp
      };
    }

    if (row.message === "Queued new page URL" && row.url) {
      const target = asHttpUrl(row.url);
      const explicitSource = firstDetailUrl(row.details, PROVENANCE_SOURCE_KEYS);
      if (explicitSource && !sameUrl(explicitSource, target)) {
        addProvenance(provenanceByUrl, target, {
          origin: explicitSource,
          confidence: "exact",
          relation: "Link queued from page",
          method: "queue metadata",
          lineNumber: row.lineNumber,
          timestamp: row.timestamp
        });
      } else if (!bestProvenance(provenanceByUrl, target)) {
        if (firstStartIndex === -1 || i < firstStartIndex) {
          addProvenance(provenanceByUrl, target, {
            origin: "",
            confidence: "initial",
            relation: "Initial queue / likely seed",
            method: "queued before crawling started",
            lineNumber: row.lineNumber,
            timestamp: row.timestamp
          });
        } else if (singleWorker && activeGlobal && !sameUrl(activeGlobal, target)) {
          addProvenance(provenanceByUrl, target, {
            origin: activeGlobal,
            confidence: "inferred",
            relation: "Likely discovered on page",
            method: "queue timing with one active worker",
            lineNumber: row.lineNumber,
            timestamp: row.timestamp
          });
        }
      }
    }

    if (row.message === "Page Finished") {
      if (workerKey) activeByWorker.delete(workerKey);
      if (singleWorker) activeGlobal = "";
    }
  }

  // Propagate page-level discovery provenance to all rows concerning that page.
  for (const row of rows) {
    if (!row.provenance) {
      let target = "";
      if (row.message === "Queued new page URL") target = asHttpUrl(row.url);
      else if (row.page && (!row.url || sameUrl(row.url, row.page))) target = asHttpUrl(row.page);
      else if (row.url && !row.page) target = asHttpUrl(row.url);
      const p = target ? bestProvenance(provenanceByUrl, target) : null;
      if (p) row.provenance = row.isLean ? sharedDerivedProvenance(p, target) : { ...p, target };
    }

    row.provenanceOrigin = row.provenance?.origin || (row.provenance?.confidence === "initial" ? "Initial queue / likely seed" : "");
    if (row.isLean) {
      row.provenanceOrigin = intern(row.provenanceOrigin);
      row.pageTarget = intern(row.pageTarget);
      row.domain = intern(row.domain);
      row.mimeType = intern(row.mimeType);
      row.mimeGroup = intern(row.mimeGroup);
      row.contentFileType = intern(row.contentFileType);
    }
    if (row.provenanceOrigin && !row.isLean) row.derivedText += ` ${row.provenanceOrigin} ${row.provenance?.relation || ""} ${row.provenance?.confidence || ""}`.toLowerCase();
  }

  return provenanceByUrl;
}

function provenanceTargetForRow(row) {
  if (row.provenance?.target) return row.provenance.target;
  if (row.url) return asHttpUrl(row.url);
  if (row.page) return asHttpUrl(row.page);
  return "";
}

function shortUrl(url) {
  if (!url) return "";
  try {
    const u = new URL(url);
    const text = `${u.host}${u.pathname}${u.search}`;
    return text.length > 64 ? `${text.slice(0, 61)}…` : text;
  } catch (_) {
    return url;
  }
}

function closeProvenancePanel() {
  els.provenancePanel.hidden = true;
  els.provenanceBackdrop.hidden = true;
}

function addProvUrl(container, url) {
  const a = document.createElement("a");
  a.className = "prov-url";
  a.href = url;
  a.target = "_blank";
  a.rel = "noreferrer noopener";
  a.textContent = url;
  container.appendChild(a);
}

function addProvMeta(container, values) {
  const dl = document.createElement("dl");
  dl.className = "prov-meta";
  for (const [label, value] of values) {
    if (value === "" || value == null) continue;
    const dt = document.createElement("dt");
    dt.textContent = label;
    const dd = document.createElement("dd");
    dd.textContent = String(value);
    dl.append(dt, dd);
  }
  container.appendChild(dl);
}

function buildProvenanceChain(target, row) {
  const chain = [];
  const seen = new Set();
  let current = asHttpUrl(target);
  let currentProv = row?.provenance || bestProvenance(state.provenanceByUrl, current);

  for (let depth = 0; current && depth < 7; depth++) {
    if (seen.has(current)) break;
    seen.add(current);
    chain.push({ url: current, provenance: currentProv });
    const parent = asHttpUrl(currentProv?.origin);
    if (!parent || seen.has(parent)) break;
    current = parent;
    currentProv = bestProvenance(state.provenanceByUrl, current);
  }
  return chain;
}

function openProvenancePanel(row) {
  const target = provenanceTargetForRow(row);
  if (!target && !row.provenance) return;

  els.provenanceTitle.textContent = shortUrl(target || row.provenanceOrigin) || "Trace";
  els.provenanceBody.replaceChildren();

  const main = document.createElement("section");
  main.className = "prov-section";
  const h = document.createElement("h3");
  h.textContent = "Selected URL";
  main.appendChild(h);
  if (target) addProvUrl(main, target);

  const p = row.provenance;
  addProvMeta(main, [
    ["Relation", p?.relation || "Unknown"],
    ["Confidence", p?.confidence ? p.confidence.toUpperCase() : "UNKNOWN"],
    ["Method", p?.method || "No provenance metadata in log"],
    ["Source line", p?.lineNumber || row.lineNumber],
    ["Time", p?.timestamp || row.timestamp]
  ]);
  els.provenanceBody.appendChild(main);

  if (p?.origin) {
    const originSection = document.createElement("section");
    originSection.className = "prov-section";
    const oh = document.createElement("h3");
    oh.textContent = p.confidence === "inferred" ? "Likely origin page" : "Origin page";
    originSection.appendChild(oh);
    addProvUrl(originSection, p.origin);
    if (p.confidence === "inferred") {
      const note = document.createElement("div");
      note.className = "prov-note";
      note.textContent = "Inferred from queue timing while a single Browsertrix worker was processing this page. The current log does not contain an explicit parent/referrer field for the queued URL.";
      originSection.appendChild(note);
    }
    els.provenanceBody.appendChild(originSection);
  } else if (p?.confidence === "initial") {
    const initial = document.createElement("section");
    initial.className = "prov-section";
    const note = document.createElement("div");
    note.className = "prov-note";
    note.textContent = "This URL was queued before page processing started. It is therefore treated as an initial queue entry / likely seed, not as a link discovered on another page.";
    initial.appendChild(note);
    els.provenanceBody.appendChild(initial);
  }

  const chain = buildProvenanceChain(target, row);
  if (chain.length > 1) {
    const section = document.createElement("section");
    section.className = "prov-section";
    const ch = document.createElement("h3");
    ch.textContent = "Trace toward seed";
    section.appendChild(ch);
    const ol = document.createElement("ol");
    ol.className = "prov-chain";
    for (let i = 0; i < chain.length; i++) {
      const li = document.createElement("li");
      const label = document.createElement("div");
      label.className = "prov-chain-label";
      label.textContent = i === 0 ? "Selected" : `Parent ${i}`;
      li.appendChild(label);
      addProvUrl(li, chain[i].url);
      if (chain[i].provenance?.confidence) {
        const meta = document.createElement("div");
        meta.className = "provenance-kicker";
        meta.textContent = `${chain[i].provenance.relation} · ${chain[i].provenance.confidence}`;
        li.appendChild(meta);
      }
      ol.appendChild(li);
    }
    section.appendChild(ol);
    els.provenanceBody.appendChild(section);
  }

  els.provenancePanel.hidden = false;
  els.provenanceBackdrop.hidden = false;
}

function originCell(row) {
  const td = document.createElement("td");
  td.className = "origin-cell";
  const p = row.provenance;
  if (!p) {
    td.innerHTML = '<span class="empty">—</span>';
    return td;
  }

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "origin-button";
  btn.title = p.origin || p.relation || "Show URL provenance";

  const text = document.createElement("span");
  text.className = "origin-text";
  text.textContent = p.origin ? shortUrl(p.origin) : "Initial queue / likely seed";
  btn.appendChild(text);

  const badge = document.createElement("span");
  badge.className = `prov-badge ${p.confidence || ""}`;
  badge.textContent = p.confidence === "exact" ? "EXACT" : p.confidence === "inferred" ? "INFERRED" : "INITIAL";
  btn.appendChild(badge);

  btn.addEventListener("click", () => openProvenancePanel(row));
  td.appendChild(btn);
  return td;
}

// ------------------------------------------------------ large-log mode (v1.16)
// Logs above LARGE_LOG_BYTES load in large-log mode: the raw text stays on
// disk (disk-lines.js) and every line becomes a compact LeanRow: the same
// fields as a normal row, but with shared (interned) strings, a numeric
// timestamp, no per-row search text, and only the few `details` fields the
// analyses need (usually none). The full details are read from disk when a
// row is opened.
const LARGE_LOG_BYTES = 500 * 1024 * 1024;

function largeLogBytes() {
  try {
    const override = Number(localStorage.getItem("btlv.debug.largeLogBytes")); // tests only
    if (Number.isFinite(override) && override > 0) return override;
  } catch (_) { /* storage unavailable */ }
  return LARGE_LOG_BYTES;
}

const EMPTY_DETAILS = Object.freeze({});
const internPool = new Map();
function intern(value) {
  if (typeof value !== "string" || value.length > 4096) return value;
  const hit = internPool.get(value);
  if (hit !== undefined) return hit;
  if (internPool.size >= 3000000) internPool.clear();
  internPool.set(value, value);
  return value;
}

let leanKeepKeys = null;
function leanKeys() {
  return leanKeepKeys ||= new Set([
    ...PROVENANCE_SOURCE_KEYS, ...PROVENANCE_TARGET_KEYS,
    "limit", "firstSeed", "seedCount",
    "rss", "heapUsed", "heapTotal", "maxHeapUsed", "maxHeapTotal", "external", "arrayBuffers",
    "cpu", "cpuUsage", "cpuPercent", "cpuUsagePercent", "systemCpu", "userCpu", "loadAverage",
    "diskFree", "diskUsed", "storageFree", "storageUsed", "freeSpace", "availableSpace", "bytesFree", "bytesUsed",
    "message", "error", "reason", "statusText"
  ]);
}
const FULL_DETAILS_MESSAGES = new Set(["Seeds", "Crawl statistics"]);

// Only what the analyses read after parsing; everything else stays on disk.
function leanDetails(message, level, details) {
  if (FULL_DETAILS_MESSAGES.has(message) || /^(warn|error|fatal|interrupt)$/i.test(level)) {
    if (details && "pendingPages" in details) {
      const { pendingPages, ...rest } = details; // can be large; not used
      return rest;
    }
    return details;
  }
  const keep = leanKeys();
  let out = null;
  for (const key in details) {
    if (keep.has(key)) (out ||= {})[key] = details[key];
  }
  if (details.type === "pageinfo") (out ||= {}).type = "pageinfo";
  if (typeof details.resourceType === "string" && details.resourceType.toLowerCase() === "document") {
    (out ||= {}).resourceType = details.resourceType;
  }
  return out || EMPTY_DETAILS;
}

class LeanRow {
  constructor(f) {
    this.index = f.index;
    this.lineNumber = f.lineNumber;
    this.timestampMs = f.timestampMs;
    this._ts = f.ts;
    this.logLevel = f.logLevel;
    this.context = f.context;
    this.message = f.message;
    this.status = f.status;
    this.workerid = f.workerid;
    this.fileType = f.fileType;
    this.contentFileType = f.fileType;
    this.mimeType = "";
    this.mimeSource = "";
    this.mimeGroup = "";
    this.sizeBytes = f.sizeBytes;
    this.url = f.url;
    this.page = f.page;
    this.domain = "";
    this.isPageEvent = false;
    this.pageTarget = "";
    this.details = f.details;
    this.provenance = null;
    this.provenanceOrigin = "";
    this.soft404Suspect = false;
    this.crawlerMade = f.crawlerMade;
    this.statusCode = NaN;
    this.suspectedBlock = false;
    this.loggedMime = f.loggedMime;
  }
  // ISO text is rebuilt from the number; the original is kept only when it
  // would not round-trip exactly.
  get timestamp() {
    return this._ts !== null ? this._ts : new Date(this.timestampMs).toISOString();
  }
  get derivedText() {
    return [this.fileType, this.mimeType, this.mimeGroup, this.domain, Number.isFinite(this.sizeBytes) ? this.sizeBytes : ""].join(" ").toLowerCase();
  }
  get mimeDetails() {
    return this.loggedMime ? { mimeType: this.loggedMime } : EMPTY_DETAILS;
  }
}
LeanRow.prototype.isLean = true;

// Provenance objects are shared between rows with the same relation.
let provenanceShare = new Map();
function sharedExactProvenance(row) {
  const target = asHttpUrl(row.url);
  const origin = asHttpUrl(row.page);
  const key = `${target}\u0001${origin}`;
  let p = provenanceShare.get(key);
  if (!p) {
    p = { target, origin, confidence: "exact", relation: "Requested by page", method: "details.page", lineNumber: row.lineNumber, timestamp: row.timestamp };
    provenanceShare.set(key, p);
  }
  return p;
}
const derivedProvenance = new WeakMap();
function sharedDerivedProvenance(p, target) {
  if (p.target === target) return p;
  let byTarget = derivedProvenance.get(p);
  if (!byTarget) derivedProvenance.set(p, byTarget = new Map());
  let q = byTarget.get(target);
  if (!q) byTarget.set(target, q = { ...p, target });
  return q;
}

// ---------------------------------------------------------- parsing (v1.12)
// Lines are parsed as they stream in (parseLineInto), then the passes that
// need every row run in time slices (finalizeRows), so the page never freezes.

function parseLineInto(rows, invalid, rawLine, lineNumber, lean = false) {
  const line = rawLine.trim();
  if (!line) return;
  try {
    const obj = JSON.parse(line);
    const details = obj.details && typeof obj.details === "object" ? obj.details : {};
    const timestamp = typeof obj.timestamp === "string" ? obj.timestamp : "";
    const status = details.status ?? "";
    const workerid = details.workerid ?? "";
    const url = extractUrl(details, "url");
    const page = extractUrl(details, "page");
    const sizeBytes = extractSizeBytes(details);
    const message = String(obj.message ?? "");
    const crawlerMade = crawlerMadeKind(message, details);
    const fileType = crawlerMade ? crawlerMadeLabel(crawlerMade) : extractFileType(details, url);
    if (lean) {
      const timestampMs = Date.parse(timestamp);
      const roundTrips = Number.isFinite(timestampMs) && new Date(timestampMs).toISOString() === timestamp;
      const logLevel = intern(String(obj.logLevel ?? ""));
      rows.push(new LeanRow({
        index: rows.length,
        lineNumber,
        timestampMs,
        ts: roundTrips ? null : timestamp,
        logLevel,
        context: intern(String(obj.context ?? "")),
        message: intern(message),
        status,
        workerid,
        fileType: intern(fileType),
        sizeBytes,
        url: intern(url),
        page: intern(page),
        details: leanDetails(message, logLevel, details),
        crawlerMade: intern(crawlerMade),
        loggedMime: intern(BTLV_MIME.mimeFromDetails(details))
      }));
      return;
    }

    rows.push({
      index: rows.length,
      lineNumber,
      timestamp,
      timestampMs: Date.parse(timestamp),
      logLevel: String(obj.logLevel ?? ""),
      context: String(obj.context ?? ""),
      message,
      status,
      workerid,
      fileType,
      contentFileType: fileType,
      mimeType: "",
      mimeSource: "",
      mimeGroup: "",
      sizeBytes,
      url,
      page,
      domain: "",
      isPageEvent: false,
      pageTarget: "",
      details,
      provenance: null,
      provenanceOrigin: "",
      soft404Suspect: false,
      crawlerMade,
      derivedText: ""
    });
  } catch (error) {
    invalid.push({ lineNumber, line: line.slice(0, 500), error: String(error) });
  }
}

const SLICE_MS = 30;

// A plain timer, on purpose: scheduler.yield() resumes the paused work AHEAD of
// other queued work (timers, repaints), which kept the page frozen in tests.
function yieldToBrowser() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

// Runs work in slices of about SLICE_MS, yielding to the browser in between so
// it can paint progress and stay responsive.
class Slicer {
  constructor(generation) {
    this.generation = generation;
    this.deadline = performance.now() + SLICE_MS;
  }

  async tick(onYield) {
    if (performance.now() < this.deadline) return;
    onYield?.();
    await yieldToBrowser();
    if (this.generation !== loadGeneration) throw new LoadSuperseded();
    this.deadline = performance.now() + SLICE_MS;
  }
}

class LoadSuperseded extends Error {}

async function finalizeRows(rows, slicer, report) {
  const total = rows.length;
  // Browsertrix puts the active crawl page in details.page on resource and behavior
  // events. Queue entries and firstSeed add URLs that may not yet have started.
  const pageUrls = new Set();
  for (let i = 0; i < total; i++) {
    const row = rows[i];
    const page = asHttpUrl(row.page);
    if (page) pageUrls.add(page);
    if (row.message === "Queued new page URL") {
      const queued = asHttpUrl(row.url);
      if (queued) pageUrls.add(queued);
    }
    const firstSeed = asHttpUrl(row.details?.firstSeed?.url);
    if (firstSeed) pageUrls.add(firstSeed);
    if (isPageLifecycleRow(row)) {
      const target = asHttpUrl(row.url) || asHttpUrl(row.page);
      if (target) pageUrls.add(target);
    }
    if ((i & 1023) === 0) await slicer.tick(() => report("Finding pages", i, total));
  }

  const pageStatusByUrl = new Map();
  // URLs with LOGGED evidence of non-HTML content (a video, PDF, image ...).
  // Such a URL counts as a resource even when Browsertrix also queued or
  // crawled it as a "page" (direct fetch of a linked file).
  const nonHtmlMime = new Map();
  for (let i = 0; i < total; i++) {
    const row = rows[i];
    // Crawler-made rows (e.g. page info) still help DISCOVER pages above, but
    // they are never page events themselves.
    const lifecycle = !row.crawlerMade && (isPageLifecycleRow(row) || row.message.startsWith("Direct fetch indicates HTML page"));
    let pageTarget = "";
    if (lifecycle) {
      const candidateUrl = asHttpUrl(row.url);
      const candidatePage = asHttpUrl(row.page);
      if (candidateUrl && pageUrls.has(candidateUrl)) pageTarget = candidateUrl;
      else if (candidatePage) pageTarget = candidatePage;
    }

    row.isPageEvent = !!pageTarget;
    row.pageTarget = pageTarget;
    const rowUrl = asHttpUrl(row.url);
    if (!row.crawlerMade && !row.contentFileType && rowUrl && pageUrls.has(rowUrl) && (!row.page || sameUrl(row.url, row.page))) {
      // A known crawl-page main response without MIME/extension metadata is HTML
      // for soft-404 comparison purposes. This does not turn arbitrary hostnames
      // or extensionless resources into HTML.
      row.contentFileType = "HTML";
    }
    if (row.isPageEvent) row.fileType = "Page";

    const primaryUrl = rowUrl || pageTarget || asHttpUrl(row.page);
    row.domain = domainFromUrl(primaryUrl);

    const mimeInfo = BTLV_MIME.detect(row.isLean ? row.mimeDetails : row.details, rowUrl || primaryUrl, row.fileType, row.isPageEvent);
    row.mimeType = mimeInfo.mimeType;
    row.mimeSource = mimeInfo.mimeSource;
    row.mimeGroup = mimeInfo.mimeGroup;
    if (row.crawlerMade) {
      // The log gives no MIME type for these; never guess one from the page URL.
      row.mimeType = "";
      row.mimeSource = "crawler";
      row.mimeGroup = CRAWLER_MADE;
      row.contentFileType = "";
    }

    row.statusCode = statusCodeOf(row);
    row.suspectedBlock = isSuspectedBlocking(row);
    if (rowUrl && !row.crawlerMade && row.mimeSource === "log" && row.mimeType && !isHtmlMime(row.mimeType) && !nonHtmlMime.has(rowUrl)) {
      nonHtmlMime.set(rowUrl, row.mimeType);
    }

    if (pageTarget) {
      const current = pageStatusByUrl.get(pageTarget) || "queued";
      const outcome = pageOutcome(row);
      if (outcome === "completed") pageStatusByUrl.set(pageTarget, "completed");
      else if (outcome === "failed" && current !== "completed") pageStatusByUrl.set(pageTarget, "failed");
      else if (outcome === "skipped" && current !== "completed" && current !== "failed") pageStatusByUrl.set(pageTarget, "skipped");
      else if (row.message === "Starting page" && !["completed", "failed", "skipped"].includes(current)) {
        pageStatusByUrl.set(pageTarget, "started");
      } else if (!pageStatusByUrl.has(pageTarget)) {
        pageStatusByUrl.set(pageTarget, "queued");
      }
    }

    // Only the DERIVED values are kept as search text. The original line
    // (message, details, URLs, status ...) is searched directly from the line
    // store, so the log is not duplicated in memory as a second copy.
    if (!row.isLean) row.derivedText = [
      row.fileType,
      row.mimeType,
      row.mimeGroup,
      row.domain,
      Number.isFinite(row.sizeBytes) ? row.sizeBytes : ""
    ].join(" ").toLowerCase();

    if ((i & 1023) === 0) await slicer.tick(() => report("Classifying resources", i, total));
  }

  // Page events of a non-HTML file (e.g. a linked video crawled as a page) are
  // grouped by that file's logged MIME type, not as "Web pages".
  for (let i = 0; i < total; i++) {
    const row = rows[i];
    if (!row.isPageEvent || !nonHtmlMime.has(row.pageTarget)) continue;
    const mime = nonHtmlMime.get(row.pageTarget);
    row.mimeType = row.mimeType || mime;
    row.mimeSource = row.mimeSource || "log";
    row.mimeGroup = BTLV_MIME.groupFor({ mime, url: row.pageTarget });
    if (!row.isLean) row.derivedText = [row.fileType, row.mimeType, row.mimeGroup, row.domain, Number.isFinite(row.sizeBytes) ? row.sizeBytes : ""].join(" ").toLowerCase();
    if ((i & 4095) === 0) await slicer.tick(() => report("Classifying linked files", i, total));
  }

  report("Tracing URL provenance", 0, 1);
  await yieldToBrowser();
  const provenanceByUrl = applyProvenance(rows);
  return { pageUrls, pageStatusByUrl, provenanceByUrl, nonHtmlUrls: new Set(nonHtmlMime.keys()) };
}

function extractCrawlMetadata(rows) {
  const meta = { firstSeed: "", seedCount: null, scopeType: "", maxDepth: null, maxExtraHops: null, crawlerVersion: "" };
  for (const row of rows) {
    if (!meta.crawlerVersion && /^Browsertrix-Crawler\b/i.test(row.message)) {
      meta.crawlerVersion = row.message.split(" (")[0];
    }
    if (row.message === "Seeds" && row.details && typeof row.details === "object") {
      const firstSeed = row.details.firstSeed;
      if (firstSeed && typeof firstSeed === "object") {
        meta.firstSeed = typeof firstSeed.url === "string" ? firstSeed.url : "";
        meta.scopeType = typeof firstSeed.scopeType === "string" ? firstSeed.scopeType : "";
        const maxDepth = Number(firstSeed.maxDepth);
        const maxExtraHops = Number(firstSeed.maxExtraHops);
        if (Number.isFinite(maxDepth)) meta.maxDepth = maxDepth;
        if (Number.isFinite(maxExtraHops)) meta.maxExtraHops = maxExtraHops;
      }
      const seedCount = Number(row.details.seedCount);
      if (Number.isFinite(seedCount)) meta.seedCount = seedCount;
    }
    if (meta.firstSeed && meta.crawlerVersion) break;
  }
  return meta;
}

function renderCrawlMeta() {
  els.crawlMeta.replaceChildren();
  const parts = [];

  if (state.meta.firstSeed) {
    const label = document.createElement("span");
    label.append("First seed: ");
    const a = document.createElement("a");
    a.href = state.meta.firstSeed;
    a.target = "_blank";
    a.rel = "noreferrer noopener";
    a.textContent = state.meta.firstSeed;
    label.appendChild(a);
    parts.push(label);
  }
  if (Number.isFinite(state.meta.seedCount)) parts.push(document.createTextNode(`${state.meta.seedCount.toLocaleString()} seeds`));
  if (state.meta.scopeType) parts.push(document.createTextNode(`scope: ${state.meta.scopeType}`));
  if (state.meta.crawlerVersion) parts.push(document.createTextNode(state.meta.crawlerVersion));

  parts.forEach((part, i) => {
    if (i) els.crawlMeta.append(" · ");
    els.crawlMeta.appendChild(part);
  });
  els.crawlMeta.hidden = parts.length === 0;
}

function fillFilters() {
  const levels = [...new Set(state.rows.map(r => r.logLevel).filter(Boolean))].sort();
  const contexts = [...new Set(state.rows.map(r => r.context).filter(Boolean))].sort();
  const fileTypes = [...new Set(state.rows.map(r => r.fileType).filter(Boolean).filter(t => t !== "Page"))]
    .sort((a, b) => a.localeCompare(b));
  const mimeGroups = [...new Set(state.rows.map(r => r.mimeGroup).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b));

  els.levelFilter.replaceChildren(new Option("All levels", ""));
  for (const level of levels) els.levelFilter.add(new Option(level, level));

  els.contextFilter.replaceChildren(new Option("All contexts", ""));
  for (const context of contexts) els.contextFilter.add(new Option(context, context));

  els.typeFilter.replaceChildren(new Option("All file types", ""));
  els.typeFilter.add(new Option("Pages", "Page"));
  for (const fileType of fileTypes) els.typeFilter.add(new Option(fileType, fileType));

  els.mimeGroupFilter.replaceChildren(new Option("All MIME groups", ""));
  for (const group of mimeGroups) els.mimeGroupFilter.add(new Option(group, group));
  fillStatusFilter();
}

function updateSummary() {
  const rows = state.rows;
  let minTs = Infinity;
  let maxTs = -Infinity;
  for (const row of rows) {
    if (!Number.isFinite(row.timestampMs)) continue;
    if (row.timestampMs < minTs) minTs = row.timestampMs;
    if (row.timestampMs > maxTs) maxTs = row.timestampMs;
  }
  if (!Number.isFinite(minTs)) minTs = NaN;
  if (!Number.isFinite(maxTs)) maxTs = NaN;
  const warn = rows.filter(r => r.logLevel.toLowerCase() === "warn").length;
  const error = rows.filter(r => ["error", "fatal"].includes(r.logLevel.toLowerCase())).length;
  const contexts = new Set(rows.map(r => r.context).filter(Boolean));

  $("sumEntries").textContent = rows.length.toLocaleString();
  $("sumDuration").textContent = formatDuration(maxTs - minTs);
  $("sumWarn").textContent = warn.toLocaleString();
  $("sumError").textContent = error.toLocaleString();
  $("sumPages").textContent = state.pageUrls.size.toLocaleString();
  $("sumContexts").textContent = contexts.size.toLocaleString();
}

let resourceLineCounter = 0;

// Wrapper: also reports how many log lines contributed to the resources.
function currentResourceStats(rows, ...rest) {
  resourceLineCounter = 0;
  const stats = currentResourceStatsInner(rows, ...rest);
  stats.lines = resourceLineCounter;
  return stats;
}

function currentResourceStatsInner(rows) {
  const byUrl = new Map();
  const pageUrlsInRows = new Set();
  const allPageUrls = state.pageUrls;

  for (const row of rows) {
    const pageCandidate = asHttpUrl(row.pageTarget || (row.isPageEvent ? (row.url || row.page) : ""));
    if (pageCandidate) pageUrlsInRows.add(pageCandidate);
    if (row.page) pageUrlsInRows.add(asHttpUrl(row.page));

    const url = asHttpUrl(row.url);
    if (!url || row.crawlerMade) continue;
    // HTML pages are counted as pages, not resources. A non-HTML file that
    // Browsertrix queued or crawled as a page (a linked video, PDF ...) IS a
    // resource of its type.
    if ((allPageUrls.has(url) || row.isPageEvent) && !state.nonHtmlUrls?.has(url)) continue;
    resourceLineCounter++;
    let item = byUrl.get(url);
    if (!item) {
      item = { url, fileType: row.fileType || "", mimeGroup: row.mimeGroup || "", sizeBytes: NaN };
      byUrl.set(url, item);
    }
    if (!item.fileType && row.fileType) item.fileType = row.fileType;
    if (!item.mimeGroup && row.mimeGroup) item.mimeGroup = row.mimeGroup;
    if (Number.isFinite(row.sizeBytes) && (!Number.isFinite(item.sizeBytes) || row.sizeBytes > item.sizeBytes)) {
      item.sizeBytes = row.sizeBytes;
    }
  }

  const resources = [...byUrl.values()];
  const sizes = resources.map(r => r.sizeBytes).filter(Number.isFinite).sort((a, b) => a - b);
  const total = sizes.reduce((sum, n) => sum + n, 0);
  const average = sizes.length ? total / sizes.length : NaN;
  let median = NaN;
  if (sizes.length) {
    const mid = Math.floor(sizes.length / 2);
    median = sizes.length % 2 ? sizes[mid] : (sizes[mid - 1] + sizes[mid]) / 2;
  }
  const largest = sizes.length ? sizes[sizes.length - 1] : NaN;
  return {
    count: resources.length,
    known: sizes.length,
    total,
    average,
    median,
    largest,
    pages: [...pageUrlsInRows].filter(Boolean).length
  };
}

function fillStatusFilter() {
  const codes = new Set();
  const groups = new Set();
  let suspected = false;
  let none = false;
  for (const row of state.rows) {
    if (Number.isFinite(row.statusCode)) {
      codes.add(row.statusCode);
      groups.add(Math.floor(row.statusCode / 100));
    } else {
      none = true;
    }
    if (row.suspectedBlock) suspected = true;
  }
  const sel = els.statusFilter;
  sel.replaceChildren(new Option("All statuses", ""));
  const groupBox = document.createElement("optgroup");
  groupBox.label = "Groups";
  for (const g of STATUS_GROUPS) {
    if (groups.has(Number(g.key.slice(2)))) groupBox.appendChild(new Option(`${g.label} · ${g.name}`, g.key));
  }
  if (suspected) groupBox.appendChild(new Option(SUSPECTED_LABEL, "suspected"));
  if (none) groupBox.appendChild(new Option("No status logged", "none"));
  if (groupBox.children.length) sel.appendChild(groupBox);
  if (codes.size) {
    const codeBox = document.createElement("optgroup");
    codeBox.label = "Status codes";
    for (const code of [...codes].sort((a, b) => a - b)) {
      codeBox.appendChild(new Option(STATUS_NAMES[code] ? `${code} · ${STATUS_NAMES[code]}` : String(code), `c:${code}`));
    }
    sel.appendChild(codeBox);
  }
}

// Overview of the WHOLE log: distinct URLs per status group. A URL that got
// several statuses (e.g. 429 and later 200) counts in each group it got.
// Bars use a square-root scale with a minimum width, so small but important
// groups (a few 429s among thousands of 200s) stay visible. No numbers on the
// bars; the exact count is in the tooltip and the accessible label.
function renderStatusOverview() {
  const host = els.statusOverview;
  if (!host || !state.rows.length) return;
  const sets = { "g:1": new Set(), "g:2": new Set(), "g:3": new Set(), "g:4": new Set(), "g:5": new Set(), suspected: new Set() };
  const allUrls = new Set();
  const withStatus = new Set();
  for (const row of state.rows) {
    const key = asHttpUrl(row.url) || asHttpUrl(row.pageTarget) || asHttpUrl(row.page);
    if (key && !row.crawlerMade) allUrls.add(key);
    if (Number.isFinite(row.statusCode) && key) {
      sets[`g:${Math.floor(row.statusCode / 100)}`]?.add(key);
      withStatus.add(key);
    }
    if (row.suspectedBlock) sets.suspected.add(key || `line ${row.lineNumber}`);
  }
  const bars = [...STATUS_GROUPS.map(g => ({ ...g, count: sets[g.key].size })),
    { key: "suspected", label: "Suspected", name: SUSPECTED_LABEL, count: sets.suspected.size }];
  const max = Math.max(1, ...bars.map(b => b.count));
  host.replaceChildren();
  const head = document.createElement("div");
  head.className = "so-head";
  head.innerHTML = "<strong>HTTP status overview</strong><span>distinct URLs per status group · click a bar to filter the table</span>";
  host.appendChild(head);
  for (const b of bars) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `so-row so-${b.key.replace(":", "")}${state.status === b.key ? " active" : ""}`;
    const exact = `${b.count.toLocaleString()} URL${b.count === 1 ? "" : "s"}`;
    row.title = `${b.label} · ${b.name}: ${exact}`;
    row.setAttribute("aria-label", `${b.name} (${b.label}): ${exact}. Filter the table.`);
    const label = document.createElement("span");
    label.className = "so-label";
    label.textContent = b.key === "suspected" ? "Suspected blocking" : `${b.label} ${b.name}`;
    const track = document.createElement("span");
    track.className = "so-track";
    const bar = document.createElement("span");
    bar.className = "so-bar";
    const width = b.count ? Math.max(4, Math.sqrt(b.count / max) * 100) : 0;
    bar.style.width = `${width}%`;
    track.appendChild(bar);
    if (!b.count) {
      const none = document.createElement("span");
      none.className = "so-none";
      none.textContent = "none";
      track.appendChild(none);
    }
    row.append(label, track);
    row.addEventListener("click", () => {
      const value = state.status === b.key ? "" : b.key;
      if (value && ![...els.statusFilter.options].some(o => o.value === value)) return;
      els.statusFilter.value = value;
      state.status = value;
      state.page = 1;
      applyFiltersAndSort();
      renderStatusOverview();
    });
    host.appendChild(row);
  }
  const note = document.createElement("p");
  note.className = "so-note";
  const share = allUrls.size ? Math.round((withStatus.size / allUrls.size) * 100) : 0;
  note.textContent = `Status codes are logged for ${share}% of the URLs in this log. ` +
    "At normal log level Browsertrix logs a status mainly for failed or rate-limited pages; with --logging debug it logs every page’s status and most resources’. " +
    "“Suspected blocking” uses the same rules as the diagnostics (401, 403, 407, 429, 503, challenge and rate-limit messages) and overlaps the 4xx/5xx groups.";
  host.appendChild(note);
  host.hidden = false;
}

function updateFilteredStats() {
  const stats = currentResourceStats(state.filtered);
  const hasFilters = !!(state.search.trim() || state.level || state.context || state.fileType || state.mimeGroup || state.status);

  if (state.fileType === "Page") {
    const pageSet = new Set();
    let completed = 0;
    let failed = 0;
    let started = 0;
    let skipped = 0;
    for (const row of state.filtered) {
      const url = asHttpUrl(row.pageTarget || row.url || row.page);
      if (url && state.pageUrls.has(url)) pageSet.add(url);
    }
    for (const url of pageSet) {
      const status = state.pageStatusByUrl.get(url);
      if (status === "completed") completed++;
      else if (status === "failed") failed++;
      else if (status === "started") started++;
      else if (status === "skipped") skipped++;
    }
    els.filteredStats.innerHTML =
      `<strong>Pages: ${pageSet.size.toLocaleString()} unique page URLs</strong>` +
      ` · ${completed.toLocaleString()} completed` +
      ` · ${failed.toLocaleString()} failed` +
      ` · ${skipped.toLocaleString()} skipped` +
      ` · ${started.toLocaleString()} started/not confirmed complete`;
  } else if (state.fileType || state.mimeGroup) {
    const labels = [];
    if (state.fileType) labels.push(state.fileType);
    if (state.mimeGroup) labels.push(`MIME group: ${state.mimeGroup}`);
    els.filteredStats.innerHTML =
      `<strong>${escapeHtml(labels.join(" · "))}: ${stats.count.toLocaleString()} unique resources</strong> (${stats.lines.toLocaleString()} log lines)` +
      ` · ${stats.known.toLocaleString()} with known size` +
      ` · combined ${formatBytes(stats.total)}` +
      ` · average ${formatBytes(stats.average)}` +
      ` · median ${formatBytes(stats.median)}` +
      ` · largest ${formatBytes(stats.largest)}`;
  } else {
    const prefix = hasFilters ? "Current filter" : "All log entries";
    els.filteredStats.innerHTML =
      `<strong>${prefix}: ${state.filtered.length.toLocaleString()} rows</strong>` +
      ` · ${stats.pages.toLocaleString()} unique pages` +
      ` · ${stats.count.toLocaleString()} unique resources` +
      ` · ${stats.known.toLocaleString()} resources with known size` +
      ` · ${formatBytes(stats.total)} known resource data`;
  }
  els.filteredStats.hidden = false;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function compare(a, b, key, type) {
  let av;
  let bv;
  if (type === "date") {
    // The number only: reading a[key] first would rebuild the date text on
    // every comparison for large-log rows (seconds on millions of rows).
    av = a.timestampMs;
    bv = b.timestampMs;
  } else if ((av = a[key], bv = b[key], type === "number")) {
    av = av === "" || av == null ? Number.NEGATIVE_INFINITY : Number(av);
    bv = bv === "" || bv == null ? Number.NEGATIVE_INFINITY : Number(bv);
  } else {
    av = String(av ?? "").toLowerCase();
    bv = String(bv ?? "").toLowerCase();
  }
  if (av < bv) return -1;
  if (av > bv) return 1;
  return a.index - b.index;
}

function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Text search over a row: its own fields, its derived values, and the
// "details" part of its original log line, read from the line store.
// Large-log mode: the details text is on disk, so the search worker streams
// the file once per query (same "details part" semantics as normal mode) and
// returns the matching lines.
const largeSearch = { query: null, pending: null, hits: null, id: 0, worker: null, dateLike: false };

function resetLargeSearch() {
  largeSearch.worker?.terminate();
  Object.assign(largeSearch, { query: null, pending: null, hits: null, worker: null, dateLike: false });
}

function startLargeSearch(query) {
  if (largeSearch.pending === query) return;
  largeSearch.pending = query;
  const id = ++largeSearch.id;
  els.matchCount.textContent = "Searching the log on disk…";
  if (!largeSearch.worker) {
    largeSearch.worker = new Worker("raw-search-worker.js");
    largeSearch.worker.onmessage = event => {
      const m = event.data || {};
      if (m.id !== largeSearch.id) return;
      if (m.type === "progress") {
        els.matchCount.textContent = `Searching the log on disk… ${Math.round(m.progress * 100)}%`;
      } else if (m.type === "result") {
        const hits = new Uint8Array(state.lines.length);
        if (m.lineHits) for (const i of m.lineHits) hits[i] = 1;
        largeSearch.hits = hits;
        largeSearch.query = largeSearch.pending;
        largeSearch.dateLike = /^[\d:.\-TZ ]+$/.test(largeSearch.query);
        applyFiltersAndSort();
      }
    };
    largeSearch.worker.postMessage({ type: "load", stream: true, blob: state.rawBlob });
  }
  largeSearch.worker.postMessage({ type: "search", id, query, regex: false, caseSensitive: false, detailsOnly: true });
}

function leanRowMatches(row, re) {
  if (re.test(row.message) || re.test(row.context) || re.test(row.logLevel) || re.test(row.fileType) ||
      re.test(row.mimeGroup) || re.test(row.mimeType) || re.test(row.domain)) return true;
  if (row.provenanceOrigin && re.test(row.provenanceOrigin)) return true;
  if (Number.isFinite(row.sizeBytes) && re.test(String(row.sizeBytes))) return true;
  if (largeSearch.dateLike && re.test(row.timestamp)) return true;
  return largeSearch.hits ? largeSearch.hits[row.lineNumber - 1] === 1 : false;
}

function rowMatchesQuery(row, re) {
  if (row.isLean) return leanRowMatches(row, re);
  if (re.test(row.message) || re.test(row.context) || re.test(row.logLevel) ||
      re.test(row.timestamp) || re.test(row.derivedText)) return true;
  const line = state.lines ? state.lines.getLine(row.lineNumber - 1) : "";
  const at = line.indexOf('"details"');
  return re.test(at >= 0 ? line.slice(at + 9) : line);
}

function applyFiltersAndSort() {
  const query = state.search.trim();
  const queryRe = query ? new RegExp(escapeRegExp(query), "i") : null;
  if (state.large && query && largeSearch.query !== query) {
    startLargeSearch(query); // the table updates when the disk search is done
    return;
  }
  state.filtered = state.rows.filter(row => {
    if (state.level && row.logLevel !== state.level) return false;
    if (state.context && row.context !== state.context) return false;
    if (state.fileType === "Page" && !row.isPageEvent) return false;
    if (state.fileType && state.fileType !== "Page" && row.fileType !== state.fileType) return false;
    if (state.mimeGroup && row.mimeGroup !== state.mimeGroup) return false;
    if (state.status && !rowMatchesStatus(row, state.status)) return false;
    if (queryRe && !rowMatchesQuery(row, queryRe)) return false;
    return true;
  });

  const th = document.querySelector(`th[data-key="${CSS.escape(state.sortKey)}"]`);
  const type = th?.dataset.type || "text";
  state.filtered.sort((a, b) => {
    if (state.sortKey === "sizeBytes") {
      const aMissing = !Number.isFinite(a.sizeBytes);
      const bMissing = !Number.isFinite(b.sizeBytes);
      if (aMissing !== bMissing) return aMissing ? 1 : -1;
    } else if (state.sortKey === "fileType") {
      const aMissing = !a.fileType;
      const bMissing = !b.fileType;
      if (aMissing !== bMissing) return aMissing ? 1 : -1;
    } else if (state.sortKey === "mimeGroup") {
      const aMissing = !a.mimeGroup;
      const bMissing = !b.mimeGroup;
      if (aMissing !== bMissing) return aMissing ? 1 : -1;
    } else if (state.sortKey === "domain") {
      const aMissing = !a.domain;
      const bMissing = !b.domain;
      if (aMissing !== bMissing) return aMissing ? 1 : -1;
    }
    return state.sortDir * compare(a, b, state.sortKey, type);
  });

  const maxPage = Math.max(1, Math.ceil(state.filtered.length / state.pageSize));
  state.page = Math.min(Math.max(1, state.page), maxPage);
  render();
}

function tdText(text, className = "") {
  const td = document.createElement("td");
  if (className) td.className = className;
  if (text === "" || text == null) {
    const span = document.createElement("span");
    span.className = "empty";
    span.textContent = "—";
    td.appendChild(span);
  } else {
    td.textContent = String(text);
  }
  return td;
}

function typeCell(row) {
  const td = tdText(row.fileType);
  if (row.soft404Suspect) {
    const badge = document.createElement("span");
    badge.className = "soft404-badge";
    badge.textContent = "SOFT404?";
    badge.title = "Same first-seed host, same type and approximately the same size as the soft-404 probe response";
    td.appendChild(badge);
  }
  return td;
}

function urlCell(url) {
  const td = document.createElement("td");
  td.className = "url-cell mono";
  if (!url) {
    td.innerHTML = '<span class="empty">—</span>';
    return td;
  }
  const a = document.createElement("a");
  a.href = url;
  a.target = "_blank";
  a.rel = "noreferrer noopener";
  a.textContent = url;
  a.title = url;
  td.appendChild(a);
  return td;
}

function statusCell(status) {
  const td = tdText(status, "mono");
  const n = Number(status);
  if (Number.isFinite(n)) td.classList.add(n >= 200 && n < 400 ? "status-ok" : "status-bad");
  return td;
}

// The details toggle lives at the end of the Message cell (v1.8.0); there is
// no separate Details column. It expands a full-width row below the event.
function detailsButton(row, tr) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "details-button";
  const count = row.isLean ? -1 : (row.details && typeof row.details === "object" ? Object.keys(row.details).length : 0);
  btn.textContent = detailsLabel(count);
  btn.title = `Show raw details (source line ${row.lineNumber})`;
  btn.setAttribute("aria-expanded", "false");

  btn.addEventListener("click", () => {
    const existing = tr.nextElementSibling;
    if (existing?.classList.contains("details-row")) {
      existing.remove();
      btn.textContent = detailsLabel(count);
      btn.setAttribute("aria-expanded", "false");
      return;
    }
    const detailTr = document.createElement("tr");
    detailTr.className = "details-row";
    const detailTd = document.createElement("td");
    detailTd.colSpan = DEFAULT_COLUMN_ORDER.length;
    const pre = document.createElement("pre");
    pre.className = "details-pre";
    fillDetails(pre, row);
    const rawLink = document.createElement("button");
    rawLink.type = "button";
    rawLink.className = "details-raw-link";
    rawLink.textContent = `Show source line ${row.lineNumber.toLocaleString()} in raw log`;
    rawLink.addEventListener("click", () => showRawLine(row.lineNumber));
    detailTd.append(rawLink, pre);
    detailTr.appendChild(detailTd);
    tr.after(detailTr);
    btn.textContent = "Hide";
    btn.setAttribute("aria-expanded", "true");
  });

  return btn;
}

function detailsLabel(count) {
  if (count < 0) return "details"; // large-log mode: the count is on disk
  return count ? `${count} fields` : "{}";
}

// In large-log mode the full details are read from disk when opened.
function fillDetails(pre, row) {
  if (!row.isLean) {
    pre.textContent = JSON.stringify(row.details, null, 2);
    return;
  }
  pre.textContent = "Reading this line from disk…";
  state.lines.readLine(row.lineNumber - 1).then(line => {
    try {
      pre.textContent = JSON.stringify(JSON.parse(line.trim()).details ?? {}, null, 2);
    } catch (_) {
      pre.textContent = line;
    }
  }).catch(error => {
    pre.textContent = `Could not read this line from disk: ${error?.message || error}`;
  });
}

function messageCell(row, tr) {
  const td = document.createElement("td");
  td.className = "message-cell";
  const text = document.createElement("span");
  text.className = "message-text";
  text.textContent = row.message;
  td.append(text, " ", detailsButton(row, tr));
  return td;
}

function render() {
  const total = state.filtered.length;
  const maxPage = Math.max(1, Math.ceil(total / state.pageSize));
  const start = (state.page - 1) * state.pageSize;
  const end = Math.min(start + state.pageSize, total);
  const slice = state.filtered.slice(start, end);

  const fragment = document.createDocumentFragment();
  for (const row of slice) {
    const tr = document.createElement("tr");
    if (row.soft404Suspect) {
      tr.classList.add("soft404-suspect");
      tr.title = "Suspected soft 404: resource resembles the soft-404 probe response";
    }

    const cells = {};
    const timeTd = tdText(row.timestamp, "mono");
    timeTd.title = `Source line ${row.lineNumber}`;
    cells.timestamp = timeTd;

    const levelTd = document.createElement("td");
    const levelSpan = document.createElement("span");
    const level = row.logLevel.toLowerCase();
    levelSpan.className = `level level-${level || "debug"}`;
    levelSpan.textContent = row.logLevel || "—";
    levelTd.appendChild(levelSpan);
    cells.logLevel = levelTd;

    cells.context = tdText(row.context);
    cells.message = messageCell(row, tr);
    cells.status = statusCell(row.status);
    cells.workerid = tdText(row.workerid, "mono");
    cells.fileType = typeCell(row);
    const mimeGroupTd = tdText(row.mimeGroup);
    if (row.mimeType) mimeGroupTd.title = `${row.mimeType}${row.mimeSource === "extension" ? " (inferred from recognized file extension)" : ""}`;
    cells.mimeGroup = mimeGroupTd;
    const sizeTd = tdText(Number.isFinite(row.sizeBytes) ? formatBytes(row.sizeBytes) : "", "mono size-cell");
    if (Number.isFinite(row.sizeBytes)) sizeTd.title = `${row.sizeBytes.toLocaleString()} bytes`;
    cells.sizeBytes = sizeTd;
    const domainTd = tdText(row.domain, "mono domain-cell");
    if (row.domain) domainTd.title = row.domain;
    cells.domain = domainTd;
    cells.url = urlCell(row.url);
    cells.page = urlCell(row.page);
    cells.provenanceOrigin = originCell(row);

    // Cells follow the user's column order; every column is always rendered.
    for (const key of state.columnOrder) tr.appendChild(cells[key]);
    fragment.appendChild(tr);
  }

  els.tbody.replaceChildren(fragment);
  els.matchCount.textContent = `${total.toLocaleString()} / ${state.rows.length.toLocaleString()} rows`;
  els.pageInfo.textContent = total ? `Page ${state.page} of ${maxPage} · rows ${(start + 1).toLocaleString()}–${end.toLocaleString()}` : "No matching rows";
  els.firstPage.disabled = state.page <= 1;
  els.prevPage.disabled = state.page <= 1;
  els.nextPage.disabled = state.page >= maxPage;
  els.lastPage.disabled = state.page >= maxPage;

  document.querySelectorAll("th[data-key]").forEach(th => {
    th.classList.remove("sorted-asc", "sorted-desc");
    if (th.dataset.key === state.sortKey) th.classList.add(state.sortDir === 1 ? "sorted-asc" : "sorted-desc");
  });
  updateFilteredStats();
}

function resetSoft404() {
  for (const row of state.rows) row.soft404Suspect = false;
  state.soft404 = {
    state: "idle",
    origin: "",
    host: "",
    testUrl: "",
    finalUrl: "",
    status: null,
    statusText: "",
    fileType: "",
    contentType: "",
    bodySize: NaN,
    headerSize: NaN,
    suspectUrls: new Set(),
    error: ""
  };
}

function permissionPatternForOrigin(origin) {
  // Request only the concrete first-seed host. The manifest declares the
  // broader optional pattern *://*/*, from which Chrome allows subsets.
  const u = new URL(origin);
  return `${u.protocol}//${u.host}/*`;
}

function manifestAllowsRuntimeHostRequests() {
  const manifest = chrome.runtime.getManifest?.() || {};
  const patterns = manifest.optional_host_permissions || [];
  return patterns.includes("*://*/*") || patterns.includes("<all_urls>") ||
    patterns.includes("https://*/*") || patterns.includes("http://*/*");
}

function soft404ReferenceSizes() {
  const values = [state.soft404.bodySize, state.soft404.headerSize].filter(n => Number.isFinite(n) && n > 0);
  return [...new Set(values)];
}

function isNearProbeSize(sizeBytes) {
  if (!Number.isFinite(sizeBytes)) return false;
  return soft404ReferenceSizes().some(reference => {
    const tolerance = Math.max(SOFT404_TOLERANCE_MIN_BYTES, reference * SOFT404_TOLERANCE_RATIO);
    return Math.abs(sizeBytes - reference) <= tolerance;
  });
}

function markSoft404Suspects() {
  for (const row of state.rows) row.soft404Suspect = false;
  const suspectUrls = new Set();

  if (state.soft404.status !== 200 || !state.soft404.host || !state.soft404.fileType) {
    state.soft404.suspectUrls = suspectUrls;
    return;
  }

  for (const row of state.rows) {
    if (row.crawlerMade) continue; // made by the crawler, not served by the site
    const matchType = row.contentFileType || row.fileType;
    if (!row.url || !matchType || !Number.isFinite(row.sizeBytes)) continue;
    if (matchType !== state.soft404.fileType) continue;
    let host = "";
    try { host = new URL(row.url).host; } catch (_) { continue; }
    if (host !== state.soft404.host) continue;
    if (isNearProbeSize(row.sizeBytes)) suspectUrls.add(row.url);
  }

  for (const row of state.rows) {
    if (row.url && !row.crawlerMade && suspectUrls.has(row.url)) row.soft404Suspect = true;
  }
  state.soft404.suspectUrls = suspectUrls;
}

function renderSoft404Panel() {
  const s = state.soft404;
  els.soft404Panel.className = "soft404-panel";
  els.soft404Test.hidden = true;

  if (!state.meta.firstSeed) {
    els.soft404Panel.hidden = true;
    return;
  }

  els.soft404Panel.hidden = false;
  els.soft404Title.textContent = "Soft-404 test";

  if (s.state === "permission") {
    els.soft404Panel.classList.add("pending");
    els.soft404Text.textContent = `Permission is needed to request ${s.testUrl}.`;
    els.soft404Test.textContent = "Run soft-404 test";
    els.soft404Test.hidden = false;
  } else if (s.state === "running") {
    els.soft404Panel.classList.add("pending");
    els.soft404Text.textContent = `Requesting ${s.testUrl}…`;
  } else if (s.state === "detected") {
    els.soft404Panel.classList.add("warn");
    const sizes = soft404ReferenceSizes().map(formatBytes).join(" / ") || "unknown size";
    const type = s.fileType || s.contentType || "unknown type";
    const redirects = s.finalUrl && s.finalUrl !== s.testUrl ? ` · final URL ${s.finalUrl}` : "";
    els.soft404Title.textContent = "Soft 404 detected";
    els.soft404Text.textContent = `${s.host} returned HTTP 200 for ${SOFT404_PATH} · ${type} · ${sizes}${redirects} · ${s.suspectUrls.size.toLocaleString()} similar resource URLs marked.`;
    els.soft404Test.textContent = "Retest";
    els.soft404Test.hidden = false;
  } else if (s.state === "clear") {
    els.soft404Panel.classList.add("good");
    els.soft404Title.textContent = "No soft-404 signal";
    els.soft404Text.textContent = `${s.host} returned HTTP ${s.status}${s.statusText ? ` ${s.statusText}` : ""} for ${SOFT404_PATH}.`;
    els.soft404Test.textContent = "Retest";
    els.soft404Test.hidden = false;
  } else if (s.state === "error") {
    els.soft404Panel.classList.add("error");
    els.soft404Title.textContent = "Soft-404 test failed";
    els.soft404Text.textContent = s.error || "The probe request failed.";
    els.soft404Test.textContent = "Retry";
    els.soft404Test.hidden = false;
  } else if (s.state === "unavailable") {
    els.soft404Panel.classList.add("pending");
    els.soft404Text.textContent = "The first seed is not an HTTP/HTTPS URL, so the probe cannot be run.";
  } else {
    els.soft404Panel.classList.add("pending");
    els.soft404Text.textContent = "Waiting to test the first-seed host.";
  }
}

function prepareSoft404Target() {
  if (!state.meta.firstSeed) return false;
  try {
    const seed = new URL(state.meta.firstSeed);
    if (!["http:", "https:"].includes(seed.protocol)) {
      state.soft404.state = "unavailable";
      renderSoft404Panel();
      return false;
    }
    state.soft404.origin = seed.origin;
    state.soft404.host = seed.host;
    state.soft404.testUrl = new URL(SOFT404_PATH, seed.origin).href;
    return true;
  } catch (_) {
    state.soft404.state = "unavailable";
    renderSoft404Panel();
    return false;
  }
}

async function runSoft404Probe(requestPermission = false) {
  if (!prepareSoft404Target()) return;
  const pattern = permissionPatternForOrigin(state.soft404.origin);

  try {
    let allowed;
    if (requestPermission) {
      // Called directly from the viewer button so Chrome can show the permission prompt.
      // Chrome only permits runtime requests that are subsets of a manifest-declared
      // optional host permission. The current manifest declares *://*/* for this purpose.
      if (!manifestAllowsRuntimeHostRequests()) {
        throw new Error(`This installed extension manifest does not declare runtime host access. Reload Browsertrix Crawl Log Viewer v${chrome.runtime.getManifest().version} in chrome://extensions and retry.`);
      }
      allowed = await chrome.permissions.request({ origins: [pattern] });
    } else {
      allowed = await chrome.permissions.contains({ origins: [pattern] });
    }

    if (!allowed) {
      state.soft404.state = "permission";
      renderSoft404Panel();
      return;
    }

    state.soft404.state = "running";
    state.soft404.error = "";
    renderSoft404Panel();

    const response = await fetch(state.soft404.testUrl, {
      method: "GET",
      credentials: "omit",
      cache: "no-store",
      redirect: "follow"
    });

    state.soft404.status = response.status;
    state.soft404.statusText = response.statusText || "";
    state.soft404.finalUrl = response.url || state.soft404.testUrl;
    state.soft404.contentType = response.headers.get("content-type") || "";
    const contentLength = Number(response.headers.get("content-length"));
    state.soft404.headerSize = Number.isFinite(contentLength) && contentLength >= 0 ? contentLength : NaN;

    if (response.status === 200) {
      const body = await response.arrayBuffer();
      state.soft404.bodySize = body.byteLength;
      state.soft404.fileType = mimeToType(state.soft404.contentType) || typeFromUrl(state.soft404.finalUrl);

      // Last-resort HTML sniff if the server omitted Content-Type and the URL has no useful extension.
      if (!state.soft404.fileType && body.byteLength) {
        const prefix = new TextDecoder("utf-8", { fatal: false }).decode(body.slice(0, Math.min(body.byteLength, 1024))).trimStart().toLowerCase();
        if (prefix.startsWith("<!doctype html") || prefix.startsWith("<html")) state.soft404.fileType = "HTML";
      }

      state.soft404.state = "detected";
      markSoft404Suspects();
    } else {
      state.soft404.bodySize = NaN;
      state.soft404.fileType = mimeToType(state.soft404.contentType) || typeFromUrl(state.soft404.finalUrl);
      state.soft404.state = "clear";
      markSoft404Suspects();
    }
  } catch (error) {
    state.soft404.state = "error";
    state.soft404.error = `${state.soft404.testUrl}: ${error?.message || error}`;
    markSoft404Suspects();
  }

  renderSoft404Panel();
  renderDiagnostics();
  applyFiltersAndSort();
}

async function initializeSoft404Probe() {
  resetSoft404();
  if (!prepareSoft404Target()) return;
  renderSoft404Panel();
  await runSoft404Probe(false);
}


function maxOf(values) {
  let max = NaN;
  for (const value of values) {
    if (Number.isFinite(value) && !(value <= max)) max = value;
  }
  return max;
}

function countBy(values) {
  const map = new Map();
  for (const value of values) {
    const key = String(value || "");
    if (!key) continue;
    map.set(key, (map.get(key) || 0) + 1);
  }
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

function numericValuesFromDetails(details, keys) {
  const out = [];
  if (!details || typeof details !== "object") return out;
  for (const key of keys) {
    const value = Number(details[key]);
    if (Number.isFinite(value)) out.push({ key, value });
  }
  return out;
}

// ------------------------------------------------- status codes & blocking
// ONE definition of "suspected blocking / throttling / rate limiting", shared
// by the diagnostics, the status dropdown and the status overview, so they can
// never disagree.
const BLOCKING_TEXT_RE = /(captcha|access denied|forbidden|cloudflare challenge|cf challenge|blocked by|blocking detected|security challenge)/i;
const THROTTLE_TEXT_RE = /(rate.?limit|throttl|too many requests)/i;
const SUSPECT_STATUS = new Set([401, 403, 407, 429, 503]);

// Message plus the explanatory details fields. Most rows have none of the
// extra fields, so the message itself is returned without building a string.
function diagnosticText(r) {
  const d = r.details;
  const extra = [d?.message, d?.error, d?.reason, d?.statusText].filter(v => typeof v === "string");
  return extra.length ? `${r.message} ${extra.join(" ")}` : r.message;
}

function statusCodeOf(row) {
  const n = Number(row.status);
  return Number.isInteger(n) && n >= 100 && n <= 599 ? n : NaN;
}

function isSuspectedBlocking(row) {
  if (SUSPECT_STATUS.has(statusCodeOf(row))) return true;
  const text = diagnosticText(row);
  return (row.message !== "Check CF Blocking" && BLOCKING_TEXT_RE.test(text)) || THROTTLE_TEXT_RE.test(text);
}

const STATUS_NAMES = {
  100: "Continue", 101: "Switching Protocols", 200: "OK", 201: "Created", 202: "Accepted", 203: "Non-Authoritative Information",
  204: "No Content", 206: "Partial Content", 300: "Multiple Choices", 301: "Moved Permanently", 302: "Found", 303: "See Other",
  304: "Not Modified", 307: "Temporary Redirect", 308: "Permanent Redirect", 400: "Bad Request", 401: "Unauthorized",
  402: "Payment Required", 403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed", 406: "Not Acceptable",
  407: "Proxy Authentication Required", 408: "Request Timeout", 409: "Conflict", 410: "Gone", 411: "Length Required",
  412: "Precondition Failed", 413: "Content Too Large", 414: "URI Too Long", 415: "Unsupported Media Type",
  416: "Range Not Satisfiable", 421: "Misdirected Request", 422: "Unprocessable Content", 425: "Too Early",
  426: "Upgrade Required", 428: "Precondition Required", 429: "Too Many Requests", 431: "Request Header Fields Too Large",
  451: "Unavailable For Legal Reasons", 500: "Internal Server Error", 501: "Not Implemented", 502: "Bad Gateway",
  503: "Service Unavailable", 504: "Gateway Timeout", 505: "HTTP Version Not Supported"
};
const STATUS_GROUPS = [
  { key: "g:1", label: "1xx", name: "Informational" },
  { key: "g:2", label: "2xx", name: "Success" },
  { key: "g:3", label: "3xx", name: "Redirect" },
  { key: "g:4", label: "4xx", name: "Client error" },
  { key: "g:5", label: "5xx", name: "Server error" }
];
const SUSPECTED_LABEL = "Suspected blocking / throttling / rate limiting";

function rowMatchesStatus(row, value) {
  if (!value) return true;
  if (value === "none") return !Number.isFinite(row.statusCode);
  if (value === "suspected") return !!row.suspectedBlock;
  if (value.startsWith("g:")) return Math.floor(row.statusCode / 100) === Number(value.slice(2));
  if (value.startsWith("c:")) return row.statusCode === Number(value.slice(2));
  return true;
}

// Crawl-level limits, matching Browsertrix Crawler's own messages (all info
// level, except "Failed threshold" which is fatal):
//   "Size threshold reached <n> >= <limit>, stopping"
//   "Time threshold reached <n> > <limit>, stopping"
//   "Failed threshold reached <n> >= <limit>, failing crawl"
//   "Disk utilization threshold reached <n>% > <limit>%, stopping"
//   "Disk utilization projected to reach threshold <n>% > <limit>%, stopping"
//   "Page limit reached when adding URL list, some URLs not crawled."
function isCrawlLimitMessage(message) {
  if (/retry limit reached/i.test(message)) return false;
  return /^(size|time|failed|disk utilization) threshold reached\b/i.test(message) ||
    /^disk utilization projected to reach threshold\b/i.test(message) ||
    /^page limit reached\b/i.test(message) ||
    /\bquota (reached|exceeded)\b/i.test(message);
}

function isDiskUtilizationStop(message) {
  return /^disk utilization (threshold reached|projected to reach threshold)\b/i.test(message);
}

function buildDeterministicAnalysis() {
  const rows = state.rows;
  const memoryRows = rows.filter(r => r.context === "memoryStatus" || r.message === "Memory");
  const memorySamples = memoryRows.map(r => ({
    timestamp: r.timestamp,
    rss: firstFiniteNumber(r.details?.rss),
    heapUsed: firstFiniteNumber(r.details?.heapUsed),
    heapTotal: firstFiniteNumber(r.details?.heapTotal),
    maxHeapUsed: firstFiniteNumber(r.details?.maxHeapUsed),
    maxHeapTotal: firstFiniteNumber(r.details?.maxHeapTotal),
    external: firstFiniteNumber(r.details?.external),
    arrayBuffers: firstFiniteNumber(r.details?.arrayBuffers)
  }));
  const finite = (arr, key) => arr.map(x => x[key]).filter(Number.isFinite);
  const rssValues = finite(memorySamples, "rss");
  const heapValues = finite(memorySamples, "heapUsed");
  const firstRss = rssValues.length ? rssValues[0] : NaN;
  const endRss = rssValues.length ? rssValues[rssValues.length - 1] : NaN;
  // A loop, not Math.max(...values): spreading >~120k samples overflows the
  // call stack, and this runs during log loading.
  const peakRss = maxOf(rssValues);
  const peakHeap = maxOf(heapValues);
  const memoryGrowthBytes = Number.isFinite(firstRss) && Number.isFinite(endRss) ? endRss - firstRss : NaN;
  const memoryGrowthRatio = Number.isFinite(firstRss) && firstRss > 0 && Number.isFinite(endRss) ? endRss / firstRss : NaN;
  const memoryTrendConcern = Number.isFinite(memoryGrowthBytes) && Number.isFinite(memoryGrowthRatio) && memoryGrowthBytes > 512 * 1024 * 1024 && memoryGrowthRatio > 1.75;

  // CPU metrics, storage metrics and crawl limits in ONE pass. Each row's own
  // detail fields are walked once and checked against a set of interesting
  // keys, instead of looking up ~16 possible keys on every row (slow on
  // hundreds of thousands of differently shaped objects).
  const cpuMetricKeys = ["cpu", "cpuUsage", "cpuPercent", "cpuUsagePercent", "systemCpu", "userCpu", "loadAverage"];
  const storageMetricKeys = ["diskFree", "diskUsed", "storageFree", "storageUsed", "freeSpace", "availableSpace", "bytesFree", "bytesUsed"];
  const cpuKeySet = new Set(cpuMetricKeys);
  const storageKeySet = new Set(storageMetricKeys);
  const cpuRows = [];
  const cpuMetrics = [];
  const storageMetrics = [];
  const limitRows = [];
  const cpuTextRe = /\bcpu\b|load average/i;
  for (const r of rows) {
    const d = r.details;
    let hasCpuMetric = false;
    const rowCpu = [];
    if (d && typeof d === "object") {
      for (const key in d) {
        if (cpuKeySet.has(key)) {
          const value = Number(d[key]);
          if (Number.isFinite(value)) {
            hasCpuMetric = true;
            rowCpu.push({ key, value, timestamp: r.timestamp });
          }
        } else if (storageKeySet.has(key)) {
          const value = Number(d[key]);
          if (Number.isFinite(value)) storageMetrics.push({ key, value, timestamp: r.timestamp });
        } else if (key === "limit" && d.limit && typeof d.limit === "object") {
          limitRows.push(r);
        }
      }
    }
    if (hasCpuMetric || cpuTextRe.test(r.message) || cpuTextRe.test(r.context)) {
      cpuRows.push(r);
      for (const metric of rowCpu) cpuMetrics.push(metric);
    }
  }

  const statusCounts = new Map();
  for (const row of rows) {
    const n = Number(row.status);
    if (Number.isInteger(n) && n >= 100 && n <= 599) statusCounts.set(n, (statusCounts.get(n) || 0) + 1);
  }
  const statusCount = code => statusCounts.get(code) || 0;

  const cfChecks = rows.filter(r => r.message === "Check CF Blocking").length;
  // One pass for both, computing each row's text once.
  const blockingRows = [];
  const throttleRows = [];
  for (const r of rows) {
    const text = diagnosticText(r);
    if (r.message !== "Check CF Blocking" &&
        BLOCKING_TEXT_RE.test(text)) blockingRows.push(r);
    if (THROTTLE_TEXT_RE.test(text)) throttleRows.push(r);
  }
  const timeoutRows = rows.filter(r => /(timed out|timeout)/i.test(r.message));
  const ignoredTimeoutRows = timeoutRows.filter(r => /(timed out|timeout).{0,30}ignor/i.test(r.message));
  const ignoredTimeoutSet = new Set(ignoredTimeoutRows); // a Set: includes() was quadratic
  const seriousTimeoutRows = timeoutRows.filter(r => !ignoredTimeoutSet.has(r));

  const storageIssueRows = rows.filter(r => {
    // Browsertrix logs disk-utilization stops at info level.
    if (isDiskUtilizationStop(r.message)) return true;
    if (!["warn", "error", "fatal"].includes(r.logLevel.toLowerCase())) return false;
    const hay = `${r.message} ${JSON.stringify(r.details)}`; // warn/error rows only: few
    return /(ENOSPC|no space left|disk full|storage.{0,30}(quota|limit|error|fail)|quota.{0,20}(exceed|limit)|WACZ.{0,30}(error|fail)|WARC.{0,30}(error|fail)|upload.{0,30}(error|fail))/i.test(hay);
  });

  const lastLimit = limitRows.length ? limitRows[limitRows.length - 1].details.limit : null;
  const explicitLimitHitRows = limitRows.filter(r => r.details.limit?.hit === true);
  // Only crawl-level stop/limit messages count. Per-page retry exhaustion
  // ("Page Load Failed: retry limit reached") is a page failure, not a limit.
  const limitMessageRows = rows.filter(r => isCrawlLimitMessage(r.message));
  const limitHit = explicitLimitHitRows.length > 0 || limitMessageRows.length > 0 || lastLimit?.hit === true;
  // Browsertrix logs limit.max = pageLimit || 0, so 0 means "no page limit".
  const rawLimitMax = Number(lastLimit?.max);
  const limitMax = Number.isFinite(rawLimitMax) && rawLimitMax > 0 ? rawLimitMax : NaN;
  const pageLimitConfigured = limitRows.length ? Number.isFinite(limitMax) : null;

  const crawlStatsRows = rows.filter(r => r.message === "Crawl statistics" && r.details && typeof r.details === "object");
  const finalCrawl = crawlStatsRows.length ? crawlStatsRows[crawlStatsRows.length - 1].details : {};
  const crawl = {
    crawled: Number.isFinite(Number(finalCrawl.crawled)) ? Number(finalCrawl.crawled) : null,
    total: Number.isFinite(Number(finalCrawl.total)) ? Number(finalCrawl.total) : null,
    pending: Number.isFinite(Number(finalCrawl.pending)) ? Number(finalCrawl.pending) : null,
    failed: Number.isFinite(Number(finalCrawl.failed)) ? Number(finalCrawl.failed) : null,
    excluded: Number.isFinite(Number(finalCrawl.excluded)) ? Number(finalCrawl.excluded) : null
  };

  const resourceMap = new Map();
  for (const row of rows) {
    const url = asHttpUrl(row.url);
    if (!url || state.pageUrls.has(url) || row.isPageEvent) continue;
    let item = resourceMap.get(url);
    if (!item) {
      item = { url, domain: domainFromUrl(url), type: row.fileType || "Unknown", mimeGroup: row.mimeGroup || "Unclassified", size: NaN };
      resourceMap.set(url, item);
    }
    if (item.type === "Unknown" && row.fileType) item.type = row.fileType;
    if (item.mimeGroup === "Unclassified" && row.mimeGroup) item.mimeGroup = row.mimeGroup;
    if (Number.isFinite(row.sizeBytes) && (!Number.isFinite(item.size) || row.sizeBytes > item.size)) item.size = row.sizeBytes;
  }
  const resources = [...resourceMap.values()];
  const typeGroups = new Map();
  const mimeGroups = new Map();
  const domainGroups = new Map();
  for (const r of resources) {
    const type = r.type || "Unknown";
    const tg = typeGroups.get(type) || { type, count: 0, knownSizeCount: 0, bytes: 0 };
    tg.count++;
    if (Number.isFinite(r.size)) { tg.knownSizeCount++; tg.bytes += r.size; }
    typeGroups.set(type, tg);

    const mimeGroup = r.mimeGroup || "Unclassified";
    const mg = mimeGroups.get(mimeGroup) || { group: mimeGroup, count: 0, knownSizeCount: 0, bytes: 0 };
    mg.count++;
    if (Number.isFinite(r.size)) { mg.knownSizeCount++; mg.bytes += r.size; }
    mimeGroups.set(mimeGroup, mg);

    const domain = r.domain || "Unknown";
    const dg = domainGroups.get(domain) || { domain, count: 0, knownSizeCount: 0, bytes: 0 };
    dg.count++;
    if (Number.isFinite(r.size)) { dg.knownSizeCount++; dg.bytes += r.size; }
    domainGroups.set(domain, dg);
  }
  const topTypes = [...typeGroups.values()].sort((a, b) => b.bytes - a.bytes || b.count - a.count).slice(0, 8);
  const topMimeGroups = [...mimeGroups.values()].sort((a, b) => b.bytes - a.bytes || b.count - a.count).slice(0, 8);
  const topDomains = [...domainGroups.values()].sort((a, b) => b.bytes - a.bytes || b.count - a.count).slice(0, 8);
  const largestResources = resources.filter(r => Number.isFinite(r.size)).sort((a, b) => b.size - a.size).slice(0, 8);

  const warningMessages = countBy(rows.filter(r => r.logLevel.toLowerCase() === "warn").map(r => r.message)).slice(0, 8);
  const errorMessages = countBy(rows.filter(r => ["error", "fatal"].includes(r.logLevel.toLowerCase())).map(r => r.message)).slice(0, 8);

  const blockingStatusTotal = statusCount(401) + statusCount(403) + statusCount(407) + statusCount(429);
  let blockingAssessment = "none";
  if (statusCount(429) > 0 || blockingRows.length > 0 || statusCount(403) >= 3) blockingAssessment = "likely";
  else if (blockingStatusTotal > 0 || statusCount(503) >= 3 || throttleRows.length > 0) blockingAssessment = "possible";

  return {
    crawl,
    pages: state.pageUrls.size,
    resources: resources.length,
    memory: {
      samples: memorySamples.length,
      firstRss,
      endRss,
      peakRss,
      peakHeap,
      growthBytes: memoryGrowthBytes,
      growthRatio: memoryGrowthRatio,
      trendConcern: memoryTrendConcern
    },
    cpu: {
      telemetryPresent: cpuRows.length > 0,
      rows: cpuRows.length,
      metrics: cpuMetrics.slice(0, 20)
    },
    storage: {
      telemetryPresent: storageMetrics.length > 0,
      metrics: storageMetrics.slice(0, 20),
      issueCount: storageIssueRows.length,
      issues: storageIssueRows.slice(0, 6).map(r => r.message)
    },
    limits: {
      hit: limitHit,
      max: Number.isFinite(limitMax) ? limitMax : null,
      pageLimitConfigured,
      explicitHitRows: explicitLimitHitRows.length,
      messages: limitMessageRows.slice(0, 6).map(r => r.message)
    },
    blocking: {
      assessment: blockingAssessment,
      cfChecks,
      http401: statusCount(401),
      http403: statusCount(403),
      http407: statusCount(407),
      http429: statusCount(429),
      http503: statusCount(503),
      blockingSignals: blockingRows.length,
      throttleSignals: throttleRows.length
    },
    timeouts: {
      total: timeoutRows.length,
      ignored: ignoredTimeoutRows.length,
      serious: seriousTimeoutRows.length
    },
    soft404: {
      state: state.soft404.state,
      host: state.soft404.host,
      status: state.soft404.status,
      suspectedUrls: state.soft404.suspectUrls.size
    },
    topTypes,
    topMimeGroups,
    topDomains,
    largestResources,
    warningMessages,
    errorMessages
  };
}

// Browsertrix Crawler logs a page's HTTP status only when the page fails or is
// rate-limited. A page that loads with 403/404/5xx is logged as "Page Finished"
// without a status, so "no signal" here is not proof that nothing was blocked.
const BLOCKING_COVERAGE_NOTE = "Based on statuses and messages in the log. At normal log level Browsertrix logs a page's HTTP status only for failed or rate-limited pages; pages that loaded with 4xx/5xx appear as \u201cPage Finished\u201d without a status. Crawls logged with --logging debug include every page's status (\u201cSetting page timestamp\u201d). Per-page statuses are also in pages/pages.jsonl inside the WACZ.";

function diagnosticChip(text, tone = "") {
  const span = document.createElement("span");
  span.className = `diag-chip ${tone}`.trim();
  span.textContent = text;
  return span;
}

function renderDiagnostics() {
  if (!state.rows.length) {
    els.analysisPanel.hidden = true;
    return;
  }
  const d = buildDeterministicAnalysis();
  state.diagnostics = d;
  els.diagnosticFacts.replaceChildren();

  if (d.limits.max != null) {
    els.diagnosticFacts.appendChild(diagnosticChip(
      d.limits.hit ? `Crawl limit HIT (page limit ${d.limits.max.toLocaleString()})` : `Page limit not hit (${d.limits.max.toLocaleString()})`,
      d.limits.hit ? "bad" : "good"
    ));
  } else if (d.limits.pageLimitConfigured === false) {
    els.diagnosticFacts.appendChild(diagnosticChip(d.limits.hit ? "A crawl limit was reached" : "No page limit configured · no limit hit logged", d.limits.hit ? "bad" : ""));
  } else {
    els.diagnosticFacts.appendChild(diagnosticChip(d.limits.hit ? "A limit was reached" : "No explicit limit hit logged", d.limits.hit ? "bad" : ""));
  }

  if (Number.isFinite(d.memory.peakRss)) {
    const memText = `Crawler process peak RSS ${formatBytes(d.memory.peakRss)}` + (Number.isFinite(d.memory.endRss) ? ` · end ${formatBytes(d.memory.endRss)}` : "");
    const memChip = diagnosticChip(memText, d.memory.trendConcern ? "warn" : "");
    memChip.title = "Memory of the Browsertrix Crawler Node.js process (process.memoryUsage), from debug-level memoryStatus lines. Chrome/browser memory is not included.";
    els.diagnosticFacts.appendChild(memChip);
  } else {
    const noMem = diagnosticChip("RAM telemetry not logged");
    noMem.title = "Browsertrix logs memory only at debug level (memoryStatus context). Run the crawl with --logging debug to get it.";
    els.diagnosticFacts.appendChild(noMem);
  }

  els.diagnosticFacts.appendChild(diagnosticChip(d.cpu.telemetryPresent ? "CPU telemetry present" : "CPU telemetry not logged"));
  const storageText = d.storage.issueCount
    ? `${d.storage.issueCount.toLocaleString()} storage/write issue signals`
    : d.storage.telemetryPresent
      ? "Storage telemetry present · no write errors logged"
      : "No storage capacity telemetry · no write errors logged";
  els.diagnosticFacts.appendChild(diagnosticChip(storageText, d.storage.issueCount ? "bad" : "good"));

  const blockTone = d.blocking.assessment === "likely" ? "bad" : d.blocking.assessment === "possible" ? "warn" : "";
  const blockText = d.blocking.assessment === "none"
    ? "No blocking/throttling signal in log events"
    : `${d.blocking.assessment === "likely" ? "Likely" : "Possible"} blocking/throttling`;
  const blockChip = diagnosticChip(blockText, blockTone);
  blockChip.title = BLOCKING_COVERAGE_NOTE;
  els.diagnosticFacts.appendChild(blockChip);

  if (d.soft404.state === "detected") {
    els.diagnosticFacts.appendChild(diagnosticChip(`Soft 404 detected · ${d.soft404.suspectedUrls.toLocaleString()} suspects`, "warn"));
  }
  if (d.timeouts.serious) {
    els.diagnosticFacts.appendChild(diagnosticChip(`${d.timeouts.serious.toLocaleString()} potentially significant timeout log entries`, "warn"));
  } else if (d.timeouts.ignored) {
    els.diagnosticFacts.appendChild(diagnosticChip(`${d.timeouts.ignored.toLocaleString()} timeout entries explicitly logged as ignored`));
  }

  els.analysisPanel.hidden = false;
}

function aiOptions() {
  return {
    expectedInputs: [{ type: "text", languages: ["en"] }],
    expectedOutputs: [{ type: "text", languages: ["en"] }]
  };
}

async function refreshAiAvailability() {
  if (!("LanguageModel" in globalThis)) {
    setAiUnsupported(diagnoseGemini({ api: false }), "Gemini Nano isn’t available in this browser. Click the button to see why.");
    return;
  }
  try {
    const availability = await LanguageModel.availability(aiOptions());
    state.ai.availability = availability;
    if (availability === "available") {
      setAiSupported("Analyze with Gemini Nano", "Gemini Nano is ready. Analysis runs on-device.");
    } else if (availability === "downloadable" || availability === "downloading") {
      setAiSupported("Download model & analyze", "Gemini Nano needs to be downloaded by Chrome before analysis. The log itself is analyzed on-device.");
    } else {
      setAiUnsupported(diagnoseGemini({ api: true, availability }), "This computer or Chrome profile can’t run Gemini Nano. Click the button to see why.");
    }
  } catch (error) {
    setAiUnsupported(diagnoseGemini({ api: true, error }), "Gemini Nano could not be checked. Click the button for details.");
  }
}

// ------------------------------------------------- Gemini "not supported"
// When Gemini Nano can't run, the button stays clickable and opens a notice
// that explains why and what to do, instead of being a dead, disabled button.

const GEMINI_MIN_CHROME = 138; // Prompt API for extensions: Chrome 138+

function setAiSupported(label, status) {
  state.ai.diagnosis = null;
  els.aiAnalyze.disabled = false;
  els.aiAnalyze.classList.remove("unavailable");
  els.aiAnalyze.textContent = label;
  els.aiStatus.textContent = status;
  hideAiNotice();
}

function setAiUnsupported(diagnosis, status) {
  state.ai.availability = "unavailable";
  state.ai.diagnosis = diagnosis;
  els.aiAnalyze.disabled = false;
  els.aiAnalyze.classList.add("unavailable");
  els.aiAnalyze.textContent = "Why is Gemini Nano unavailable?";
  els.aiStatus.textContent = status;
}

function browserInfo() {
  const data = navigator.userAgentData;
  const brands = Array.isArray(data?.brands) ? data.brands : [];
  const brand = name => brands.find(b => b.brand === name);
  const chrome = brand("Google Chrome");
  const other = ["Microsoft Edge", "Opera", "Brave", "Vivaldi", "Yandex", "Samsung Internet"].map(brand).find(Boolean);
  const uaMajor = Number((navigator.userAgent.match(/Chrome\/(\d+)/) || [])[1]);
  const major = Number(chrome?.version) || uaMajor || NaN;
  let name = "";
  if (other) name = other.brand;
  else if (!chrome && brands.length) name = "a Chromium-based browser that isn’t Google Chrome";
  return { isChrome: !!chrome || (!brands.length && /Chrome\//.test(navigator.userAgent) && !/Edg\//.test(navigator.userAgent)), name, major, mobile: !!data?.mobile };
}

// Returns { title, detail, steps[] }. Text in `backticks` is shown as code.
function diagnoseGemini({ api, availability = "", error = null }) {
  const offSteps = [
    "If you manage this computer yourself: open `chrome://settings`, search for “On-device AI” and make sure it is turned on.",
    "If your organisation manages Chrome: open `chrome://policy`. If `GenAILocalFoundationalModelSettings` is set to 1, built-in AI has been switched off by your IT department. Ask them.",
    "If you have changed experimental settings: open `chrome://flags`, set `optimization-guide-on-device-model` and `prompt-api-for-gemini-nano` back to Default, and relaunch Chrome."
  ];

  if (!api) {
    const b = browserInfo();
    if (b.mobile) {
      return {
        title: "Gemini Nano needs desktop Chrome",
        detail: "Chrome’s built-in AI for extensions is available in desktop Chrome on Windows, macOS, Linux and Chromebook Plus only.",
        steps: ["Open this log in Google Chrome on a desktop computer to use the AI report."]
      };
    }
    if (!b.isChrome) {
      return {
        title: "Gemini Nano needs Google Chrome",
        detail: `You are using ${b.name || "a browser other than Google Chrome"}. Gemini Nano is built into Google Chrome only, so the AI report can’t run here.`,
        steps: [`Open this log in desktop Google Chrome ${GEMINI_MIN_CHROME} or later to use the AI report.`]
      };
    }
    if (Number.isFinite(b.major) && b.major < GEMINI_MIN_CHROME) {
      return {
        title: "Chrome is too old for Gemini Nano",
        detail: `This is Chrome ${b.major}. Gemini Nano for extensions needs Chrome ${GEMINI_MIN_CHROME} or later.`,
        steps: ["Update Chrome: open `chrome://settings/help`, let Chrome update, and click Relaunch."]
      };
    }
    return {
      title: "Gemini Nano is switched off in this Chrome",
      detail: `This Chrome${Number.isFinite(b.major) ? ` (version ${b.major})` : ""} is new enough, but its built-in AI is not available to extensions. That usually means it has been turned off.`,
      steps: offSteps
    };
  }

  if (error) {
    return {
      title: "Gemini Nano could not be checked",
      detail: `Chrome reported an error while checking Gemini Nano: ${error?.message || error}`,
      steps: [
        "Reload this tab and try again.",
        "Open `chrome://on-device-internals` and look at the Model Status tab: it shows Chrome’s own reason."
      ]
    };
  }

  return {
    title: "This computer can’t run Gemini Nano",
    detail: "This Chrome supports Gemini Nano, but reports that it is not available on this computer or in this Chrome profile.",
    steps: [
      "Check the requirements: Windows 10/11, macOS 13 or later, Linux or a Chromebook Plus; at least 22 GB free disk space for the Chrome profile; a graphics card with more than 4 GB memory, or 16 GB RAM and 4 or more CPU cores.",
      "Open `chrome://on-device-internals` and look at the Model Status tab: it shows Chrome’s own reason.",
      ...offSteps.slice(0, 2)
    ]
  };
}

function appendWithCode(parent, text) {
  String(text).split("`").forEach((part, i) => {
    if (!part) return;
    if (i % 2) {
      const code = document.createElement("code");
      code.textContent = part;
      parent.appendChild(code);
    } else {
      parent.appendChild(document.createTextNode(part));
    }
  });
}

function showAiNotice(diagnosis = state.ai.diagnosis) {
  if (!diagnosis) return;
  els.aiNoticeTitle.textContent = diagnosis.title;
  els.aiNoticeDetail.replaceChildren();
  appendWithCode(els.aiNoticeDetail, diagnosis.detail);
  els.aiNoticeSteps.replaceChildren(...diagnosis.steps.map(step => {
    const li = document.createElement("li");
    appendWithCode(li, step);
    return li;
  }));
  els.aiNotice.hidden = false;
  els.aiNotice.scrollIntoView({ block: "nearest", behavior: "smooth" });
  els.aiNotice.focus({ preventScroll: true });
}

function hideAiNotice() {
  els.aiNotice.hidden = true;
}

function compactAnalysisForAi(d) {
  const cleanResource = r => ({
    url: r.url,
    domain: r.domain,
    type: r.type,
    mimeGroup: r.mimeGroup,
    sizeBytes: Number.isFinite(r.size) ? r.size : null
  });
  return {
    firstSeed: state.meta.firstSeed || null,
    seedCount: state.meta.seedCount,
    crawlerVersion: state.meta.crawlerVersion || null,
    scope: {
      type: state.meta.scopeType || null,
      maxDepth: state.meta.maxDepth,
      maxExtraHops: state.meta.maxExtraHops
    },
    crawl: d.crawl,
    uniquePages: d.pages,
    uniqueResources: d.resources,
    memory: {
      scope: "Browsertrix Crawler Node.js process only; browser (Chrome) memory is not logged",
      samples: d.memory.samples,
      firstRssBytes: Number.isFinite(d.memory.firstRss) ? d.memory.firstRss : null,
      endRssBytes: Number.isFinite(d.memory.endRss) ? d.memory.endRss : null,
      peakRssBytes: Number.isFinite(d.memory.peakRss) ? d.memory.peakRss : null,
      peakHeapUsedBytes: Number.isFinite(d.memory.peakHeap) ? d.memory.peakHeap : null,
      trendConcern: d.memory.trendConcern
    },
    cpu: d.cpu,
    storage: d.storage,
    limits: d.limits,
    blockingAndThrottling: { ...d.blocking, coverage: BLOCKING_COVERAGE_NOTE },
    timeoutLogEntries: d.timeouts,
    soft404: d.soft404,
    topResourceTypes: d.topTypes,
    topMimeGroups: d.topMimeGroups,
    topResourceDomains: d.topDomains,
    largestResources: d.largestResources.map(cleanResource),
    topWarnings: d.warningMessages.map(([message, count]) => ({ message, count })),
    topErrors: d.errorMessages.map(([message, count]) => ({ message, count }))
  };
}

const AI_REPORT_SCHEMA = {
  type: "object",
  properties: {
    health: { type: "string", enum: ["good", "attention", "problem", "unknown"] },
    summary: { type: "string" },
    findings: {
      type: "array",
      maxItems: 6,
      items: {
        type: "object",
        properties: {
          severity: { type: "string", enum: ["info", "attention", "problem"] },
          title: { type: "string" },
          detail: { type: "string" }
        },
        required: ["severity", "title", "detail"],
        additionalProperties: false
      }
    },
    recommendations: {
      type: "array",
      maxItems: 4,
      items: { type: "string" }
    }
  },
  required: ["health", "summary", "findings", "recommendations"],
  additionalProperties: false
};

function renderAiReport(report) {
  els.aiReport.replaceChildren();
  const head = document.createElement("div");
  head.className = "ai-report-head";
  const badge = document.createElement("span");
  badge.className = `ai-health ${report.health || "unknown"}`;
  badge.textContent = report.health || "unknown";
  const title = document.createElement("strong");
  title.textContent = "Gemini Nano crawl assessment";
  head.append(badge, title);
  els.aiReport.appendChild(head);

  const p = document.createElement("p");
  p.textContent = report.summary || "";
  els.aiReport.appendChild(p);

  if (Array.isArray(report.findings) && report.findings.length) {
    const ul = document.createElement("ul");
    for (const finding of report.findings) {
      const li = document.createElement("li");
      const strong = document.createElement("strong");
      strong.textContent = finding.title ? `${finding.title}: ` : "";
      const severity = ["info", "attention", "problem"].includes(finding.severity) ? finding.severity : "";
      if (severity) {
        const sev = document.createElement("span");
        sev.className = `ai-health ${severity === "info" ? "unknown" : severity}`;
        sev.textContent = severity;
        sev.style.marginRight = "6px";
        li.append(sev);
      }
      li.append(strong, document.createTextNode(finding.detail || ""));
      ul.appendChild(li);
    }
    els.aiReport.appendChild(ul);
  }

  if (Array.isArray(report.recommendations) && report.recommendations.length) {
    const h = document.createElement("strong");
    h.textContent = "Recommendations";
    h.style.display = "block";
    h.style.marginTop = "9px";
    els.aiReport.appendChild(h);
    const ul = document.createElement("ul");
    for (const rec of report.recommendations) {
      const li = document.createElement("li");
      li.textContent = rec;
      ul.appendChild(li);
    }
    els.aiReport.appendChild(ul);
  }

  els.aiReport.hidden = false;
}

async function analyzeWithGeminiNano() {
  if (!("LanguageModel" in globalThis) || state.ai.availability === "unavailable") {
    await refreshAiAvailability();
    if (state.ai.diagnosis) {
      showAiNotice();
      return;
    }
  }
  hideAiNotice();

  els.aiAnalyze.disabled = true;
  els.aiReport.hidden = true;
  els.aiProgress.hidden = false;
  els.aiProgressBar.classList.add("indeterminate");
  els.aiProgressBar.style.width = "35%";
  els.aiStatus.textContent = "Preparing Gemini Nano…";

  let session = null;
  try {
    const options = aiOptions();
    session = await LanguageModel.create({
      ...options,
      monitor(monitor) {
        monitor.addEventListener("downloadprogress", event => {
          const loaded = Number(event.loaded);
          if (Number.isFinite(loaded)) {
            const pct = Math.max(0, Math.min(100, loaded * 100));
            els.aiProgressBar.classList.remove("indeterminate");
            els.aiProgressBar.style.width = `${pct}%`;
            els.aiStatus.textContent = `Downloading Gemini Nano… ${pct.toFixed(0)}%`;
          }
        });
      }
    });

    els.aiProgressBar.classList.add("indeterminate");
    els.aiProgressBar.style.width = "35%";
    els.aiStatus.textContent = "Gemini Nano is analyzing the crawl diagnostics on-device…";

    const facts = compactAnalysisForAi(buildDeterministicAnalysis());
    const prompt = [
      "You are reviewing a Browsertrix web-archive crawl. Use ONLY the deterministic facts below. Do not invent missing telemetry or claim a cause that the facts do not support. Distinguish normal debug noise from genuine problems.",
      "Always consider: crawl completion/failures; blocking or throttling (respect the coverage note: absence of signals is not proof); crawler-process RAM trend/peak; CPU telemetry if present; storage/write failures; configured limits and whether any were hit; timeouts; soft-404 findings; unusually large resource groups/domains. If CPU or storage capacity is not logged, say so only if it matters.",
      "Respond with JSON only, in this shape:",
      '{"health": "good" | "attention" | "problem" | "unknown", "summary": "<2-3 sentences>", "findings": [{"severity": "info" | "attention" | "problem", "title": "<short>", "detail": "<one or two sentences>"}] (at most 6, most important first), "recommendations": ["<short action>"] (at most 4)}',
      "",
      "FACTS:",
      JSON.stringify(facts)
    ].join("\n");

    const result = await session.prompt(prompt, {
      responseConstraint: AI_REPORT_SCHEMA,
      omitResponseConstraintInput: true
    });
    const report = JSON.parse(result);
    state.ai.report = report;
    renderAiReport(report);
    els.aiStatus.textContent = "Analysis completed locally with Gemini Nano.";
  } catch (error) {
    els.aiStatus.textContent = `Gemini Nano analysis failed: ${error?.message || error}`;
    // Chrome can refuse at create()/prompt() time even after a positive check.
    if (error?.name === "NotSupportedError" || error?.name === "NotAllowedError") {
      await refreshAiAvailability().catch(() => {});
      if (!state.ai.diagnosis) {
        state.ai.diagnosis = diagnoseGemini({ api: true, error });
      }
      showAiNotice();
    }
  } finally {
    els.aiProgress.hidden = true;
    els.aiAnalyze.disabled = false;
    try { session?.destroy?.(); } catch (_) {}
    refreshAiAvailability().catch(() => {});
  }
}

function rawLineMarkers(rows, invalid) {
  const warn = [];
  const error = [];
  for (const row of rows) {
    const level = row.logLevel.toLowerCase();
    if (level === "warn") warn.push(row.lineNumber);
    else if (level === "error" || level === "fatal" || level === "interrupt") error.push(row.lineNumber);
  }
  return { warn, error, malformed: invalid.map(item => item.lineNumber) };
}

function setView(view) {
  const raw = view === "raw" && globalThis.BTLV_RAW;
  els.tabTable.setAttribute("aria-selected", String(!raw));
  els.tabRaw.setAttribute("aria-selected", String(!!raw));
  els.tabTable.tabIndex = raw ? -1 : 0;
  els.tabRaw.tabIndex = raw ? 0 : -1;
  els.tableView.hidden = !!raw;
  if (raw) {
    globalThis.BTLV_RAW.show();
    alignViewTabs();
  } else {
    globalThis.BTLV_RAW?.hide();
  }
}

// Align the view tabs just below the sticky top bar so the whole raw panel
// (toolbar, code area and footer) fits in the window.
function alignViewTabs() {
  const topbar = document.querySelector(".topbar");
  const offset = (topbar?.offsetHeight || 0) + 8;
  const top = els.viewTabs.getBoundingClientRect().top + window.scrollY - offset;
  if (Math.abs(window.scrollY - top) > 2) window.scrollTo({ top, behavior: "instant" });
}

function showRawLine(lineNumber) {
  setView("raw");
  globalThis.BTLV_RAW?.showLine(lineNumber);
}

// ---------------------------------------------------------- loading (v1.12)
// A log is never held as one big string. Decoded pieces go straight into a
// LineStore and are parsed line by line while they arrive; all heavy work
// runs in time slices with visible progress, so large logs never freeze the
// page and logs larger than JavaScript's ~536 million character string limit
// still load.

let loadGeneration = 0;

// Turns a byte stream into decoded text pieces, counting raw bytes.
// hooks.onBytes(u8): also receives every raw chunk (the disk copy).
// hooks.shouldSwitch(): when true, the rest is only copied to disk and a final
// { switched: true } piece is yielded (large-log mode takes over).
async function* decodeStream(readable, hooks = {}) {
  const reader = readable.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: false });
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      if (hooks.onBytes) await hooks.onBytes(value);
      if (hooks.shouldSwitch?.()) {
        while (true) {
          const next = await reader.read();
          if (next.done) break;
          await hooks.onBytes(next.value);
          hooks.onDrain?.();
        }
        yield { text: "", bytes: value.byteLength, switched: true };
        return;
      }
      yield { text: decoder.decode(value, { stream: true }), bytes: value.byteLength };
    }
    yield { text: decoder.decode(), bytes: 0 };
  } finally {
    reader.releaseLock?.();
  }
}

function setPhaseStatus(phase, done, total) {
  const pct = total > 0 ? Math.min(100, (done / total) * 100) : 0;
  setLoadingStatus(`${phase}…`, 0, NaN);
  els.statusDetail.textContent = total > 1 ? `${pct.toFixed(0)}% · ${done.toLocaleString()} / ${total.toLocaleString()} rows` : "";
  if (total > 1) {
    els.loadProgressBar.classList.remove("indeterminate");
    els.loadProgressBar.style.width = `${pct}%`;
    els.loadProgress.setAttribute("aria-valuenow", pct.toFixed(0));
  }
}

// pieces: async iterable of { text, bytes }. Returns false if superseded by a
// newer load, throws on real errors.
async function ingestLog({ pieces, totalBytes, label, filename, sourceDescription, rawBlob }) {
  const generation = ++loadGeneration;
  resetUrlCaches();
  const { LineStore, LineSplitter } = globalThis.BTLV_LINES;
  const store = new LineStore();
  const splitter = new LineSplitter(store);
  const rows = [];
  const invalid = [];
  const slicer = new Slicer(generation);
  let bytes = 0;

  const showReadProgress = () => {
    setLoadingStatus(label, bytes, totalBytes);
    els.statusDetail.textContent += ` · ${store.length.toLocaleString()} lines`;
  };
  const parseRange = async ([from, to]) => {
    for (let i = from; i < to; i++) {
      parseLineInto(rows, invalid, store.getLine(i), i + 1);
      if ((i & 255) === 0) await slicer.tick(showReadProgress);
    }
  };

  try {
    for await (const piece of pieces) {
      if (piece.switched) return "large"; // the in-memory work is discarded
      bytes += piece.bytes;
      await parseRange(splitter.push(piece.text));
      await slicer.tick(showReadProgress);
    }
    await parseRange(splitter.finish());
    if (!rows.length) throw new Error("No valid Browsertrix NDJSON log lines were found.");

    const derived = await finalizeRows(rows, slicer, setPhaseStatus);
    await finishLoad({ store, rows, invalid, ...derived, filename, sourceDescription, byteSize: bytes, rawBlob, slicer });
    return true;
  } catch (error) {
    if (error instanceof LoadSuperseded) return false;
    throw error;
  }
}

// Large-log mode: reads the log from disk, keeps only line offsets and
// compact rows in memory, then runs the same analyses as normal mode.
async function ingestLargeLog({ blob, filename, sourceDescription, disk = null }) {
  const generation = ++loadGeneration;
  resetUrlCaches();
  internPool.clear();
  provenanceShare = new Map();
  const lines = new BTLV_DISK.DiskLines(blob);
  const rows = [];
  const invalid = [];
  const slicer = new Slicer(generation);
  const reader = blob.stream().getReader();
  const decoder = new TextDecoder("utf-8", { fatal: false });
  let carry = "";
  let lineNumber = 0;
  let bytes = 0;
  const label = `Large log: reading ${filename} from disk (large-log mode)…`;
  const show = () => {
    setLoadingStatus(label, bytes, blob.size);
    els.statusDetail.textContent += ` · ${lineNumber.toLocaleString()} lines`;
  };
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      lines.indexBytes(value, bytes);
      bytes += value.byteLength;
      const text = carry + decoder.decode(value, { stream: true });
      let pos = 0;
      let nl;
      while ((nl = text.indexOf("\n", pos)) !== -1) {
        let line = text.slice(pos, nl);
        if (line.endsWith("\r")) line = line.slice(0, -1);
        parseLineInto(rows, invalid, line, ++lineNumber, true);
        pos = nl + 1;
        if ((lineNumber & 255) === 0) await slicer.tick(show);
      }
      carry = text.slice(pos);
      await slicer.tick(show);
    }
    const rest = carry + decoder.decode();
    if (rest) parseLineInto(rows, invalid, rest, ++lineNumber, true);
    lines.finish(bytes);
    if (lines.length !== lineNumber) throw new Error(`line index mismatch (${lines.length} vs ${lineNumber})`);
    if (!rows.length) throw new Error("No valid Browsertrix NDJSON log lines were found.");
    const derived = await finalizeRows(rows, slicer, setPhaseStatus);
    await finishLoad({ store: lines, rows, invalid, ...derived, filename, sourceDescription, byteSize: bytes, rawBlob: blob, slicer, large: true, disk });
    return true;
  } catch (error) {
    reader.cancel().catch(() => {});
    if (error instanceof LoadSuperseded) return false;
    throw error;
  }
}

async function finishLoad({ store, rows, invalid, provenanceByUrl, pageUrls, pageStatusByUrl, nonHtmlUrls, filename, sourceDescription, byteSize, rawBlob, slicer, large = false, disk = null }) {
  const step = async phase => {
    setPhaseStatus(phase, 0, 1);
    await yieldToBrowser();
    if (slicer.generation !== loadGeneration) throw new LoadSuperseded();
  };

  await step("Reading crawl metadata");
  state.lines = store;
  state.large = !!large;
  if (state.diskBuffer && state.diskBuffer !== disk) state.diskBuffer.remove();
  state.diskBuffer = disk;
  resetLargeSearch();
  state.rawBlob = rawBlob || null;
  state.filename = filename || "browsertrix-logs.log";
  state.rows = rows;
  state.provenanceByUrl = provenanceByUrl;
  state.pageUrls = pageUrls;
  state.pageStatusByUrl = pageStatusByUrl;
  state.nonHtmlUrls = nonHtmlUrls || new Set();
  state.filtered = rows.slice();
  state.page = 1;
  state.search = "";
  state.level = "";
  state.context = "";
  state.fileType = "";
  state.mimeGroup = "";
  state.status = "";
  state.sortKey = "timestamp";
  state.sortDir = 1;
  state.meta = extractCrawlMetadata(rows);
  state.ai.report = null;

  // Byte size comes from the caller (download counter / File.size).
  const sizeText = Number.isFinite(byteSize) ? ` · ${formatBytes(byteSize)}` : "";
  els.filename.textContent = `${state.filename}${sizeText}${sourceDescription ? ` · ${sourceDescription}` : ""}`;
  if (state.large) {
    const badge = document.createElement("span");
    badge.className = "mode-badge";
    badge.textContent = "Large-log mode";
    badge.title = `This log is larger than ${formatBytes(largeLogBytes())}, so it is shown in large-log mode: the raw text stays on disk and rows are stored compactly. Everything works; searching and opening details read from disk and take a moment longer.`;
    els.filename.append(" · ", badge);
  }
  els.search.value = "";
  els.levelFilter.value = "";
  els.contextFilter.value = "";
  els.typeFilter.value = "";
  els.mimeGroupFilter.value = "";
  els.statusFilter.value = "";
  els.downloadRaw.disabled = false;
  els.aiReport.hidden = true;

  renderCrawlMeta();
  await step("Building filters");
  fillFilters();
  await step("Calculating totals");
  updateSummary();
  await step("Sorting table");
  applyFiltersAndSort();
  await step("Running diagnostics");
  renderDiagnostics();
  renderStatusOverview();

  await step("Preparing raw log");
  globalThis.BTLV_RAW?.load(store.isDisk ? {
    lineCount: store.length,
    getLine: i => store.cached(i),
    has: i => store.has(i),
    ensure: indices => store.ensure(indices),
    maxLen: store.maxLen,
    getBlob: getRawBlob,
    stream: true
  } : {
    lineCount: store.length,
    getLine: i => store.getLine(i),
    maxLen: store.maxLen,
    getBlob: getRawBlob
  }, rawLineMarkers(rows, invalid));
  els.viewTabs.hidden = false;

  els.summary.hidden = false;
  els.controls.hidden = false;
  els.tableWrap.hidden = false;
  els.pager.hidden = false;
  els.analysisPanel.hidden = false;

  if (invalid.length) {
    setStatus(`Loaded ${rows.length.toLocaleString()} valid rows; ${invalid.length.toLocaleString()} malformed lines were skipped.`, true);
  } else {
    hideStatus();
  }

  refreshAiAvailability().catch(() => {});
  initializeSoft404Probe().catch(error => {
    state.soft404.state = "error";
    state.soft404.error = String(error?.message || error);
    renderSoft404Panel();
    renderDiagnostics();
  });
}

// The original file for local logs (exact bytes, no copy); for downloaded logs
// a Blob made from the line store's chunks, created only when needed.
function getRawBlob() {
  if (!state.rawBlob && state.lines) {
    state.rawBlob = new Blob(state.lines.chunks, { type: "text/plain;charset=utf-8" });
  }
  return state.rawBlob || new Blob([]);
}

async function loadRemote() {
  const id = decodeURIComponent(location.hash.slice(1));
  if (!id) {
    const hosts = await globalThis.BTLV_HOSTS?.getHosts().catch(() => []) || [];
    setStatus(hosts.length
      ? "Click Download Logs on a crawl in Browsertrix, or use “Open local log” to open a log file."
      : "No Browsertrix is connected yet. Click Settings (top right) to add the address of your Browsertrix, or use “Open local log” to open a log file.", !hosts.length);
    return;
  }

  const key = KEY_PREFIX + id;
  let result = await chrome.storage.session.get(key);
  let item = result[key];
  result = null;
  // Read once: the handoff entry is deleted the moment it is read, whether or
  // not the download then succeeds. From here on the signed link exists only
  // in the local variable `signedUrl` below, inside this tab's memory. It is
  // never put in `state`, the page, storage, the console or the address bar.
  await chrome.storage.session.remove(key);
  if (!item?.url) {
    setStatus("The temporary log reference is missing or expired. Click Download Logs in Browsertrix again.", true);
    return;
  }

  let signedUrl = item.url;
  const filename = item.filename || "browsertrix-logs.log";
  item = null;
  els.filename.textContent = filename;

  async function attempt() {
    setLoadingStatus("Fetching Browsertrix crawl log…", 0, NaN);
    logLoadStarted();
    let ok = false;
    try {
      const { response, totalBytes } = await fetchSignedLog(signedUrl);
      // Every download is also copied to the extension's private disk storage
      // (log content only, never the link or its token). If it grows past
      // the large-log limit, large-log mode continues from that disk copy.
      let disk = null;
      try {
        if (BTLV_DISK.DiskBuffer.available()) disk = await BTLV_DISK.DiskBuffer.create();
      } catch (_) {
        disk = null;
      }
      let received = 0;
      const limit = largeLogBytes();
      const hooks = disk ? {
        onBytes: async u8 => { received += u8.byteLength; await disk.write(u8); },
        shouldSwitch: () => received > limit,
        onDrain: () => setLoadingStatus(`Large log (over ${formatBytes(limit)}): downloading to disk for large-log mode…`, received, totalBytes)
      } : {};
      let loaded;
      try {
        loaded = await ingestLog({
          pieces: decodeStream(response.body, hooks),
          totalBytes,
          label: "Fetching and parsing Browsertrix crawl log…",
          filename,
          sourceDescription: "Browsertrix",
          rawBlob: null
        });
        if (loaded === "large") {
          const file = await disk.finish();
          loaded = await ingestLargeLog({ blob: file, filename, sourceDescription: "Browsertrix", disk });
        } else {
          await disk?.remove(); // normal mode keeps the log in memory
        }
      } catch (error) {
        await disk?.remove();
        throw error;
      }
      if (!loaded) return; // a newer load took over
      ok = true;
      signedUrl = null; // the link is no longer needed: drop it
      els.retryRemote.onclick = null;
    } catch (error) {
      setStatus(`Could not fetch the crawl log: ${error?.message || error}. Click Retry, or click Download Logs in Browsertrix again.`, true);
      // Retry uses the link held in memory. Reloading the tab cannot retry,
      // because the link is no longer stored anywhere.
      els.retryRemote.hidden = false;
      els.retryRemote.onclick = () => { if (signedUrl) attempt(); };
    } finally {
      logLoadFinished(ok);
    }
  }
  await attempt();
}

// Fetches the signed log link. No cookies (Browsertrix authenticates with the
// token in the link), no Referer, no HTTP cache (the cache index is keyed by
// the full URL, token included) and no redirects (Browsertrix streams logs
// directly; a redirect would mean something in between is misbehaving).
async function fetchSignedLog(signedUrl) {
  const response = await fetch(signedUrl, {
    method: "GET",
    credentials: "omit",
    cache: "no-store",
    redirect: "error",
    referrerPolicy: "no-referrer"
  });
  if (!response.ok) throw new Error(`Browsertrix returned HTTP ${response.status} ${response.statusText}`.trim());
  if (!response.body?.getReader) throw new Error("This browser cannot stream the download.");

  const declaredLength = Number(response.headers.get("content-length"));
  const contentEncoding = (response.headers.get("content-encoding") || "").toLowerCase();
  // Fetch exposes decoded body bytes. A compressed Content-Length describes the
  // encoded transfer and therefore is not a reliable denominator.
  const totalBytes = Number.isFinite(declaredLength) && declaredLength > 0 && (!contentEncoding || contentEncoding === "identity")
    ? declaredLength
    : NaN;
  return { response, totalBytes };
}

let searchTimer;
els.search.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    state.search = els.search.value;
    state.page = 1;
    applyFiltersAndSort();
  }, 120);
});

els.levelFilter.addEventListener("change", () => {
  state.level = els.levelFilter.value;
  state.page = 1;
  applyFiltersAndSort();
});

els.contextFilter.addEventListener("change", () => {
  state.context = els.contextFilter.value;
  state.page = 1;
  applyFiltersAndSort();
});

els.typeFilter.addEventListener("change", () => {
  state.fileType = els.typeFilter.value;
  state.page = 1;
  applyFiltersAndSort();
});

els.mimeGroupFilter.addEventListener("change", () => {
  state.mimeGroup = els.mimeGroupFilter.value;
  state.page = 1;
  applyFiltersAndSort();
});

els.statusFilter.addEventListener("change", () => {
  state.status = els.statusFilter.value;
  state.page = 1;
  applyFiltersAndSort();
  renderStatusOverview();
});

els.pageSize.addEventListener("change", () => {
  state.pageSize = Number(els.pageSize.value) || 250;
  state.page = 1;
  applyFiltersAndSort();
});

els.clearFilters.addEventListener("click", () => {
  els.search.value = "";
  els.levelFilter.value = "";
  els.contextFilter.value = "";
  els.typeFilter.value = "";
  els.mimeGroupFilter.value = "";
  els.statusFilter.value = "";
  state.status = "";
  state.search = "";
  state.level = "";
  state.context = "";
  state.fileType = "";
  state.mimeGroup = "";
  state.page = 1;
  applyFiltersAndSort();
});

els.soft404Test.addEventListener("click", () => {
  runSoft404Probe(true).catch(error => {
    state.soft404.state = "error";
    state.soft404.error = String(error?.message || error);
    renderSoft404Panel();
    renderDiagnostics();
  });
});

els.aiNoticeClose.addEventListener("click", () => {
  hideAiNotice();
  els.aiAnalyze.focus();
});
els.aiNotice.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    event.stopPropagation();
    hideAiNotice();
    els.aiAnalyze.focus();
  }
});

els.aiAnalyze.addEventListener("click", () => {
  analyzeWithGeminiNano().catch(error => {
    els.aiStatus.textContent = `Gemini Nano analysis failed: ${error?.message || error}`;
    els.aiAnalyze.disabled = false;
    els.aiProgress.hidden = true;
  });
});

function saveColumnOrder() {
  try {
    localStorage.setItem(COLUMN_ORDER_KEY, JSON.stringify(state.columnOrder));
  } catch (_) { /* storage unavailable: order lasts for this tab only */ }
}

function isDefaultColumnOrder() {
  return state.columnOrder.every((key, i) => key === DEFAULT_COLUMN_ORDER[i]);
}

function headerFor(key) {
  return headerRow.querySelector(`th[data-key="${key}"]`);
}

// Moves existing header and body cells into the new order. Cells are moved,
// not rebuilt, so expanded details rows and focus targets survive.
function applyColumnOrder(previousOrder = null) {
  const focused = document.activeElement;
  for (const key of state.columnOrder) headerRow.appendChild(headerFor(key));
  if (previousOrder) {
    const indexOf = new Map(previousOrder.map((key, i) => [key, i]));
    for (const tr of els.tbody.children) {
      if (tr.classList.contains("details-row")) continue;
      const cells = [...tr.children];
      if (cells.length !== previousOrder.length) continue;
      for (const key of state.columnOrder) tr.appendChild(cells[indexOf.get(key)]);
    }
  }
  if (focused && focused !== document.activeElement && document.contains(focused)) focused.focus({ preventScroll: true });
  els.resetColumns.disabled = isDefaultColumnOrder();
}

function setColumnOrder(order, announce = "") {
  const next = sanitizeColumnOrder(order);
  const previous = state.columnOrder;
  if (next.every((key, i) => key === previous[i])) return false;
  state.columnOrder = next;
  saveColumnOrder();
  applyColumnOrder(previous);
  if (announce) els.columnAnnounce.textContent = announce;
  return true;
}

function columnLabel(key) {
  return headerFor(key)?.firstChild?.textContent.trim() || key;
}

// ---- Pointer drag. The dragged header only moves horizontally and is clamped
// to the visible header area of the table; it cannot leave the table.
const columnDrag = {
  th: null,
  key: "",
  pointerId: null,
  startX: 0,
  grabOffset: 0,
  naturalLeftInRow: 0,
  width: 0,
  lastX: 0,
  active: false,
  insertIndex: -1,
  autoScroll: 0,
  suppressClick: false
};

const columnDropMarker = document.createElement("div");
columnDropMarker.className = "column-drop-marker";
columnDropMarker.hidden = true;
els.tableWrap.appendChild(columnDropMarker);

const DRAG_THRESHOLD_PX = 6;
const AUTO_SCROLL_EDGE_PX = 48;

function visibleHeaderBounds() {
  const wrap = els.tableWrap.getBoundingClientRect();
  const row = headerRow.getBoundingClientRect();
  const left = Math.max(wrap.left + els.tableWrap.clientLeft, row.left);
  const right = Math.min(wrap.left + els.tableWrap.clientLeft + els.tableWrap.clientWidth, row.right);
  return { left, right, wrap, row };
}

function updateColumnDrag(clientX) {
  const d = columnDrag;
  const { left, right, wrap, row } = visibleHeaderBounds();
  const naturalLeft = row.left + d.naturalLeftInRow;
  let draggedLeft = clientX - d.grabOffset;
  draggedLeft = Math.min(draggedLeft, right - d.width);
  draggedLeft = Math.max(draggedLeft, left);
  d.th.style.transform = `translateX(${Math.round(draggedLeft - naturalLeft)}px)`;

  // Insertion point: how many other columns have their midpoint left of the
  // dragged header's centre.
  const centre = draggedLeft + d.width / 2;
  const others = state.columnOrder.filter(key => key !== d.key).map(headerFor);
  let index = 0;
  for (const th of others) {
    const r = th.getBoundingClientRect();
    if (r.left + r.width / 2 < centre) index++;
  }
  d.insertIndex = index;

  const original = state.columnOrder.indexOf(d.key);
  if (index === original) {
    columnDropMarker.hidden = true;
  } else {
    const edge = index === 0
      ? others[0].getBoundingClientRect().left
      : others[index - 1].getBoundingClientRect().right;
    columnDropMarker.hidden = false;
    columnDropMarker.style.left = `${Math.round(edge - wrap.left - els.tableWrap.clientLeft + els.tableWrap.scrollLeft - 1)}px`;
    columnDropMarker.style.top = `${els.tableWrap.scrollTop}px`;
    columnDropMarker.style.height = `${els.tableWrap.clientHeight}px`;
  }

  // Auto-scroll when the pointer is held near the left/right edge of the table.
  const wrapLeft = wrap.left + els.tableWrap.clientLeft;
  const wrapRight = wrapLeft + els.tableWrap.clientWidth;
  let speed = 0;
  if (clientX < wrapLeft + AUTO_SCROLL_EDGE_PX) speed = -Math.ceil((wrapLeft + AUTO_SCROLL_EDGE_PX - clientX) / 4);
  else if (clientX > wrapRight - AUTO_SCROLL_EDGE_PX) speed = Math.ceil((clientX - (wrapRight - AUTO_SCROLL_EDGE_PX)) / 4);
  speed = Math.max(-24, Math.min(24, speed));
  if (speed && !d.autoScroll) {
    const tick = () => {
      if (!d.active) {
        d.autoScroll = 0;
        return;
      }
      const before = els.tableWrap.scrollLeft;
      els.tableWrap.scrollLeft += d.scrollSpeed;
      if (els.tableWrap.scrollLeft !== before) updateColumnDrag(d.lastX);
      d.autoScroll = d.scrollSpeed ? requestAnimationFrame(tick) : 0;
    };
    d.autoScroll = requestAnimationFrame(tick);
  }
  d.scrollSpeed = speed;
}

function endColumnDrag(commit) {
  const d = columnDrag;
  if (!d.th) return;
  // Detach first: releasing pointer capture can synchronously fire
  // lostpointercapture, which calls this function again.
  const th = d.th;
  const pointerId = d.pointerId;
  const wasActive = d.active;
  d.th = null;
  d.active = false;
  d.pointerId = null;
  if (d.autoScroll) cancelAnimationFrame(d.autoScroll);
  d.autoScroll = 0;
  d.scrollSpeed = 0;
  th.style.transform = "";
  th.classList.remove("dragging");
  headerRow.classList.remove("reordering");
  document.body.classList.remove("column-dragging");
  columnDropMarker.hidden = true;
  if (pointerId != null && th.hasPointerCapture?.(pointerId)) th.releasePointerCapture(pointerId);

  if (wasActive) {
    // A drag must never also count as a click (which would sort the column).
    d.suppressClick = true;
    setTimeout(() => { d.suppressClick = false; }, 0);
    if (commit) {
      const order = state.columnOrder.filter(key => key !== d.key);
      order.splice(d.insertIndex, 0, d.key);
      setColumnOrder(order, `${columnLabel(d.key)} column moved to position ${d.insertIndex + 1} of ${order.length}.`);
    }
  }
}

headerRow.addEventListener("pointerdown", event => {
  const th = event.target.closest("th[data-key]");
  if (!th || event.button !== 0 || columnDrag.th) return;
  const thRect = th.getBoundingClientRect();
  Object.assign(columnDrag, {
    th,
    key: th.dataset.key,
    pointerId: event.pointerId,
    startX: event.clientX,
    lastX: event.clientX,
    grabOffset: event.clientX - thRect.left,
    naturalLeftInRow: thRect.left - headerRow.getBoundingClientRect().left,
    width: thRect.width,
    active: false,
    insertIndex: state.columnOrder.indexOf(th.dataset.key)
  });
  th.setPointerCapture(event.pointerId);
});

headerRow.addEventListener("pointermove", event => {
  const d = columnDrag;
  if (!d.th || event.pointerId !== d.pointerId) return;
  d.lastX = event.clientX;
  if (!d.active) {
    if (Math.abs(event.clientX - d.startX) < DRAG_THRESHOLD_PX) return;
    d.active = true;
    d.th.classList.add("dragging");
    headerRow.classList.add("reordering");
    document.body.classList.add("column-dragging");
  }
  event.preventDefault();
  updateColumnDrag(event.clientX);
});

headerRow.addEventListener("pointerup", event => {
  if (event.pointerId === columnDrag.pointerId) endColumnDrag(true);
});
headerRow.addEventListener("pointercancel", event => {
  if (event.pointerId === columnDrag.pointerId) endColumnDrag(false);
});
headerRow.addEventListener("lostpointercapture", event => {
  if (event.pointerId === columnDrag.pointerId && columnDrag.th) endColumnDrag(false);
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && columnDrag.active) {
    event.preventDefault();
    event.stopPropagation();
    endColumnDrag(false);
  }
}, true);

// ---- Keyboard: headers are focusable; Enter/Space sorts, Alt+Left/Right moves.
headerRow.querySelectorAll("th[data-key]").forEach(th => {
  th.tabIndex = 0;
  th.title = "Click to sort · drag to move · Alt+\u2190/\u2192 moves the focused column";
  th.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      th.click();
      return;
    }
    if (!event.altKey || (event.key !== "ArrowLeft" && event.key !== "ArrowRight")) return;
    event.preventDefault();
    const key = th.dataset.key;
    const from = state.columnOrder.indexOf(key);
    const to = event.key === "ArrowLeft" ? from - 1 : from + 1;
    if (to < 0 || to >= state.columnOrder.length) return;
    const order = [...state.columnOrder];
    order.splice(from, 1);
    order.splice(to, 0, key);
    setColumnOrder(order, `${columnLabel(key)} column moved to position ${to + 1} of ${order.length}.`);
    th.focus({ preventScroll: true });
    th.scrollIntoView({ block: "nearest", inline: "nearest" });
  });
});

els.resetColumns.addEventListener("click", () => {
  setColumnOrder([...DEFAULT_COLUMN_ORDER], "Column order reset to default.");
});

applyColumnOrder();

document.querySelectorAll("th[data-key]").forEach(th => {
  th.addEventListener("click", () => {
    if (columnDrag.suppressClick) return;
    const key = th.dataset.key;
    if (state.sortKey === key) {
      state.sortDir *= -1;
    } else {
      state.sortKey = key;
      state.sortDir = key === "sizeBytes" ? -1 : 1;
    }
    state.page = 1;
    applyFiltersAndSort();
  });
});

els.firstPage.addEventListener("click", () => { state.page = 1; render(); });
els.prevPage.addEventListener("click", () => { state.page = Math.max(1, state.page - 1); render(); });
els.nextPage.addEventListener("click", () => {
  const max = Math.max(1, Math.ceil(state.filtered.length / state.pageSize));
  state.page = Math.min(max, state.page + 1);
  render();
});
els.lastPage.addEventListener("click", () => {
  state.page = Math.max(1, Math.ceil(state.filtered.length / state.pageSize));
  render();
});

els.downloadRaw.addEventListener("click", () => {
  if (!state.lines) return;
  const url = URL.createObjectURL(getRawBlob());
  const a = document.createElement("a");
  a.href = url;
  a.download = state.filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
});

els.tabTable.addEventListener("click", () => setView("table"));
els.tabRaw.addEventListener("click", () => setView("raw"));
els.viewTabs.addEventListener("keydown", event => {
  if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
  event.preventDefault();
  const toRaw = event.key === "ArrowRight";
  setView(toRaw ? "raw" : "table");
  (toRaw ? els.tabRaw : els.tabTable).focus();
});

els.provenanceClose.addEventListener("click", closeProvenancePanel);
els.provenanceBackdrop.addEventListener("click", closeProvenancePanel);
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && !els.provenancePanel.hidden) closeProvenancePanel();
});

els.fileInput.addEventListener("change", async () => {
  const file = els.fileInput.files?.[0];
  if (!file) return;
  logLoadStarted();
  let ok = false;
  try {
    setLoadingStatus(`Reading ${file.name}…`, 0, file.size);
    if (file.size > largeLogBytes()) {
      // Large-log mode: the file is read from disk when needed.
      await ingestLargeLog({ blob: file, filename: file.name, sourceDescription: "local file" });
    } else {
      await ingestLog({
        pieces: decodeStream(file.stream()),
        totalBytes: file.size,
        label: `Reading and parsing ${file.name}…`,
        filename: file.name,
        sourceDescription: "local file",
        rawBlob: file
      });
    }
    ok = true;
  } catch (error) {
    setStatus(`Could not read local log: ${error?.message || error}`, true);
  } finally {
    els.fileInput.value = "";
    logLoadFinished(ok);
  }
});

// ------------------------------------------------ cards while a log loads
// Tip/news cards are shown while a crawl log loads (loading-cards.js). News
// feeds are refreshed only while NO log is loading, so they never compete with
// a log download (news.js; off unless turned on in Settings).
let logLoadsRunning = 0;

function logLoadStarted() {
  logLoadsRunning++;
  globalThis.BTLV_LOADING_CARDS?.loadStarted();
}

function logLoadFinished(ok) {
  logLoadsRunning = Math.max(0, logLoadsRunning - 1);
  if (logLoadsRunning) return;
  globalThis.BTLV_LOADING_CARDS?.loadFinished({ ok });
  scheduleNewsRefresh(3000);
}

function scheduleNewsRefresh(delayMs) {
  setTimeout(() => {
    if (logLoadsRunning) return;
    globalThis.BTLV_NEWS?.refresh().catch(() => {});
  }, delayMs);
}

scheduleNewsRefresh(5000);

// Large-log disk copies: delete this tab's copy when it closes (best effort)
// and any left-over copy from earlier tabs at startup.
globalThis.BTLV_DISK?.DiskBuffer.cleanupStale();
window.addEventListener("pagehide", () => { state.diskBuffer?.remove(); });

loadRemote().catch(error => setStatus(String(error?.message || error), true));
