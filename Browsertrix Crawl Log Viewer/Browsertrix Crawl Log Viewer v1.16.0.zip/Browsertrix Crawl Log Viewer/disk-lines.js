/*
 * Browsertrix Crawl Log Viewer - large-log mode: raw text on disk
 *
 * DiskLines gives line access to a log that stays on disk (a local File, or
 * a file in the extension's private disk storage). Only the byte offset where
 * each line starts is kept in memory (8 bytes per line). Lines are read
 * asynchronously, a block at a time, and a bounded cache keeps recently read
 * lines for the raw view.
 *
 * Line numbering matches line-store.js and text.split(/\r?\n/): every "\n"
 * ends a line, a "\r" right before it is not part of the line, a final
 * newline does not start an extra line. ("\n" never occurs inside a UTF-8
 * multi-byte sequence, so byte and text line boundaries agree.)
 *
 * DiskBuffer writes a downloaded log to the Origin Private File System, which
 * only this extension can read. Files are deleted when the tab closes (best
 * effort) and any left-over file older than STALE_MS is deleted at startup.
 * Only log CONTENT is written there, never the signed link or its token.
 */
(() => {
  const CACHE_LINES = 20000;

  class DiskLines {
    constructor(blob) {
      this.blob = blob;
      this.length = 0;
      this.maxLen = 0;
      this.isDisk = true;
      this._starts = new Float64Array(65536);
      this._pendingStart = 0;
      this._endsWithNewline = false;
      this._size = 0;
      this._cache = new Map();
    }

    _push(start) {
      if (this.length >= this._starts.length) {
        const next = new Float64Array(this._starts.length * 2);
        next.set(this._starts);
        this._starts = next;
      }
      this._starts[this.length++] = start;
    }

    // Feed the raw bytes in order; `base` is the absolute offset of u8[0].
    indexBytes(u8, base) {
      for (let i = u8.indexOf(10); i !== -1; i = u8.indexOf(10, i + 1)) {
        const end = base + i;
        if (end - this._pendingStart > this.maxLen) this.maxLen = end - this._pendingStart;
        this._push(this._pendingStart);
        this._pendingStart = end + 1;
      }
    }

    finish(size) {
      this._size = size;
      this._endsWithNewline = this._pendingStart >= size;
      if (this._pendingStart < size) {
        if (size - this._pendingStart > this.maxLen) this.maxLen = size - this._pendingStart;
        this._push(this._pendingStart);
      }
      this._starts = this._starts.slice(0, this.length);
    }

    _end(i) {
      if (i + 1 < this.length) return this._starts[i + 1] - 1;
      return this._endsWithNewline ? this._size - 1 : this._size;
    }

    // Reads lines [from, to) from disk. Returns an array of strings.
    async readLines(from, to) {
      from = Math.max(0, from);
      to = Math.min(this.length, to);
      if (to <= from) return [];
      const text = await this.blob.slice(this._starts[from], this._end(to - 1)).text();
      const parts = text.split("\n");
      for (let k = 0; k < parts.length; k++) {
        // "\r" before a newline is not part of the line (the last line keeps it
        // only if the file does not end with a newline, as in line-store.js)
        const isFinalUnterminated = from + k === this.length - 1 && !this._endsWithNewline;
        if (!isFinalUnterminated && parts[k].endsWith("\r")) parts[k] = parts[k].slice(0, -1);
      }
      for (let k = 0; k < parts.length; k++) this._remember(from + k, parts[k]);
      return parts;
    }

    async readLine(i) {
      return (await this.readLines(i, i + 1))[0] ?? "";
    }

    // Makes sure the listed line indices are in the cache (contiguous runs
    // are read together).
    async ensure(indices) {
      const missing = indices.filter(i => !this._cache.has(i)).sort((a, b) => a - b);
      let k = 0;
      while (k < missing.length) {
        let j = k;
        while (j + 1 < missing.length && missing[j + 1] === missing[j] + 1 && j - k < 400) j++;
        await this.readLines(missing[k], missing[j] + 1);
        k = j + 1;
      }
    }

    cached(i) {
      return this._cache.get(i) ?? "";
    }

    has(i) {
      return this._cache.has(i);
    }

    _remember(i, text) {
      if (this._cache.has(i)) this._cache.delete(i);
      this._cache.set(i, text);
      if (this._cache.size > CACHE_LINES) {
        const drop = this._cache.size - CACHE_LINES;
        let n = 0;
        for (const key of this._cache.keys()) {
          this._cache.delete(key);
          if (++n >= drop) break;
        }
      }
    }

    lineLength(i) {
      return i >= 0 && i < this.length ? this._end(i) - this._starts[i] : 0;
    }
  }

  const PREFIX = "btlv-log-";
  const STALE_MS = 24 * 60 * 60 * 1000;

  const DiskBuffer = {
    available() {
      return !!navigator.storage?.getDirectory;
    },

    async create() {
      const root = await navigator.storage.getDirectory();
      const name = `${PREFIX}${Date.now()}-${crypto.randomUUID()}.ndjson`;
      const handle = await root.getFileHandle(name, { create: true });
      const writable = await handle.createWritable();
      let closed = false;
      return {
        name,
        async write(u8) {
          await writable.write(u8);
        },
        async finish() {
          if (!closed) {
            closed = true;
            await writable.close();
          }
          return handle.getFile();
        },
        async remove() {
          try {
            if (!closed) {
              closed = true;
              await writable.abort();
            }
          } catch (_) { /* already closed */ }
          try {
            await root.removeEntry(name);
          } catch (_) { /* already gone */ }
        }
      };
    },

    // Deletes left-over files from tabs that closed without cleaning up.
    async cleanupStale(now = Date.now()) {
      try {
        const root = await navigator.storage.getDirectory();
        for await (const [name] of root.entries()) {
          if (!name.startsWith(PREFIX)) continue;
          const created = Number(name.slice(PREFIX.length).split("-")[0]);
          if (!Number.isFinite(created) || now - created > STALE_MS) {
            await root.removeEntry(name).catch(() => {});
          }
        }
      } catch (_) { /* storage unavailable */ }
    }
  };

  globalThis.BTLV_DISK = Object.freeze({ DiskLines, DiskBuffer });
})();
