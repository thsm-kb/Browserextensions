/*
 * Browsertrix Crawl Log Viewer - news sources for the loading cards
 *
 * EDIT HERE to change news feeds or the time window. Each source:
 *   id      stable identifier (used to remember items; do not reuse ids)
 *   name    shown on the card
 *   url     an RSS or Atom feed (https)
 *   kind    "release" | "community" | "shutdown" (card label and symbol)
 *   titleFilter (optional) only entries whose title matches this regex
 * Chrome asks for access to each feed's site when news is turned on in
 * Settings; after adding a source, users turn news off and on once.
 * Validated sources are listed in README.md; a source that fails is shown as
 * unavailable in Settings and never blocks the others.
 */
(() => {
  globalThis.BTLV_NEWS_CONFIG = Object.freeze({
    MAX_AGE_DAYS: 30,        // only items PUBLISHED within this many days
    MAX_PER_SOURCE: 10,      // newest items per source
    REFRESH_HOURS: 24,       // fetch feeds at most this often
    CARD_TITLE_MAX: 60,      // card length limits (characters)
    CARD_TEXT_MAX: 240,
    EXCERPT_CHARS: 1200,     // plain text given to Gemini Nano per item
    GEMINI_MAX_PER_REFRESH: 12,
    FETCH_TIMEOUT_MS: 15000,
    SOURCES: [
      { id: "heritrix-releases", name: "Heritrix releases", url: "https://github.com/internetarchive/heritrix3/releases.atom", kind: "release" },
      { id: "browsertrix-releases", name: "Browsertrix releases", url: "https://github.com/webrecorder/browsertrix/releases.atom", kind: "release" },
      { id: "browsertrix-crawler-releases", name: "Browsertrix Crawler releases", url: "https://github.com/webrecorder/browsertrix-crawler/releases.atom", kind: "release" },
      { id: "netarchivesuite-releases", name: "NetarchiveSuite releases", url: "https://github.com/netarchivesuite/netarchivesuite/releases.atom", kind: "release" },
      { id: "pywb-releases", name: "pywb releases", url: "https://github.com/webrecorder/pywb/releases.atom", kind: "release" },
      { id: "replaywebpage-releases", name: "ReplayWeb.page releases", url: "https://github.com/webrecorder/replayweb.page/releases.atom", kind: "release" },
      { id: "solrwayback-releases", name: "SolrWayback releases", url: "https://github.com/netarchivesuite/solrwayback/releases.atom", kind: "release" },
      { id: "webrecorder-blog", name: "Webrecorder Blog", url: "https://webrecorder.net/feed.xml", kind: "community" },
      { id: "iipc-blog", name: "IIPC Blog", url: "https://netpreserveblog.wordpress.com/feed/", kind: "community" },
      { id: "ia-blog", name: "Internet Archive Blog", url: "https://blog.archive.org/feed/", kind: "community" },
      { id: "loc-signal", name: "The Signal (Library of Congress)", url: "https://blogs.loc.gov/thesignal/feed/", kind: "community" },
      { id: "archiveteam-deathwatch", name: "ArchiveTeam Deathwatch", url: "https://wiki.archiveteam.org/api.php?action=feedrecentchanges&feedformat=atom", kind: "shutdown", titleFilter: "^Deathwatch(/|$)" }
    ]
  });
})();
