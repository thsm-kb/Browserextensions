/*
 * Browsertrix Crawl Log Viewer - cards while a crawl log loads
 *
 * While a crawl log downloads and parses, a friendly card in the middle of
 * the screen shows a "good to know" tip (loading-cards-data.js) or, when the
 * user turned news on in Settings, a fresh web-archiving news item (news.js).
 * It appears only if loading takes longer than SHOW_AFTER_MS, keeps a slim
 * copy of the loading progress visible, and never blocks the page behind it.
 */
(() => {
  const SHOW_AFTER_MS = 1500;
  const MIN_VISIBLE_MS = 1500; // a card never blinks away right after appearing
  const NEWS_EVERY = 3; // when news exists: first card, then every 3rd card
  const NEWS_KIND_INFO = {
    release: { label: "New release", icon: "🆕" },
    community: { label: "Web-archiving news", icon: "📰" },
    shutdown: { label: "Shutdown watch", icon: "⚠️" }
  };
  const DATA = globalThis.BTLV_CARD_DATA;
  const NEWS = globalThis.BTLV_NEWS;
  if (!DATA) return;

  let overlay = null;
  let deck = [];
  let position = -1;
  let showTimer = null;
  let progressTimer = null;
  let loading = false;
  let enabled = true;
  let shownAt = 0;
  let lingerTimer = null;

  function shuffle(list) {
    const a = list.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function buildDeck(newsCards) {
    const tips = shuffle(DATA.TIPS.map(t => ({ type: "tip", ...t })));
    const news = shuffle(newsCards.map(n => ({ type: "news", ...n })));
    const out = [];
    let t = 0;
    let n = 0;
    while (t < tips.length || n < news.length) {
      const wantNews = n < news.length && (out.length % NEWS_EVERY === 0 || t >= tips.length);
      out.push(wantNews ? news[n++] : tips[t++]);
    }
    return out;
  }

  function formatDate(ms) {
    try {
      return new Date(ms).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
    } catch (_) {
      return "";
    }
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = el("div", "lc-overlay");
    overlay.hidden = true;
    const card = el("section", "lc-card");
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-modal", "false");
    card.setAttribute("aria-labelledby", "lcTitle");
    card.innerHTML = `
      <div class="lc-kicker"><span class="lc-spinner" aria-hidden="true"></span><span class="lc-kicker-text">While your crawl log loads…</span></div>
      <button class="lc-close" type="button" aria-label="Close cards for this load" title="Close (Esc)">&times;</button>
      <div class="lc-meta"><span class="lc-icon" aria-hidden="true"></span><span class="lc-label"></span></div>
      <h2 class="lc-title" id="lcTitle"></h2>
      <p class="lc-text"></p>
      <p class="lc-source"></p>
      <a class="lc-link" target="_blank" rel="noopener noreferrer"></a>
      <div class="lc-actions">
        <button class="lc-off" type="button">Don’t show cards while loading</button>
        <button class="lc-next" type="button">Next <span aria-hidden="true">›</span></button>
        <button class="lc-ready" type="button" hidden>Show my log</button>
      </div>`;
    overlay.appendChild(card);
    document.body.appendChild(overlay);
    card.querySelector(".lc-close").addEventListener("click", hide);
    card.querySelector(".lc-next").addEventListener("click", next);
    card.querySelector(".lc-ready").addEventListener("click", hide);
    card.querySelector(".lc-off").addEventListener("click", async () => {
      enabled = false;
      hide();
      try { await NEWS?.setPref("cards", false); } catch (_) {}
    });
    document.addEventListener("keydown", event => {
      if (!overlay || overlay.hidden) return;
      if (event.key === "Escape") {
        event.preventDefault();
        hide();
      } else if ((event.key === "ArrowRight" || event.key.toLowerCase() === "n") && !event.target.closest?.("input, textarea, select")) {
        if (loading) {
          event.preventDefault();
          next();
        }
      }
    });
    return overlay;
  }

  function render(item) {
    const card = overlay.querySelector(".lc-card");
    let icon;
    let label;
    if (item.type === "news") {
      ({ icon, label } = NEWS_KIND_INFO[item.kind] || NEWS_KIND_INFO.community);
    } else {
      ({ icon, label } = DATA.CATEGORY_INFO[item.cat] || { icon: "💡", label: "Good to know" });
    }
    card.dataset.type = item.type === "news" ? `news-${item.kind}` : item.cat;
    card.querySelector(".lc-icon").textContent = icon;
    card.querySelector(".lc-label").textContent = label;
    card.querySelector(".lc-title").textContent = item.title;
    card.querySelector(".lc-text").textContent = item.text;

    const source = card.querySelector(".lc-source");
    if (item.type === "news") {
      const parts = [item.sourceName, `published ${formatDate(item.publishedMs)}`];
      if (item.by === "gemini-nano") parts.push("summarised on-device by Gemini Nano");
      source.textContent = parts.join(" · ");
      source.hidden = false;
    } else {
      source.hidden = true;
    }

    const link = card.querySelector(".lc-link");
    const href = item.link || "";
    link.hidden = !href;
    if (href) {
      link.href = href;
      link.textContent = item.type === "news" ? "Read the original ↗" : "Learn more ↗";
    }
  }

  function next() {
    if (!deck.length) return;
    position = (position + 1) % deck.length;
    render(deck[position]);
  }

  // v1.16: the card no longer repeats the loading progress.
  function copyProgress() {}

  async function show() {
    if (!loading || !enabled) return;
    let newsCards = [];
    try { newsCards = (await NEWS?.getCards()) || []; } catch (_) { newsCards = []; }
    if (!loading) return;
    deck = buildDeck(newsCards);
    position = -1;
    ensureOverlay();
    const card = overlay.querySelector(".lc-card");
    card.classList.remove("ready");
    overlay.querySelector(".lc-kicker-text").textContent = "While your crawl log loads…";
    overlay.querySelector(".lc-next").hidden = false;
    overlay.querySelector(".lc-ready").hidden = true;
    next();
    clearTimeout(lingerTimer);
    overlay.hidden = false;
    shownAt = performance.now();
    requestAnimationFrame(() => overlay.classList.add("visible"));
    copyProgress();
    progressTimer = setInterval(copyProgress, 250);
  }

  function hide() {
    clearTimeout(lingerTimer);
    clearTimeout(showTimer);
    clearInterval(progressTimer);
    showTimer = null;
    progressTimer = null;
    if (!overlay) return;
    overlay.classList.remove("visible");
    overlay.hidden = true;
  }

  async function loadStarted() {
    loading = true;
    clearTimeout(showTimer);
    try {
      enabled = NEWS ? (await NEWS.prefs()).cards : true;
    } catch (_) {
      enabled = true;
    }
    if (!enabled) return;
    showTimer = setTimeout(show, SHOW_AFTER_MS);
  }

  function isBeingRead(card) {
    return card.matches(":hover") || card.contains(document.activeElement);
  }

  // Ready, and the user is reading: keep the card until they close it.
  function keepReady(card) {
    setReady(card);
    overlay.querySelector(".lc-next").hidden = true;
    overlay.querySelector(".lc-ready").hidden = false;
  }

  function setReady(card) {
    clearInterval(progressTimer);
    card.classList.add("ready");
    overlay.querySelector(".lc-kicker-text").textContent = "Your crawl log is ready";
  }

  function loadFinished({ ok = true } = {}) {
    loading = false;
    clearTimeout(showTimer);
    showTimer = null;
    if (!overlay || overlay.hidden) return;
    const card = overlay.querySelector(".lc-card");
    // Shown only a moment ago: let it be seen briefly, marked ready, then go.
    const visibleFor = performance.now() - shownAt;
    if (ok && visibleFor < MIN_VISIBLE_MS && !isBeingRead(card)) {
      setReady(card);
      // If the user starts reading during this moment, keep the card for them.
      lingerTimer = setTimeout(() => (isBeingRead(card) ? keepReady(card) : hide()), MIN_VISIBLE_MS - visibleFor);
      return;
    }
    // Someone reading the card keeps it until they choose to close it.
    if (ok && (card.matches(":hover") || card.contains(document.activeElement))) {
      clearInterval(progressTimer);
      card.classList.add("ready");
      overlay.querySelector(".lc-kicker-text").textContent = "Your crawl log is ready";
      overlay.querySelector(".lc-next").hidden = true;
      overlay.querySelector(".lc-ready").hidden = false;
      return;
    }
    hide();
  }

  globalThis.BTLV_LOADING_CARDS = Object.freeze({ loadStarted, loadFinished, buildDeck });
})();
