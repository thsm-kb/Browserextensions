Browsertrix Crawl Log Viewer v1.6.1
===================================

made by Thomas Smedebøl, Royal Danish Library

Purpose
-------
Intercept Browsertrix "Download Logs" links on btrix-cloud-prod.kb.dk and open
the NDJSON crawl log in a local Chrome extension viewer focused on crawl QA,
resource inspection and diagnostics.

Install / upgrade
-----------------
1. Unzip the package.
2. Open chrome://extensions
3. Enable Developer mode.
4. If upgrading, replace the old folder and press Reload. Otherwise choose
   "Load unpacked" and select the browsertrix-log-viewer folder.
5. Click "Download Logs" in Browsertrix.
6. Use the Guide button in the viewer for feature and interpretation notes.

New in v1.6.1 (review fixes)
----------------------------
- Logs with very many memory samples (large --logging debug crawls) no longer
  fail to load (stack overflow in the diagnostics).
- Crawl-limit detection uses Browsertrix's own stop messages (size, time,
  failed-page, disk-utilization thresholds, page limit). "retry limit
  reached" for one page is no longer reported as a crawl limit; page limit 0
  is shown as "no page limit configured".
- Disk-utilization stops (logged at info level) count as storage issues.
- Page outcomes follow Browsertrix semantics: completed, failed (retry limit
  reached / empty non-200), skipped, started.
- A .ts file with a non-video MIME type (TypeScript) is no longer classified
  as streaming video.
- Blocking and RAM chips state their limits: HTTP status is only logged for
  failed pages; RSS is the crawler's Node.js process, not Chrome.
- Gemini Nano: real line breaks in the prompt, the expected JSON shape is
  described, finding severities are shown, caveats are passed as facts.
- Less memory per row; file size no longer measured by copying the log.
- The log is fetched without cookies; the signed URL is kept until the
  download succeeds so a failed download can be retried by reloading.
- Removed the unneeded "tabs" permission. MIME/type label tables now live
  only in mime-groups.js.

New in v1.6.0
-------------
- New "Raw log" tab showing the original log as code: line numbers (same as
  the table's source line), JSON syntax colouring, gutter marks for warn,
  error/fatal and malformed lines.
- Plain-text or regular-expression search with match case, next/previous
  (Enter / Shift+Enter / F3), "Only matching lines" (grep-style) and
  "Wrap lines" toggles, and Go to line.
- Search runs in a Web Worker; a regex that stalls for 8 s is stopped.
- Every expanded table row links to its line in the raw view.

New in v1.5.1
-------------
- Added GitHub-ready README.md with installation, features, MIME methodology,
  privacy/security, diagnostics, development notes and version history.

New in v1.5.0
-------------
- New Guide page with feature explanations, technical workflow, interpretation
  caveats, privacy notes and MIME-grouping documentation.
- Guide title includes the live extension version and the byline:
  "made by Thomas Smedebøl, Royal Danish Library".
- Added Instructions_for_agents.txt with architecture, decisions, requirements,
  testing notes and continuation guidance for another AI/developer.
- New sortable MIME group column and MIME-group filter.
- MIME grouping is based on the IANA Media Types registry and top-level media
  type families, with a documented viewer-side functional overlay for:
  * Images
  * Office / documents
  * Audio files
  * Video files
  * Streaming manifests / playlists
  * Streaming audio
  * Streaming video
  * Streaming media segments
  * Archives / compressed
  * Structured data
  * Scripts / web code
  * Stylesheets
  * Fonts
  * E-books
  * 3D / models
  * Messages / multipart
  * Application / other
  * Binary / unknown
- Streaming classification is conservative: ordinary audio/* and video/* are
  not called streaming unless an HLS/DASH/segment-specific MIME or URL signal
  exists.
- MIME values come from Browsertrix details/headers where available. When a MIME
  is missing, a small explicit list of recognized filename extensions may infer
  one. Hostnames/TLDs are never used as file extensions.

Existing features retained
--------------------------
- Prominent animated "Fetching Browsertrix crawl log…" state.
- Streaming download progress:
  * percentage + received/total bytes when reliable Content-Length is known;
  * indeterminate progress + received bytes otherwise.
- Sortable/filterable Browsertrix NDJSON table.
- Pages as a first-class option in the file-type filter.
- Resource type, size and Domain columns.
- URL-aware file-type detection; .dk/.com/.org are never file types.
- Filter-dependent resource totals: unique count, known sizes, combined size,
  average, median and largest.
- Compact firstSeed / seed count / scope / crawler-version header.
- Soft-404 probe against <firstSeed origin>/browsertrixsoft404detect.
- Suspected soft-404 marking by host + normalized type + approximately equal
  size (±8% or ±2 KB, whichever is larger).
- URL provenance tracing:
  * EXACT for resources where Browsertrix logs details.page;
  * EXACT for explicit source/referrer/parent metadata;
  * INFERRED for queued page URLs during a single-worker crawl when timing makes
    a parent inference defensible;
  * INITIAL for URLs queued before page processing starts.
- Deterministic crawl diagnostics for:
  * final crawl statistics and configured limits;
  * RAM/heap telemetry and suspicious growth;
  * CPU/storage information only when explicitly logged;
  * HTTP blocking/rate-limit signals and WAF/challenge evidence;
  * timeouts, warnings/errors, large resources and high-volume domains.
- Optional on-device Gemini Nano report via Chrome's Prompt API. JavaScript
  calculates facts first; Gemini interprets the compact summary.

MIME references
---------------
Authoritative MIME registrations:
https://www.iana.org/assignments/media-types/media-types.xhtml

Authoritative top-level MIME families:
https://www.iana.org/assignments/top-level-media-types/top-level-media-types.xhtml

The viewer's practical groups such as "Office / documents" and "Streaming
video" are not IANA top-level types. They are deliberately documented QA groups
built from registered MIME values plus conservative URL signals.

Gemini Nano notes
-----------------
The AI button uses Chrome's built-in LanguageModel / Prompt API when available.
Chrome may need to download Gemini Nano the first time. Model download progress
is shown in the viewer. The report is based on a deterministic fact summary,
not the full raw log, and the raw log is not sent to a cloud AI API by this
feature.

Soft-404 host permission
------------------------
The manifest declares *://*/* as an OPTIONAL host permission only. The extension
does not receive access to all sites at installation. The soft-404 test requests
access only to the concrete first-seed host through chrome.permissions.request().

Caveats
-------
- A 200 response from /browsertrixsoft404detect proves only that the host can
  return success for a deliberately nonexistent path. Similar-size/type URLs are
  marked SOFT404? as suspects, not confirmed missing pages.
- Browsertrix queue entries do not always log a referrer/parent. Timing-based
  provenance is labeled INFERRED and is not guessed for multi-worker crawls.
- CPU/storage capacity are reported only when present in the log.
- A large-resource internal threshold is not automatically a crawl storage
  quota.
- MIME grouping is intentionally conservative. Vendor-specific application MIME
  types that are not explicitly categorized remain "Application / other".
