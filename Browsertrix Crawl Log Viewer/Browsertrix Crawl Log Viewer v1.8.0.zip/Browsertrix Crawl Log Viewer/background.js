const KEY_PREFIX = "btrixLog:";

// Entries are removed by the viewer once the log is downloaded. Entries for
// viewers that never loaded (tab closed early, fetch failed and abandoned) are
// pruned here. chrome.storage.session lives in memory and is cleared when the
// browser restarts, so no startup cleanup is needed.
const MAX_ENTRY_AGE_MS = 60 * 60 * 1000;

async function pruneOldEntries() {
  const all = await chrome.storage.session.get(null);
  const cutoff = Date.now() - MAX_ENTRY_AGE_MS;
  const remove = Object.entries(all)
    .filter(([key, value]) => key.startsWith(KEY_PREFIX) && (!value?.createdAt || value.createdAt < cutoff))
    .map(([key]) => key);
  if (remove.length) await chrome.storage.session.remove(remove);
}

async function openViewer(logUrl, filename) {
  await pruneOldEntries().catch(() => {});
  const id = crypto.randomUUID();
  const key = KEY_PREFIX + id;

  // Keep the signed URL only in session storage. It is not placed in the
  // viewer URL, browsing history, bookmarks, or persistent extension storage.
  await chrome.storage.session.set({
    [key]: {
      url: logUrl,
      filename: filename || "browsertrix-logs.log",
      createdAt: Date.now()
    }
  });

  await chrome.tabs.create({
    url: chrome.runtime.getURL(`viewer.html#${encodeURIComponent(id)}`),
    active: true
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "OPEN_BROWSERTRIX_LOG") return;

  (async () => {
    try {
      const u = new URL(message.url);
      if (u.origin !== "https://btrix-cloud-prod.kb.dk") {
        throw new Error("Blocked unexpected log host: " + u.origin);
      }
      if (!/^\/api\/orgs\/[^/]+\/crawls\/[^/]+\/logs$/.test(u.pathname)) {
        throw new Error("URL does not look like a Browsertrix crawl log endpoint.");
      }

      await openViewer(message.url, message.filename);
      sendResponse({ ok: true });
    } catch (error) {
      console.error("Browsertrix Log Viewer:", error);
      sendResponse({ ok: false, error: String(error?.message || error) });
    }
  })();

  return true;
});

chrome.action.onClicked.addListener(async () => {
  await chrome.tabs.create({
    url: chrome.runtime.getURL("viewer.html"),
    active: true
  });
});
