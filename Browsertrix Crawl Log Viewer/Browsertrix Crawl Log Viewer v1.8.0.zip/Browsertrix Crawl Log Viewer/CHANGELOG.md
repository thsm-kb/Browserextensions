# Changelog

All notable changes to **Browsertrix Crawl Log Viewer**.

## 1.8.0

### Changed
- The **Details** column is gone. The details toggle (*N fields*) now sits at the end of each **Message** cell and still opens the full `details` JSON and the link to the raw log line. The Message column is wider to make room.
- The extension, its folder and its download are now all named **Browsertrix Crawl Log Viewer**.
- New README in the same form as the other extensions in this repository, with installation steps for a downloaded zip. This changelog replaces `README.txt`.

### Upgrade note
- The folder name changed. Chrome identifies an unpacked extension by its folder, so loading the new folder next to the old one installs a **second copy**. Remove the old card in `chrome://extensions` first, or copy the new files into your existing folder. See the README.

## 1.7.0
- Table columns can be moved left and right by dragging their headers. A blue line shows where the column will land; the dragged header stays inside the table, and the table scrolls when you hold it near an edge. Esc cancels a drag.
- Keyboard: focus a header with Tab, Alt+←/→ moves it, Enter sorts.
- Columns can only be moved, never hidden or removed. The order is remembered; **Reset column order** below the table restores the default.
- A click without dragging still sorts the column.

## 1.6.1 (review fixes)
- Logs with very many memory samples (large `--logging debug` crawls) no longer fail to load (stack overflow in the diagnostics).
- Crawl-limit detection uses Browsertrix's own stop messages (size, time, failed-page and disk-utilization thresholds, page limit). *Retry limit reached* for one page is no longer reported as a crawl limit, and page limit 0 is shown as *no page limit configured*.
- Disk-utilization stops (logged at info level) count as storage issues.
- Page outcomes follow Browsertrix semantics: completed, failed (retry limit reached or empty non-200), skipped, started.
- A `.ts` file with a non-video MIME type (TypeScript) is no longer classified as streaming video.
- The blocking and RAM chips state their limits: HTTP status is only logged for failed pages, and RSS is the crawler's Node.js process, not Chrome.
- Gemini Nano: real line breaks in the prompt, the expected JSON shape is described, finding severities are shown, and the caveats are passed on as facts.
- Less memory per row; the file size is no longer measured by copying the log.
- The log is fetched without cookies. The signed URL is kept until the download succeeds, so a failed download can be retried by reloading.
- Removed the unneeded `tabs` permission. MIME/type label tables now live only in `mime-groups.js`.

## 1.6.0
- New **Raw log** tab showing the original log as code: line numbers (the same as the table's source line), JSON syntax colouring, and gutter marks for warn, error/fatal and malformed lines.
- Plain-text or regular-expression search with match case, next/previous (Enter, Shift+Enter, F3), **Only matching lines** (grep-style) and **Wrap lines** toggles, and Go to line.
- Search runs in a Web Worker; a regular expression that stalls for 8 seconds is stopped.
- Every expanded table row links to its line in the raw view.

## 1.5.1
- Added a GitHub-ready `README.md` with installation, features, MIME methodology, privacy and security, diagnostics, development notes and version history.

## 1.5.0
- New **Guide** page with feature explanations, technical workflow, interpretation caveats, privacy notes and MIME-grouping documentation. The guide title shows the live extension version and the byline *made by Thomas Smedebøl, Royal Danish Library*.
- Added `Instructions_for_agents.txt` with architecture, decisions, requirements, testing notes and continuation guidance for another developer or AI agent.
- New sortable **MIME group** column and MIME-group filter. Grouping is based on the IANA Media Types registry and top-level media type families, with a documented functional overlay for QA (Images, Office / documents, Audio files, Video files, Streaming manifests / playlists, Streaming audio, Streaming video, Streaming media segments, Archives / compressed, Structured data, Scripts / web code, Stylesheets, Fonts, E-books, 3D / models, Messages / multipart, Application / other, Binary / unknown).
- Streaming classification is conservative: ordinary `audio/*` and `video/*` are not called streaming without an HLS/DASH/segment-specific MIME or URL signal.
- MIME values come from Browsertrix details/headers where available. When a MIME is missing, a small explicit list of recognized filename extensions may infer one. Hostnames and TLDs are never used as file extensions.

## 1.4.0
- Prominent *Fetching Browsertrix crawl log…* state with streaming download progress: percentage and received/total bytes when a reliable `Content-Length` is known, otherwise an indeterminate bar with received bytes.
- **Pages** as a first-class option in the file-type filter.
- URL-aware file-type detection; `.dk`, `.com`, `.org` are never file types.
- **Domain** column.
- Deterministic crawl diagnostics and the optional on-device **Gemini Nano** report.

## 1.3.1
- Runtime host-permission fix.

## 1.3.0
- URL provenance / origin tracing: EXACT for `details.page` and explicit source/referrer/parent metadata, INFERRED for queued page URLs in single-worker crawls when timing makes it defensible, INITIAL for URLs queued before page processing starts.

## 1.2.0
- Soft-404 probe against `<first-seed origin>/browsertrixsoft404detect`, with suspected soft-404 marking by host, normalized type and approximately equal size (±8 % or ±2 KB, whichever is larger).
- Filter-dependent resource totals: unique count, known sizes, combined size, average, median and largest.
- Compact first-seed / seed count / scope / crawler-version header.

## 1.1.0
- Resource type and size support.

## 1.0.0
- Initial viewer: intercepts Browsertrix **Download Logs** and opens the log in a sortable, filterable table.
