(() => {
  const LOG_PATH_RE = /^\/api\/orgs\/[^/]+\/crawls\/[^/]+\/logs$/;

  function getAttr(el, name) {
    if (!el || typeof el.getAttribute !== "function") return null;
    return el.getAttribute(name);
  }

  function candidateFromEvent(event) {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [];

    for (const node of path) {
      if (!(node instanceof Element)) continue;

      const href = getAttr(node, "href") || node.href;
      if (!href) continue;

      let url;
      try {
        url = new URL(href, location.href);
      } catch {
        continue;
      }

      if (url.origin !== location.origin) continue;
      if (!LOG_PATH_RE.test(url.pathname)) continue;
      if (!url.searchParams.has("auth_bearer")) continue;

      const filename =
        getAttr(node, "download") ||
        path.map(n => getAttr(n, "download")).find(Boolean) ||
        `browsertrix-${url.pathname.split("/").at(-2) || "crawl"}-logs.log`;

      return { url: url.href, filename };
    }

    // Fallback for clicks on descendants where the composed path does not
    // expose the href-bearing node as expected.
    const target = event.target instanceof Element ? event.target : null;
    const host = target?.closest?.('sl-button[download][href*="/crawls/"][href*="/logs"]');
    if (host) {
      const href = host.getAttribute("href");
      let url = null;
      try {
        url = href ? new URL(href, location.href) : null;
      } catch {
        url = null;
      }
      if (url) {
        if (url.origin === location.origin && LOG_PATH_RE.test(url.pathname) && url.searchParams.has("auth_bearer")) {
          return {
            url: url.href,
            filename: host.getAttribute("download") || "browsertrix-logs.log"
          };
        }
      }
    }

    return null;
  }

  function normalDownload(candidate) {
    const a = document.createElement("a");
    a.href = candidate.url;
    a.download = candidate.filename;
    a.rel = "noreferrer noopener";
    a.dataset.btrixLogViewerBypass = "1";
    (document.body || document.documentElement).appendChild(a);
    a.click();
    a.remove();
  }

  window.addEventListener("click", event => {
    if (event.button !== 0 || event.defaultPrevented) return;

    const path = typeof event.composedPath === "function" ? event.composedPath() : [];
    if (path.some(node => node instanceof Element && node.dataset?.btrixLogViewerBypass === "1")) return;

    const candidate = candidateFromEvent(event);
    if (!candidate) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    chrome.runtime.sendMessage({
      type: "OPEN_BROWSERTRIX_LOG",
      url: candidate.url,
      filename: candidate.filename
    }).then(response => {
      if (!response?.ok) {
        console.error("Browsertrix Log Viewer:", response?.error || "Viewer could not be opened");
        normalDownload(candidate);
      }
    }).catch(error => {
      console.error("Browsertrix Log Viewer: unable to open viewer", error);
      // Fail open: if the extension fails, keep Browsertrix's original
      // download behavior available.
      normalDownload(candidate);
    });
  }, true);
})();
