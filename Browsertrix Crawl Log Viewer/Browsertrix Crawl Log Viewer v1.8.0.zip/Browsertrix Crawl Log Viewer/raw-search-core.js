/*
 * Browsertrix Crawl Log Viewer - raw log search core
 *
 * Shared by the page (highlighting visible lines, fallback search) and by
 * raw-search-worker.js (full-log search off the main thread). Keeping the
 * pattern compiler in one place guarantees that what the worker counts is
 * exactly what the page highlights.
 */
(() => {
  // Stored match positions are capped so a pattern such as "." on a large log
  // cannot exhaust memory. Matching lines are always tracked in full.
  const MATCH_STORE_CAP = 100000;
  // Beyond this count we stop enumerating every match and only test whether
  // each remaining line matches at all.
  const MATCH_COUNT_CAP = 1000000;

  function escapeRegExp(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // Returns { re, error }. re is null for an empty query or an invalid pattern.
  function compile(query, { regex = false, caseSensitive = false } = {}) {
    if (typeof query !== "string" || query === "") return { re: null, error: "" };
    const source = regex ? query : escapeRegExp(query);
    const flags = caseSensitive ? "g" : "gi";
    try {
      return { re: new RegExp(source, flags), error: "" };
    } catch (error) {
      return { re: null, error: String(error?.message || error) };
    }
  }

  // Appends [start, end] pairs for every match in one line. Zero-length matches
  // (e.g. ^ or \b) are kept so the user can see where they occur, and the scan
  // is advanced manually so they cannot loop forever.
  function matchesInLine(re, line, out = [], limit = Infinity) {
    re.lastIndex = 0;
    let m;
    while (out.length < limit && (m = re.exec(line)) !== null) {
      out.push([m.index, m.index + m[0].length]);
      if (m[0].length === 0) re.lastIndex++;
      if (re.lastIndex > line.length) break;
    }
    return out;
  }

  function lineMatches(re, line) {
    re.lastIndex = 0;
    return re.test(line);
  }

  // Creates an incremental search over an array of lines. step(budgetMs)
  // processes lines until the budget is used and returns true when finished.
  function createSearch(lines, re) {
    const lineHits = [];
    const matchLine = [];
    const matchStart = [];
    const matchEnd = [];
    let total = 0;
    let totalCapped = false;
    let index = 0;
    const scratch = [];

    function step(budgetMs = 30) {
      const deadline = Date.now() + budgetMs;
      while (index < lines.length) {
        const line = lines[index];
        if (totalCapped) {
          if (lineMatches(re, line)) lineHits.push(index);
        } else {
          scratch.length = 0;
          matchesInLine(re, line, scratch, MATCH_COUNT_CAP - total + 1);
          if (scratch.length) {
            lineHits.push(index);
            for (const [s, e] of scratch) {
              if (matchLine.length < MATCH_STORE_CAP) {
                matchLine.push(index);
                matchStart.push(s);
                matchEnd.push(e);
              }
            }
            total += scratch.length;
            if (total > MATCH_COUNT_CAP) {
              total = MATCH_COUNT_CAP;
              totalCapped = true;
            }
          }
        }
        index++;
        // Checking the clock every line is cheap relative to a regex exec.
        if ((index & 63) === 0 && Date.now() >= deadline) break;
      }
      return index >= lines.length;
    }

    function result() {
      return {
        lineHits: Int32Array.from(lineHits),
        matchLine: Int32Array.from(matchLine),
        matchStart: Int32Array.from(matchStart),
        matchEnd: Int32Array.from(matchEnd),
        total,
        totalCapped,
        storedCapped: total > matchLine.length
      };
    }

    return {
      step,
      result,
      progress: () => (lines.length ? index / lines.length : 1)
    };
  }

  function splitLines(text) {
    const lines = String(text).split(/\r?\n/);
    // A trailing newline produces one empty final element that is not a line.
    if (lines.length > 1 && lines[lines.length - 1] === "") lines.pop();
    return lines;
  }

  globalThis.BTLV_RAW_SEARCH = Object.freeze({
    MATCH_STORE_CAP,
    MATCH_COUNT_CAP,
    compile,
    matchesInLine,
    createSearch,
    splitLines
  });
})();
