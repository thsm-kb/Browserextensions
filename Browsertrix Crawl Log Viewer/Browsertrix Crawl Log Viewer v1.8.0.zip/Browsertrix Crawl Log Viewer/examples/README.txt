Examples / development references
================================

example-browsertrix-crawl.log
  Actual Browsertrix crawl-log NDJSON used to test parsing, page/resource
  extraction, sizes, memory telemetry, soft-404 comparison and provenance.

reference-crawler-choice-bbc.json
  Additional supplied URL-structure reference. This file is NOT Browsertrix
  crawl-log NDJSON and should not be expected to open successfully as a crawl
  log in the viewer. It is retained only as a development/reference fixture.
