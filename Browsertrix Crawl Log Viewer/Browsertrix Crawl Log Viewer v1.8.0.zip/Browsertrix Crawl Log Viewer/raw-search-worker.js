/*
 * Browsertrix Crawl Log Viewer - raw log search worker
 *
 * Runs searches off the main thread so a slow regular expression cannot freeze
 * the viewer. Work is time-sliced: between slices the worker yields, which lets
 * a newer search request supersede the running one. It posts progress after
 * every slice; the page treats a long silence as a stuck regex (catastrophic
 * backtracking on a single line) and terminates the worker.
 */
importScripts("raw-search-core.js");

const { compile, createSearch, splitLines } = self.BTLV_RAW_SEARCH;

let lines = [];
let activeId = 0;

function yieldToMessages() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

async function runSearch({ id, query, regex, caseSensitive }) {
  activeId = id;
  const { re, error } = compile(query, { regex, caseSensitive });
  if (!re) {
    self.postMessage({ type: "result", id, error, empty: !error });
    return;
  }

  const search = createSearch(lines, re);
  while (!search.step(40)) {
    self.postMessage({ type: "progress", id, progress: search.progress() });
    await yieldToMessages();
    if (activeId !== id) return; // superseded by a newer request
  }

  const result = search.result();
  self.postMessage(
    { type: "result", id, ...result },
    [result.lineHits.buffer, result.matchLine.buffer, result.matchStart.buffer, result.matchEnd.buffer]
  );
}

self.onmessage = event => {
  const message = event.data || {};
  if (message.type === "load") {
    lines = splitLines(message.text || "");
    activeId = 0;
    self.postMessage({ type: "loaded", lineCount: lines.length });
  } else if (message.type === "search") {
    runSearch(message).catch(error => {
      self.postMessage({ type: "result", id: message.id, error: String(error?.message || error) });
    });
  } else if (message.type === "cancel") {
    activeId = 0;
  }
};
