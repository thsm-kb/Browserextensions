/*
 * Browsertrix Crawl Log Viewer - Browsertrix addresses
 *
 * The extension ships WITHOUT any Browsertrix address. Each user adds the
 * address(es) of their own Browsertrix in Settings; they are stored only in
 * this browser (chrome.storage.local). Shared by background.js (validation and
 * content-script registration) and settings.js (the Settings page), so both
 * apply exactly the same rules.
 */
(() => {
  const STORAGE_KEY = "btrixHosts";
  const SCRIPT_ID_PREFIX = "btrix-host-";
  const LOCAL_HOSTNAMES = new Set(["localhost", "127.0.0.1", "[::1]"]);
  const LOG_PATH_RE = /^\/api\/orgs\/[^/]+\/crawls\/[^/]+\/logs$/;

  // Accepts what people paste: a bare host name, a full address, or any page
  // inside Browsertrix. Returns { origin } or { error }; the path is ignored.
  function normalizeOrigin(input) {
    let text = String(input ?? "").trim();
    if (!text) return { error: "Enter the address of your Browsertrix." };
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = `https://${text}`;

    let url;
    try {
      url = new URL(text);
    } catch {
      return { error: "That doesn't look like a web address. Example: https://browsertrix.example.org" };
    }
    if (url.username || url.password) {
      return { error: "Leave out user names and passwords. Enter only the address." };
    }
    const local = LOCAL_HOSTNAMES.has(url.hostname);
    if (url.protocol !== "https:" && !(url.protocol === "http:" && local)) {
      return { error: "Use an https:// address. Plain http:// is accepted only for localhost, because the log link contains a login token." };
    }
    if (!local && !url.hostname.includes(".")) {
      return { error: "Enter the full host name, for example browsertrix.example.org." };
    }
    return {
      origin: url.origin,
      pathIgnored: url.pathname !== "/" || url.search !== "" || url.hash !== ""
    };
  }

  function isValidStoredOrigin(value) {
    if (typeof value !== "string") return false;
    const result = normalizeOrigin(value);
    return !result.error && result.origin === value;
  }

  // Chrome match patterns cannot express a port reliably, so the permission
  // covers the host name; the exact origin (including port) is still checked
  // in background.js before any log is opened.
  function matchPattern(origin) {
    const url = new URL(origin);
    return `${url.protocol}//${url.hostname}/*`;
  }

  function scriptId(origin) {
    return SCRIPT_ID_PREFIX + origin.replace(/[^a-z0-9]/gi, "_");
  }

  async function getHosts() {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    const list = stored[STORAGE_KEY];
    return Array.isArray(list) ? [...new Set(list.filter(isValidStoredOrigin))] : [];
  }

  async function setHosts(list) {
    const clean = [...new Set(list.filter(isValidStoredOrigin))];
    await chrome.storage.local.set({ [STORAGE_KEY]: clean });
    return clean;
  }

  globalThis.BTLV_HOSTS = Object.freeze({
    STORAGE_KEY,
    SCRIPT_ID_PREFIX,
    LOG_PATH_RE,
    normalizeOrigin,
    isValidStoredOrigin,
    matchPattern,
    scriptId,
    getHosts,
    setHosts
  });
})();
