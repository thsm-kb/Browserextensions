// Guide page: close button. Inline scripts are not allowed on MV3 extension pages, hence this file.
// The guide is opened as a tab by the popup (chrome.tabs.create); a page cannot reliably close a tab
// it did not open with window.close(), so the extension closes its own tab via chrome.tabs.
document.getElementById('close-guide')?.addEventListener('click', async () => {
  try {
    const tab = await chrome.tabs.getCurrent();
    if (tab?.id != null) { await chrome.tabs.remove(tab.id); return; }
  } catch { /* not running as an extension tab */ }
  window.close();
});

// Escape closes the guide too.
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !e.defaultPrevented) document.getElementById('close-guide')?.click();
});
