// Offscreen document: raw-HTML analysis and the Gemini Nano fallback when the Prompt API is not
// exposed to the service worker.
//
// v1.8: the raw side's URLs come from an emulation of Heritrix 3.14.1's own link extraction
// (lib/heritrix-extractor.js), run over the fetched source text. DOMParser (scripts are never executed
// in a DOMParser document) is still used for text length, framework hints and, for transparency, a
// count of plain <a href> links.

import { detectChallenge } from './lib/challenge.js';
import { extractHeritrixOutlinks } from './lib/heritrix-extractor.js';
import { runNano } from './lib/ai-core.js';

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return;
  if (msg.type === 'ANALYZE_HTML') {
    try { sendResponse({ ok: true, result: analyzeHtml(msg.html, msg.url, msg.status, msg.heritrixConfig || {}) }); }
    catch (err) { sendResponse({ ok: false, error: String(err?.message || err) }); }
    return;
  }
  if (msg.type === 'AI_CLASSIFY') {
    runNano(globalThis.LanguageModel, msg.payload, { timeoutMs: msg.timeoutMs })
      .then(sendResponse)
      .catch(err => sendResponse({ status: 'error', error: String(err?.message || err) }));
    return true;
  }
});

const LOAD_MORE_RE = /(?:load|show|view|see)\s+more|se\s+flere|vis\s+flere|indlæs\s+flere|hent\s+flere|flere\s+(?:kommentarer|resultater|artikler|svar|nyheder)|vis\s+mere/i;
const MANIFEST_RE = /(?:https?:)?\/\/[^\s"'<>\\]+?\.(?:m3u8|mpd)(?:\?[^\s"'<>\\]*)?|(?<![\w.])\/[^\s"'<>\\]+?\.(?:m3u8|mpd)(?:\?[^\s"'<>\\]*)?/gi;

function analyzeHtml(html, url, status, heritrixConfig = {}) {
  // What Heritrix would discover: source-order text scan, its own heuristics, base handling, hops.
  const { discoveries: _all, ...heritrix } = extractHeritrixOutlinks(String(html || ''), url, heritrixConfig); // duplicates not needed downstream
  const heritrixHttp = heritrix.outlinks.filter(o => o.scheme === 'http' || o.scheme === 'https');

  const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
  const baseHref = doc.querySelector('base[href]')?.getAttribute('href');
  let base = url;
  try { if (baseHref) base = new URL(baseHref, url).href; } catch {}
  const abs = raw => { try { const u = new URL(String(raw).trim(), base); u.hash = ''; return /^https?:$/.test(u.protocol) ? u.href : ''; } catch { return ''; } };

  // Plain DOM anchor scan — kept only as a transparency figure (what a "link scraper" would see).
  const domAnchors = new Set();
  for (const a of doc.querySelectorAll('a[href], area[href]')) { const u = abs(a.getAttribute('href')); if (u) domAnchors.add(u); if (domAnchors.size >= 5000) break; }

  const title = doc.title || '';
  const body = doc.body ? doc.body.cloneNode(true) : null;
  body?.querySelectorAll('script,style,noscript,template').forEach(n => n.remove());
  const text = (body?.textContent || '').replace(/\s+/g, ' ').trim();

  // "Discoverable in the raw HTML" = discovered by the Heritrix emulation (any hop type).
  const staticUrls = heritrixHttp.map(o => o.absoluteUrl);
  const inlineCode = [...doc.querySelectorAll('script:not([src]), style')].map(s => s.textContent || '').join('\n').replace(/\\\//g, '/');

  const unescaped = String(html || '').replace(/\\\//g, '/');
  const manifestUrls = [...new Set([...unescaped.matchAll(MANIFEST_RE)].map(m => m[0]))].slice(0, 30);
  const low = unescaped.toLowerCase();

  const scriptSrcs = [...doc.querySelectorAll('script[src]')].map(s => s.getAttribute('src'));
  const frameworks = [];
  if (doc.getElementById('__NEXT_DATA__') || scriptSrcs.some(s => /\/_next\//.test(s))) frameworks.push('Next.js');
  if (/window\.__NUXT__/.test(inlineCode) || scriptSrcs.some(s => /\/_nuxt\//.test(s))) frameworks.push('Nuxt');
  if (doc.querySelector('[ng-version]')) frameworks.push('Angular');
  if (doc.querySelector('[data-reactroot]') || scriptSrcs.some(s => /react(?:-dom)?[.-]/i.test(s))) frameworks.push('React');
  if (doc.querySelector('[data-v-app]') || /\sdata-v-[0-9a-f]{6,}/i.test(String(html).slice(0, 300000))) frameworks.push('Vue');

  return {
    title,
    htmlLength: String(html || '').length,
    textLength: text.length,
    links: heritrixHttp.map(o => o.absoluteUrl),
    heritrix,
    domAnchors: [...domAnchors],
    scriptCount: doc.scripts.length,
    externalScriptCount: scriptSrcs.length,
    frameworks,
    buttons: doc.querySelectorAll('button').length,
    iframes: doc.querySelectorAll('iframe').length,
    lazyStandard: doc.querySelectorAll('[loading="lazy"]').length,
    lazyDataSrc: doc.querySelectorAll('[data-src],[data-lazy-src],[data-original]').length,
    jsonLd: doc.querySelectorAll('script[type="application/ld+json"]').length,
    noscript: doc.querySelectorAll('noscript').length,
    loadMoreText: LOAD_MORE_RE.test(text),
    staticUrls,
    manifestUrls,
    challenge: detectChallenge({ html, title, text, status }),
    websocketHints: (low.match(/new\s+websocket\s*\(|\bwss?:\/\//g) || []).length,
    eventSourceHints: (low.match(/new\s+eventsource\s*\(|text\/event-stream/g) || []).length,
    graphQlHints: (low.match(/graphql/g) || []).length,
    cursorPaginationHints: (low.match(/endcursor|hasnextpage|pageinfo|nextcursor/g) || []).length,
  };
}
