// Injected into test tabs in the ISOLATED world (never MAIN), so page scripts cannot overwrite the
// APIs this probe relies on. Network activity is NOT measured here — the service worker records it
// through the DevTools Protocol and correlates it with the phase windows below.
// The probe is idempotent: re-injection reuses the existing instance.

(() => {
  if (globalThis.__ccProbe) return;

  const state = { observer: null, roots: [], linksBefore: null, phaseStarted: 0, phaseMenu: false, candidates: [], viewer: null, menuTriggers: [], menuItems: [] };
  const wait = ms => new Promise(r => setTimeout(r, ms));

  const norm = href => { try { const u = new URL(href, location.href); u.hash = ''; return /^https?:$/.test(u.protocol) ? u.href : ''; } catch { return ''; } };
  const docLinks = () => {
    const out = new Set();
    for (const a of document.querySelectorAll('a[href], area[href]')) { const u = norm(a.getAttribute('href')); if (u) out.add(u); if (out.size >= 5000) break; }
    return out;
  };
  const visible = el => {
    try {
      const r = el.getBoundingClientRect(); const st = getComputedStyle(el);
      return r.width >= 4 && r.height >= 4 && st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity || 1) > 0;
    } catch { return false; }
  };
  const inOverlay = el => {
    let n = el, depth = 0;
    while (n && n.nodeType === 1 && depth < 10) {
      try {
        const st = getComputedStyle(n);
        if (st.position === 'fixed' || st.position === 'sticky') return true;
        const id = `${n.id || ''} ${typeof n.className === 'string' ? n.className : ''}`;
        if (/(?:cookie|consent|gdpr|cmp|onetrust|cookiebot|usercentrics|didomi|modal|dialog|popup|newsletter|toast|snackbar)/i.test(id)) return true;
        if (n.getAttribute?.('role') === 'dialog' || n.getAttribute?.('aria-modal') === 'true') return true;
      } catch {}
      n = n.parentElement; depth++;
    }
    return false;
  };
  const CONSENT_ID_RE = /(?:cookie|consent|gdpr|\bcmp\b|onetrust|cookiebot|usercentrics|didomi|sp_message|coi-|newsletter)/i;
  const inConsent = el => {
    let n = el, depth = 0;
    while (n && n.nodeType === 1 && depth < 12) {
      const id = `${n.id || ''} ${typeof n.className === 'string' ? n.className : ''}`;
      if (CONSENT_ID_RE.test(id)) return true;
      n = n.parentElement; depth++;
    }
    return false;
  };
  const adLike = el => {
    try {
      if (el.closest?.('[data-ad],[data-ad-slot],[data-adunit],[aria-label*="advertisement" i],[aria-label*="sponsored" i],[aria-label*="annonce" i],[class*="advertisement" i],[class*="ad-slot" i],[class*="adslot" i],[id*="ad-slot" i],[id*="adslot" i],[id^="google_ads"],ins.adsbygoogle')) return true;
      const meta = `${el.id || ''} ${typeof el.className === 'string' ? el.className : ''}`;
      return /(?:^|[\s_-])(?:ads?|advert|advertisement|adslot|sponsor|sponsored|annonce|taboola|outbrain)(?:$|[\s_-])/i.test(meta);
    } catch { return false; }
  };
  const normalHref = el => {
    const a = el.closest?.('a[href]');
    if (!a) return false;
    const raw = (a.getAttribute('href') || '').trim();
    if (!raw || raw === '#' || /^javascript:/i.test(raw)) return false;
    try { return /^https?:$/i.test(new URL(raw, location.href).protocol); } catch { return false; }
  };
  const DANGER_RE = /(?:delete|remove|logout|log\s*out|sign\s*out|login|sign\s*in|buy|purchase|checkout|order|pay|subscribe|unsubscribe|submit|save|confirm|accept|reject|cookie|consent|download|print|share|follow|like|report|block|book|reservation|vote|rate|slet|log\s*ud|log\s*ind|køb|betal|bestil|abonn|tilmeld|afmeld|send|gem|bekræft|accepter|afvis|samtykke|stem|del\b)/i;
  const dangerous = el => {
    const d = `${el.innerText || el.textContent || ''} ${el.getAttribute?.('aria-label') || ''} ${el.getAttribute?.('title') || ''}`;
    if (DANGER_RE.test(d)) return true;
    if (el.matches?.('input[type="submit"],button[type="submit"],[formaction]')) return true;
    if (el instanceof HTMLButtonElement && el.form && (!el.getAttribute('type') || el.type === 'submit')) return true;
    if (el.closest?.('form') || el.closest?.('a[download]')) return true;
    if (/(?:window\.)?location(?:\.href)?\s*=|location\.(?:assign|replace)\s*\(|window\.open\s*\(/i.test(el.getAttribute?.('onclick') || '')) return true;
    return false;
  };
  const descriptor = el => `${el.innerText || el.textContent || ''} ${el.getAttribute?.('aria-label') || ''} ${el.getAttribute?.('title') || ''} ${el.id || ''} ${typeof el.className === 'string' ? el.className : ''}`.replace(/\s+/g, ' ').trim();
  const LOAD_MORE_RE = /(?:load|show|view|see)\s+more|se\s+flere|vis\s+flere|indlæs\s+flere|hent\s+flere|flere\s+(?:kommentarer|resultater|artikler|svar|nyheder|indlæg)|vis\s+mere|mehr\s+(?:anzeigen|laden)|visa\s+fler/i;
  const classifyControl = el => {
    const d = descriptor(el);
    const txt = (el.innerText || el.textContent || '').trim();
    if (LOAD_MORE_RE.test(d)) return 'load-more';
    const pager = el.closest?.('[class*="pagination" i],[class*="pager" i],[aria-label*="pagination" i],[aria-label*="paginering" i],nav[aria-label*="page" i],nav[aria-label*="side" i]');
    if (/^(?:next|previous|næste|forrige|mere|more|›|»)$/i.test(txt) || /(?:pagination|paginering|pager|next[-_ ]?page|prev(?:ious)?[-_ ]?page|næste\s+side|forrige\s+side)/i.test(d) || (/^\d{1,4}$/.test(txt) && pager)) return 'pagination';
    if (el.getAttribute?.('role') === 'tab' || el.closest?.('[role="tablist"]')) return 'tab';
    if (el.tagName === 'SUMMARY' || /accordion|disclosure|expand|collapse|fold/i.test(d) || el.hasAttribute?.('aria-expanded')) return 'accordion';
    return '';
  };
  const blockedAnchor = a => {
    if (!a) return false;
    const href = (a.getAttribute?.('href') || '').trim();
    return a.hasAttribute?.('download') || /^(?:blob:|data:|file:)/i.test(href) || /\.(?:pdf|docx?|xlsx?|pptx?|zip|rar|7z|csv|exe|msi|dmg|apk)(?:$|[?#])/i.test(href);
  };
  // DOM-level guards (the authoritative network guard runs in the service worker via CDP).
  const guards = () => {
    const onSubmit = e => { e.preventDefault(); e.stopImmediatePropagation(); };
    const onClick = e => { const a = e.target?.closest?.('a'); if (blockedAnchor(a) || (a && a.target === '_blank')) { e.preventDefault(); e.stopImmediatePropagation(); } };
    document.addEventListener('submit', onSubmit, true);
    document.addEventListener('click', onClick, true);
    return () => { document.removeEventListener('submit', onSubmit, true); document.removeEventListener('click', onClick, true); };
  };

  const CHALLENGE_PHRASES = /\b(?:just a moment\.{0,3}|checking your browser|verify(?:ing)? you are (?:a )?human|attention required|access denied|request unsuccessful|are you a robot|bekræft at du er et menneske|adgang nægtet)\b/i;

  function shadowScan() {
    let roots = 0;
    const links = new Set();
    const walk = (root, depth) => {
      if (depth > 6 || roots > 400) return;
      const tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      for (let n = tw.currentNode; n; n = tw.nextNode()) {
        if (n.shadowRoot) {
          roots++;
          for (const a of n.shadowRoot.querySelectorAll('a[href]')) { const u = norm(a.getAttribute('href')); if (u) links.add(u); }
          walk(n.shadowRoot, depth + 1);
        }
      }
    };
    try { walk(document.documentElement, 0); } catch {}
    return { roots, links: [...links].slice(0, 500) };
  }

  function scrollLocked() {
    try {
      const h = getComputedStyle(document.documentElement), b = getComputedStyle(document.body);
      const locked = /hidden|clip/.test(h.overflowY) || /hidden|clip/.test(b.overflowY);
      const docTall = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) > innerHeight + 200;
      return locked && docTall && !findInnerScroller();
    } catch { return false; }
  }

  function findInnerScroller() {
    let best = null, bestArea = 0;
    for (const el of document.querySelectorAll('main, [role="main"], div, section, article')) {
      if (el.scrollHeight <= el.clientHeight + 200) continue;
      const st = getComputedStyle(el);
      if (!/(auto|scroll|overlay)/.test(st.overflowY)) continue;
      const r = el.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea && r.width >= innerWidth * 0.5 && r.height >= innerHeight * 0.5) { best = el; bestArea = area; }
    }
    return best;
  }

  function snapshot({ withTextSample = false } = {}) {
    const links = docLinks();
    const bodyText = document.body?.innerText || '';
    const imgs = [...document.images];
    const shadow = shadowScan();
    const frameworks = [];
    if (document.getElementById('__NEXT_DATA__') || document.querySelector('script[src*="/_next/"]')) frameworks.push('Next.js');
    if (document.getElementById('__nuxt') || document.querySelector('script[src*="/_nuxt/"]')) frameworks.push('Nuxt');
    if (document.querySelector('[ng-version]')) frameworks.push('Angular');
    if (document.querySelector('[data-reactroot], #root[data-reactroot], [data-react-helmet]')) frameworks.push('React');
    if (document.querySelector('[data-v-app]') || /\sdata-v-[0-9a-f]{6,}/i.test(document.body?.outerHTML?.slice(0, 200000) || '')) frameworks.push('Vue');
    const clickish = [...document.querySelectorAll('button,[role="button"],a')].slice(0, 3000);
    return {
      url: location.href,
      title: document.title,
      documentLanguage: (document.documentElement?.getAttribute('lang') || '').trim(),
      metaContentLanguage: (document.querySelector('meta[http-equiv="content-language" i]')?.getAttribute('content') || '').trim(),
      ogLocale: (document.querySelector('meta[property="og:locale" i]')?.getAttribute('content') || '').trim(),
      textSample: withTextSample ? bodyText.replace(/\s+/g, ' ').slice(0, 12000) : undefined,
      textLength: bodyText.length,
      linkCount: links.size,
      links: [...links].slice(0, 3000),
      elementCount: document.getElementsByTagName('*').length,
      height: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0),
      shadowRootCount: shadow.roots,
      shadowLinks: shadow.links,
      frameworks,
      lazyDataOnly: imgs.filter(img => (img.dataset.src || img.dataset.lazySrc || img.dataset.original) && !img.getAttribute('src')).length,
      iframeCount: document.querySelectorAll('iframe').length,
      crossOriginIframes: [...document.querySelectorAll('iframe[src]')].filter(f => { try { return new URL(f.src, location.href).origin !== location.origin; } catch { return false; } }).length,
      mediaElements: document.querySelectorAll('video,audio').length,
      mediaBlobSources: [...document.querySelectorAll('video,audio')].filter(m => /^(?:blob|mediasource):/i.test(m.currentSrc || m.src || '')).length,
      loadMoreControls: clickish.filter(el => LOAD_MORE_RE.test((el.innerText || el.textContent || '').trim())).length,
      challenge: bodyText.trim().length < 3000 && CHALLENGE_PHRASES.test(`${document.title} ${bodyText.slice(0, 6000)}`),
      scrollLocked: scrollLocked(),
      jsonLd: document.querySelectorAll('script[type="application/ld+json"]').length,
    };
  }

  /**
   * @param {{menu?: boolean}} [opts]  menu: count content inside fixed/sticky overlays too (off-canvas and
   *   dropdown menus live there); consent and ad containers stay excluded.
   */
  function startPhase(opts = {}) {
    if (state.observer) try { state.observer.disconnect(); } catch {}
    state.phaseMenu = !!opts?.menu;
    state.roots = [];
    state.linksBefore = docLinks();
    state.phaseStarted = performance.now();
    state.observer = new MutationObserver(ms => {
      for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1 && state.roots.length < 20000) state.roots.push(n);
    });
    state.observer.observe(document.documentElement, { childList: true, subtree: true });
    return { url: location.href };
  }

  function excludedFromPhase(n) {
    return state.phaseMenu ? (inConsent(n) || adLike(n)) : (inOverlay(n) || adLike(n));
  }

  function endPhase() {
    try { state.observer?.disconnect(); } catch {}
    state.observer = null;
    // Net-new content only: roots still in the document, de-duplicated (nested roots are counted once).
    const alive = state.roots.filter(n => n.isConnected);
    const set = new Set(alive);
    const top = alive.filter(n => { for (let p = n.parentElement; p; p = p.parentElement) if (set.has(p)) return false; return true; });
    let netElements = 0, overlayElements = 0, text = 0;
    const newLinks = new Set();
    const before = state.linksBefore || new Set();
    for (const root of top) {
      const size = 1 + (root.getElementsByTagName ? root.getElementsByTagName('*').length : 0);
      if (excludedFromPhase(root)) { overlayElements += size; continue; }
      netElements += size;
      try { text += (root.innerText || root.textContent || '').trim().length; } catch {}
      const anchors = root.matches?.('a[href]') ? [root] : [];
      for (const a of [...anchors, ...(root.querySelectorAll?.('a[href]') || [])]) {
        if (adLike(a)) continue;
        const u = norm(a.getAttribute('href'));
        if (u && !before.has(u)) newLinks.add(u);
      }
      if (netElements > 50000) break;
    }
    // Links that appeared through attribute changes (e.g. href filled in later) outside overlays.
    for (const a of document.querySelectorAll('a[href]')) {
      const u = norm(a.getAttribute('href'));
      if (u && !before.has(u) && !newLinks.has(u) && !excludedFromPhase(a)) newLinks.add(u);
      if (newLinks.size > 2000) break;
    }
    return {
      durationMs: Math.round(performance.now() - state.phaseStarted),
      netElements, overlayElements, text: Math.min(text, 200000),
      newLinks: [...newLinks].slice(0, 1500),
      url: location.href,
    };
  }

  async function scroll(opts) {
    const inner = (document.documentElement.scrollHeight <= innerHeight + 50 || scrollLocked()) ? findInnerScroller() : null;
    const scroller = inner || document.scrollingElement || document.documentElement;
    const metrics = () => ({ height: scroller.scrollHeight, links: document.links.length, elements: document.getElementsByTagName('*').length, text: (document.body?.textContent || '').length });
    const started = performance.now();
    let steps = 0, bottomLoads = 0, stable = 0, reachedStableBottom = false, safetyStop = false;
    let last = metrics();
    const origTop = scroller.scrollTop;
    scroller.scrollTop = 0;
    await wait(150);
    while (steps < opts.maxSteps && performance.now() - started < opts.maxMs) {
      steps++;
      const view = inner ? inner.clientHeight : Math.max(innerHeight, 600);
      const maxY = Math.max(0, scroller.scrollHeight - view);
      const cur = scroller.scrollTop;
      const next = Math.min(maxY, cur + Math.max(700, Math.floor(view * 0.9)));
      if (next > cur + 20) {
        scroller.scrollTop = next;
        if (!inner) window.dispatchEvent(new Event('scroll'));
        await wait(220);
        continue;
      }
      await wait(800);
      const snap = metrics();
      const grew = snap.height > last.height + 80 || snap.links > last.links + 1 || snap.elements > last.elements + 8 || snap.text > last.text + 300;
      last = snap;
      if (grew) {
        bottomLoads++; stable = 0;
        if (bottomLoads >= opts.maxBottomLoads) { safetyStop = true; break; }
        continue;
      }
      if (++stable >= opts.stableBottomRounds) { reachedStableBottom = true; break; }
    }
    if (!reachedStableBottom && !safetyStop) safetyStop = true;
    const finalHeight = scroller.scrollHeight;
    scroller.scrollTop = origTop;
    return { steps, bottomLoads, reachedStableBottom, safetyStop, scroller: inner ? 'inner-container' : 'document', elapsedMs: Math.round(performance.now() - started), finalHeight };
  }

  const cssEscape = v => (globalThis.CSS?.escape ? CSS.escape(v) : String(v).replace(/[^\w-]/g, '\\$&'));
  // Short, reasonably stable selector for crawler config hints (Browsertrix clickSelector).
  const selectorFor = el => {
    if (el.id && !/\d{4,}/.test(el.id)) return `#${cssEscape(el.id)}`;
    for (const attr of ['data-testid', 'data-test', 'data-action', 'aria-label']) {
      const v = el.getAttribute?.(attr);
      if (v && v.length < 60) return `${el.tagName.toLowerCase()}[${attr}=${JSON.stringify(v)}]`;
    }
    const classes = (typeof el.className === 'string' ? el.className : '').split(/\s+/).filter(c => c && !/\d{3,}|^(?:is|has)-|active|open|hover/.test(c)).slice(0, 2);
    return el.tagName.toLowerCase() + classes.map(c => `.${cssEscape(c)}`).join('');
  };

  // ---- Browsertrix autofetch emulation (v1.10): srcset / data-src URLs ----
  // Mirrors browsertrix-behaviors src/autofetcher.ts: same selector (images, picture/video/audio
  // sources, noscript images, also inside open shadow roots), data-src, every srcset and data-srcset
  // candidate (split with the autofetcher's own regex), and src when a srcset exists or inside <noscript>.
  const AUTOFETCH_SELECTOR = "img[srcset], img[data-srcset], img[data-src], noscript > img[src], img[loading='lazy'], "
    + 'video[srcset], video[data-srcset], video[data-src], audio[srcset], audio[data-srcset], audio[data-src], '
    + 'picture > source[srcset], picture > source[data-srcset], picture > source[data-src], '
    + 'video > source[srcset], video > source[data-srcset], video > source[data-src], '
    + 'audio > source[srcset], audio > source[data-srcset], audio > source[data-src]';
  const AUTOFETCH_SRCSET_RE = /\s*(\S*\s+[\d.]+[wx]),|(?:\s*,(?:\s+|(?=https?:)))/;

  function autofetchUrls(max = 3000) {
    const out = new Set();
    const queue = u => {
      if (!u || out.size >= max) return;
      try { const abs = new URL(u, document.baseURI); if (/^https?:$/.test(abs.protocol)) { abs.hash = ''; out.add(abs.href); } } catch {}
    };
    const srcsetAttr = v => { for (const part of String(v).split(AUTOFETCH_SRCSET_RE)) if (part) queue(part.trim().split(' ')[0]); };
    const roots = [document];
    for (let i = 0; i < roots.length && i < 200; i++) {
      let els = [];
      try { els = roots[i].querySelectorAll(AUTOFETCH_SELECTOR); } catch {}
      for (const el of els) {
        queue(el.getAttribute('data-src'));
        const srcset = el.getAttribute('srcset'), dataSrcset = el.getAttribute('data-srcset');
        if (srcset) srcsetAttr(srcset);
        if (dataSrcset) srcsetAttr(dataSrcset);
        const src = el.getAttribute('src');
        if (src && (srcset || dataSrcset || el.parentElement?.tagName === 'NOSCRIPT')) queue(src);
      }
      try { for (const host of roots[i].querySelectorAll('*')) if (host.shadowRoot) roots.push(host.shadowRoot); } catch {}
    }
    return [...out];
  }

  // ---- Menus (v1.7.3): burger / off-canvas toggles and navigation dropdowns ----
  const MENU_WORD_RE = /(?:^|[\s_:-])(?:menu|menuen|meny|menü|valikko|hamburger|burger|navigation|navigering|hovedmenu|main[-_ ]?menu|site[-_ ]?menu|mobile[-_ ]?(?:menu|nav)|nav[-_ ]?(?:toggle|toggler|trigger|button|open)|navbar[-_ ]?toggler|menu[-_ ]?(?:toggle|button|trigger|open|icon)|off-?canvas|side-?nav|drawer|åbn menu|vis menu|open menu|show menu|toggle navigation|alle sektioner|all sections)(?:$|[\s_:-])/i;
  const MENU_SKIP_RE = /(?:search|søg|sök|suche|haku|recherche|sprog|language|sprache|språk|kurv|cart|basket|konto|account|profil|login|log ind)/i;
  const MENU_CANDIDATES = 'button,[role="button"],summary,[aria-haspopup],[aria-expanded],[aria-controls],label[for],a[href="#"],a:not([href]),a[href^="javascript:"]';
  const SUBMENU_ITEMS = 'button,[role="button"],[role="menuitem"],[role="tab"],summary,[aria-haspopup],[aria-expanded],a[href="#"],a:not([href])';
  const NAV_LIKE = 'nav,header,[role="navigation"],[role="menubar"],[role="banner"],[class*="nav" i],[id*="nav" i],[class*="menu" i],[id*="menu" i],[class*="header" i]';

  const iconOnly = el => !(el.innerText || el.textContent || '').trim() && !!el.querySelector?.('svg,img,i,span');

  /** 'burger' | 'dropdown' | '' — never for links that navigate, risky wording, search/cart/account/language toggles. */
  function menuTriggerType(el) {
    try {
      if (normalHref(el) || dangerous(el) || el.disabled || el.getAttribute?.('aria-disabled') === 'true') return '';
      const d = descriptor(el);
      if (MENU_SKIP_RE.test(d)) return '';
      if (el.tagName === 'LABEL') {
        const input = document.getElementById(el.getAttribute('for') || '');
        if (!input || input.type !== 'checkbox' || !MENU_WORD_RE.test(`${d} ${input.id} ${input.className || ''}`)) return '';
        return 'burger'; // CSS-only "checkbox hack" menu
      }
      const controls = el.getAttribute('aria-controls');
      const target = controls ? document.getElementById(controls) : null;
      const targetIsMenu = !!target && (target.matches('nav,[role="navigation"],[role="menu"],[role="dialog"]') || /nav|menu|drawer|off-?canvas|sidebar/i.test(`${target.id} ${typeof target.className === 'string' ? target.className : ''}`));
      const navLike = !!el.closest?.(NAV_LIKE);
      if (MENU_WORD_RE.test(d) || targetIsMenu || (iconOnly(el) && navLike && (el.hasAttribute('aria-expanded') || controls))) return 'burger';
      const popup = el.getAttribute('aria-haspopup');
      if (navLike && (popup === 'true' || popup === 'menu' || el.hasAttribute('aria-expanded') || el.tagName === 'SUMMARY')) return 'dropdown';
    } catch {}
    return '';
  }

  /** Up to `max` triggers: one burger first, then dropdowns from different menus, then the rest. */
  function findMenuTriggers(max = 2) {
    state.menuTriggers = [];
    const seen = new Set();
    const burgers = [], dropdowns = [];
    for (const el of document.querySelectorAll(MENU_CANDIDATES)) {
      if (burgers.length + dropdowns.length >= 40) break;
      if (!visible(el) || adLike(el) || inConsent(el)) continue;
      const type = menuTriggerType(el);
      if (!type) continue;
      const key = el.getAttribute('aria-controls') || selectorFor(el) + '|' + descriptor(el).slice(0, 40);
      if (seen.has(key)) continue;
      seen.add(key);
      (type === 'burger' ? burgers : dropdowns).push({ el, type });
    }
    const picked = [];
    if (burgers[0]) picked.push(burgers[0]);
    const parents = new Set();
    for (const d of dropdowns) {
      if (picked.length >= max) break;
      const parent = d.el.closest('ul,nav,[role="menubar"]') || d.el.parentElement;
      if (parents.has(parent)) continue;
      parents.add(parent);
      picked.push(d);
    }
    for (const x of [...dropdowns, ...burgers.slice(1)]) {
      if (picked.length >= max) break;
      if (!picked.includes(x)) picked.push(x);
    }
    return picked.slice(0, max).map(({ el, type }) => {
      state.menuTriggers.push(el);
      return { i: state.menuTriggers.length - 1, type, label: descriptor(el).slice(0, 80), selector: selectorFor(el) };
    });
  }

  const isSubmenuItem = it => it.hasAttribute('aria-expanded') || it.hasAttribute('aria-haspopup') || it.tagName === 'SUMMARY'
    || it.getAttribute('role') === 'menuitem' || it.getAttribute('role') === 'tab'
    || /sub-?menu|dropdown|expand|toggle|caret|chevron|arrow|mega|accordion|undermenu/i.test(descriptor(it));

  /** Opens a trigger; afterwards lists submenu controls that only became visible because of it. */
  async function openMenu(i, settleMs) {
    const el = state.menuTriggers[i];
    state.menuItems = [];
    if (!el?.isConnected) return { clicked: false };
    const visibleBefore = new Set([...document.querySelectorAll(SUBMENU_ITEMS)].filter(visible));
    const restore = guards();
    try {
      el.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
      await wait(80);
      el.click();
      await wait(settleMs);
    } catch {} finally { restore(); }
    const items = [];
    for (const it of document.querySelectorAll(SUBMENU_ITEMS)) {
      if (items.length >= 12) break;
      if (it === el || visibleBefore.has(it) || !visible(it) || normalHref(it) || dangerous(it) || it.disabled
        || adLike(it) || inConsent(it) || MENU_SKIP_RE.test(descriptor(it)) || !isSubmenuItem(it)) continue;
      items.push(it);
    }
    state.menuItems = items;
    return {
      clicked: true, url: location.href, expanded: el.getAttribute('aria-expanded') || '',
      items: items.slice(0, 6).map((it, j) => ({ i: j, label: descriptor(it).slice(0, 80), selector: selectorFor(it) })),
    };
  }

  async function clickMenuItem(j, settleMs) {
    const it = state.menuItems[j];
    if (!it?.isConnected || !visible(it)) return { clicked: false };
    const restore = guards();
    try { it.click(); await wait(settleMs); } catch {} finally { restore(); }
    return { clicked: true, url: location.href };
  }

  /** Best effort: Escape, then the toggle again if it still reports expanded. */
  async function closeMenu(i) {
    const el = state.menuTriggers[i];
    try {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
      await wait(150);
      if (el?.isConnected && visible(el) && el.getAttribute('aria-expanded') === 'true') {
        const restore = guards();
        try { el.click(); } finally { restore(); }
      }
      await wait(250);
    } catch {}
    state.menuItems = [];
    return { closed: true };
  }

  function findControls(max = 5) {
    state.candidates = [];
    const byType = new Map();
    const all = document.querySelectorAll('button,[role="button"],[role="tab"],summary,[aria-expanded],[aria-haspopup],input[type="button"],a');
    for (const el of all) {
      if (byType.size >= 5) break;
      if (!visible(el) || normalHref(el) || dangerous(el) || el.disabled || el.getAttribute?.('aria-disabled') === 'true' || inOverlay(el) || adLike(el)) continue;
      if (menuTriggerType(el)) continue; // menus are tested in their own phase (see findMenuTriggers)
      const type = classifyControl(el);
      if (!type || byType.has(type)) continue;
      byType.set(type, el);
    }
    const out = [];
    for (const type of ['load-more', 'pagination', 'tab', 'accordion']) {
      const el = byType.get(type);
      if (!el || out.length >= max) continue;
      state.candidates.push(el);
      out.push({ i: state.candidates.length - 1, type, label: descriptor(el).slice(0, 80), selector: selectorFor(el) });
    }
    return out;
  }

  async function click(i, settleMs) {
    const el = state.candidates[i];
    if (!el?.isConnected) return { clicked: false };
    const restore = guards();
    try {
      el.scrollIntoView?.({ block: 'center', inline: 'nearest' });
      await wait(120);
      el.click();
      await wait(settleMs);
    } catch {} finally { restore(); }
    return { clicked: true, url: location.href };
  }

  async function media(opts) {
    let playbackAttempted = 0, playbackStarted = 0;
    const original = new Map();
    const mute = m => { if (!m || original.has(m)) return; original.set(m, { muted: m.muted, volume: m.volume, paused: m.paused }); try { m.muted = true; m.volume = 0; } catch {} };
    const list = [...document.querySelectorAll('video,audio')].slice(0, opts.maxElements || 2);
    list.forEach(mute);
    const mo = new MutationObserver(ms => { for (const m of ms) for (const n of m.addedNodes) { if (n.nodeType !== 1) continue; if (n.matches?.('video,audio')) mute(n); n.querySelectorAll?.('video,audio').forEach(mute); } });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    const restore = guards();
    try {
      for (const m of list) {
        playbackAttempted++;
        try { const p = m.play?.(); if (p?.then) await Promise.race([p.catch(() => {}), wait(800)]); await wait(250); if (!m.paused) playbackStarted++; } catch {}
      }
      if (!playbackStarted) {
        const btn = [...document.querySelectorAll('button,[role="button"],[aria-label],[title]')].find(el => {
          if (!visible(el) || normalHref(el) || dangerous(el) || el.disabled) return false;
          if (!/(?:^|\b)(?:play|play video|play audio|start video|listen|afspil|lyt|abspielen)(?:\b|$)/i.test(descriptor(el))) return false;
          return !!el.closest?.('[class*="player" i],[id*="player" i],[class*="video" i],[id*="video" i],[class*="audio" i],[data-player],figure');
        });
        if (btn) {
          playbackAttempted++;
          try { btn.click(); } catch {}
          await wait(400);
          for (const m of document.querySelectorAll('video,audio')) { mute(m); if (!m.paused) playbackStarted++; }
        }
      }
      if (playbackAttempted) await wait(opts.playbackMs || 2500);
    } finally {
      restore();
      mo.disconnect();
      for (const [m, s] of original) { try { if (s.paused && !m.paused) m.pause(); m.muted = s.muted; m.volume = s.volume; } catch {} }
    }
    return { playbackAttempted, playbackStarted };
  }

  // ---- Page-flipper / document-viewer probe (runs in every frame) ----
  const viewerRe = /(?:catalog|catalogue|katalog|tilbudsavis|publication|publikation|leaflet|brochure|magazine|flip(?:book|per)?|page[-_ ]?flip|page[-_ ]?turn|document[-_ ]?viewer|pdf[-_ ]?viewer|reader|spread|digital[-_ ]?edition)/i;
  const nextRe = /(?:^|[-_\s])(next|næste|forward|frem|right|page[-_ ]?next|next[-_ ]?page|next[-_ ]?slide|arrow[-_ ]?right|chevron[-_ ]?right|caret[-_ ]?right|flip[-_ ]?next|›|»)(?:$|[-_\s])/i;
  const prevRe = /(?:^|[-_\s])(prev|previous|forrige|back|left|arrow[-_ ]?left|chevron[-_ ]?left|caret[-_ ]?left|‹|«)(?:$|[-_\s])/i;
  const attrText = el => {
    const svg = el.querySelector?.('svg'), use = svg?.querySelector?.('use');
    return [descriptor(el), el.getAttribute?.('name') || '', el.getAttribute?.('data-testid') || '', svg?.getAttribute?.('data-icon') || '', use?.getAttribute?.('href') || use?.getAttribute?.('xlink:href') || ''].join(' ');
  };
  const imageSet = () => {
    const out = new Set();
    for (const img of document.images) for (const v of [img.currentSrc, img.src]) { const u = norm(v || ''); if (u) out.add(u); }
    return out;
  };
  const canvasFp = () => [...document.querySelectorAll('canvas')].slice(0, 4).map(c => {
    try {
      const ctx = c.getContext('2d', { willReadFrequently: true });
      if (!ctx || !c.width || !c.height) return `${c.width}x${c.height}:na`;
      let h = 2166136261;
      for (const [px, py] of [[.2, .2], [.5, .5], [.8, .8], [.2, .8], [.8, .2]]) {
        const d = ctx.getImageData(Math.min(c.width - 1, Math.floor(c.width * px)), Math.min(c.height - 1, Math.floor(c.height * py)), 1, 1).data;
        for (const b of d) { h ^= b; h = Math.imul(h, 16777619); }
      }
      return `${c.width}x${c.height}:${h >>> 0}`;
    } catch { return `${c.width}x${c.height}:tainted`; }
  }).join('|');

  function viewerFind() {
    state.viewer = null;
    const descriptorDoc = `${location.href} ${document.title || ''} ${document.body?.className || ''}`;
    const containers = [...document.querySelectorAll('[class*="viewer" i],[id*="viewer" i],[class*="flip" i],[id*="flip" i],[class*="catalog" i],[class*="katalog" i],[class*="publication" i],[class*="reader" i],[class*="leaflet" i],[class*="magazine" i]')].filter(visible);
    const canvases = document.querySelectorAll('canvas').length;
    const viewerish = viewerRe.test(descriptorDoc) || containers.length > 0 || (canvases > 0 && document.querySelectorAll('button,[role="button"]').length >= 2);
    if (!viewerish) return { frameUrl: location.href, viewerish: false, hasCandidate: false };
    const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],[tabindex]:not(a)')]
      .filter(el => visible(el) && !normalHref(el) && !dangerous(el) && !el.disabled && el.getAttribute?.('aria-disabled') !== 'true');
    let candidate = controls.find(el => nextRe.test(` ${attrText(el)} `) && !prevRe.test(` ${attrText(el)} `));
    const explicitNext = !!candidate;
    const scope = containers[0] || document.documentElement;
    const sr = scope.getBoundingClientRect();
    const scoped = controls.filter(el => scope === document.documentElement || scope.contains(el)).map(el => ({ el, r: el.getBoundingClientRect(), d: attrText(el) }));
    const mid = x => x.r.top + x.r.height / 2 > sr.top + sr.height * .12 && x.r.top + x.r.height / 2 < sr.top + sr.height * .88;
    const left = scoped.some(x => mid(x) && x.r.left + x.r.width / 2 < sr.left + sr.width * .35);
    const right = scoped.some(x => mid(x) && x.r.left + x.r.width / 2 > sr.left + sr.width * .65);
    const structural = containers.length > 0 || canvases > 0 || (left && right);
    if (!candidate && structural) {
      candidate = scoped.filter(x => mid(x) && x.r.left + x.r.width / 2 > sr.left + sr.width * .62 && !prevRe.test(` ${x.d} `))
        .sort((a, b) => (b.r.left + b.r.width / 2) - (a.r.left + a.r.width / 2))[0]?.el || null;
    }
    if (!candidate) return { frameUrl: location.href, viewerish, structural, hasCandidate: false };
    state.viewer = { el: candidate, explicitNext, structural, viewerish };
    return { frameUrl: location.href, viewerish, structural, explicitNext, hasCandidate: true };
  }

  async function viewerClick(settleMs) {
    const v = state.viewer;
    if (!v?.el?.isConnected) return { tested: false };
    const beforeImages = imageSet(), beforeFp = canvasFp(), beforeUrl = location.href;
    let addedElements = 0, changedImageAttrs = 0, changedStyleAttrs = 0;
    const mo = new MutationObserver(ms => {
      for (const m of ms) {
        if (m.type === 'childList') for (const n of m.addedNodes) if (n.nodeType === 1) addedElements++;
        if (m.type === 'attributes') {
          if (m.target?.tagName === 'IMG' && (m.attributeName === 'src' || m.attributeName === 'srcset')) changedImageAttrs++;
          if (m.attributeName === 'style') changedStyleAttrs++;
        }
      }
    });
    mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'srcset', 'style'] });
    const restore = guards();
    try { v.el.scrollIntoView?.({ block: 'center' }); await wait(100); v.el.click(); await wait(settleMs); } catch {} finally { restore(); mo.disconnect(); }
    const afterFp = canvasFp();
    const newImages = [...imageSet()].filter(u => !beforeImages.has(u));
    const canvasChanged = !!beforeFp && beforeFp !== afterFp && !/tainted/.test(beforeFp + afterFp);
    const routeChanged = location.href !== beforeUrl;
    const visualChanged = newImages.length > 0 || changedImageAttrs > 0 || canvasChanged || changedStyleAttrs >= 2 || addedElements >= 2;
    return { tested: true, frameUrl: location.href, viewerish: v.viewerish, structural: v.structural, explicitNext: v.explicitNext, newImages: newImages.slice(0, 8), changedImageAttrs, canvasChanged, routeChanged, visualChanged, addedElements };
  }

  // Consent banners are handled by probe/consent.js (all frames) since v1.7.
  globalThis.__ccProbe = { snapshot, startPhase, endPhase, scroll, findControls, click, findMenuTriggers, openMenu, clickMenuItem, closeMenu, autofetchUrls, media, viewerFind, viewerClick, version: '1.10.0' };
})();
