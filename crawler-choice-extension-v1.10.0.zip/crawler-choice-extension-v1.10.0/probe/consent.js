// Consent-banner handling for test tabs (v1.7). Injected into EVERY frame in the ISOLATED world, so
// it also reaches CMPs that render in cross-origin iframes (e.g. Sourcepoint) and page scripts cannot
// tamper with it. The service worker drives it in rounds (see background.js handleConsent()).
//
// Method — modelled on "I don't care about cookies" / "I still don't care about cookies" (rule-based
// clicking + CSS hiding + scroll unlocking, retried while the page loads) and on Consent-O-Matic /
// DuckDuckGo autoconsent (per-CMP detectors: "is it present", "is it showing", then a click action):
//   1. CMP rules: known consent platforms, weighted towards those common on Danish and other European
//      sites (Cookiebot, Cookie Information, OneTrust, Usercentrics, Didomi, Sourcepoint, …). Each rule
//      names the banner root(s) and the accept / reject buttons; open shadow roots are searched.
//   2. Wording heuristic: visible containers that talk about cookies/consent, and buttons whose label
//      exactly matches an accept / reject phrase in Danish, Norwegian, Swedish, English, German, Dutch,
//      French, Finnish, Spanish, Italian, Polish or Icelandic.
//   3. Cosmetic fallback ("accept" mode only, as in IDCAC): if a banner is still visible or the page is
//      still scroll-locked, the identified banner, its backdrop and the scroll lock are removed.
// Deliberately NOT copied from IDCAC: the broad generic CSS list (it also hides real page content and
// would corrupt the text/link measurements), blocking CMP scripts (changes what the page does) and
// per-site cookie/localStorage seeding. No rule data from those projects is included; all rules here
// are written for this extension. Rules are best-effort: a stale selector simply does not match and
// the wording heuristic takes over.

(() => {
  if (globalThis.__ccConsent) return;

  // ------------------------------------------------------------------------------------------------
  // 1. CMP rules. root: banner container(s). accept / reject: buttons searched inside the root (and its
  // open shadow root). open: second-layer "settings" button used only when no reject button exists.
  // backdrop: overlay to remove in the cosmetic fallback. lockClasses: html/body classes that lock scroll.
  // ------------------------------------------------------------------------------------------------
  const CMP_RULES = [
    { id: 'cookiebot', root: '#CybotCookiebotDialog, #CookiebotWidget:not(.CookiebotWidget-inactive)',
      accept: '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll, #CybotCookiebotDialogBodyButtonAccept, #CybotCookiebotDialogBodyLevelButtonAccept',
      reject: '#CybotCookiebotDialogBodyButtonDecline, #CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll, #CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection',
      backdrop: '#CybotCookiebotDialogBodyUnderlay, .CybotCookiebotDialogActive + div' },
    { id: 'cookie-information', root: '#coiOverlay, #cookie-information-template-wrapper, .coi-banner__wrapper',
      accept: '.coi-banner__accept, button[onclick*="submitAllCategories"], #coiPage-1 .coi-banner__accept',
      reject: '#declineButton, .coi-banner__decline, button[onclick*="declineAllCategories"], button[onclick*="submitNecessary"]',
      open: '.coi-banner__settings, button[onclick*="changeLayer"]', backdrop: '#coiOverlay', lockClasses: ['noScroll', 'coi-overflow-hidden'] },
    { id: 'onetrust', root: '#onetrust-banner-sdk, #onetrust-pc-sdk',
      accept: '#onetrust-accept-btn-handler, #accept-recommended-btn-handler, .onetrust-close-btn-handler.banner-close-button',
      reject: '#onetrust-reject-all-handler, .ot-pc-refuse-all-handler, .save-preference-btn-handler',
      open: '#onetrust-pc-btn-handler', backdrop: '.onetrust-pc-dark-filter' },
    { id: 'usercentrics', root: '#usercentrics-root, #usercentrics-cmp-ui, aside#usercentrics-cmp-ui', shadow: true,
      accept: '[data-testid="uc-accept-all-button"], #accept', reject: '[data-testid="uc-deny-all-button"], #deny',
      open: '[data-testid="uc-more-button"]' },
    { id: 'didomi', root: '#didomi-host #didomi-notice, #didomi-popup, #didomi-notice',
      accept: '#didomi-notice-agree-button, #didomi-popup .didomi-button-highlight',
      reject: '#didomi-notice-disagree-button, .didomi-continue-without-agreeing, #btn-toggle-disagree',
      open: '#didomi-notice-learn-more-button', backdrop: '.didomi-popup-backdrop', lockClasses: ['didomi-popup-open'] },
    // Sourcepoint: the top frame holds an iframe container; the buttons live inside the iframe.
    { id: 'sourcepoint-host', root: 'div[id^="sp_message_container_"]', lockClasses: ['sp-message-open'] },
    { id: 'sourcepoint', root: '.message-container, #notice.message, .message.type-modal, .message.type-bottom',
      requireMarker: 'button[class*="sp_choice_type_"]',
      accept: 'button.sp_choice_type_11, button.sp_choice_type_ACCEPT_ALL', reject: 'button.sp_choice_type_13, button.sp_choice_type_REJECT_ALL' },
    { id: 'quantcast', root: '#qc-cmp2-container .qc-cmp2-summary-section, #qc-cmp2-ui, .qc-cmp2-container',
      accept: '.qc-cmp2-summary-buttons button[mode="primary"], #qc-cmp2-ui button[mode="primary"]',
      reject: '.qc-cmp2-summary-buttons button[mode="secondary"]' },
    { id: 'consentmanager', root: '#cmpbox, #cmpwrapper', shadow: true,
      accept: '.cmpboxbtnyes, a.cmpboxbtn.cmpboxbtnyes', reject: '.cmpboxbtnno, a.cmpboxbtn.cmpboxbtnno, .cmpboxbtnreject', backdrop: '#cmpbox2' },
    { id: 'google-fc', root: '.fc-consent-root, .fc-dialog-container',
      accept: '.fc-cta-consent, .fc-button.fc-cta-consent', reject: '.fc-cta-do-not-consent' },
    { id: 'cookieyes', root: '.cky-consent-container:not(.cky-hide), .cky-modal.cky-modal-open',
      accept: '.cky-btn-accept', reject: '.cky-btn-reject', backdrop: '.cky-overlay' },
    { id: 'complianz', root: '.cmplz-cookiebanner:not(.cmplz-hidden)', accept: '.cmplz-accept', reject: '.cmplz-deny' },
    { id: 'borlabs', root: '#BorlabsCookieBox, .brlbs-cmpnt-container',
      accept: 'a[data-cookie-accept-all], .brlbs-btn-accept-all, #CookieBoxSaveButton',
      reject: 'a[data-cookie-refuse], .brlbs-btn-accept-only-essential, a._brlbs-refuse-btn' },
    { id: 'cookie-script', root: '#cookiescript_injected, #cookiescript_injected_wrapper', accept: '#cookiescript_accept', reject: '#cookiescript_reject' },
    { id: 'iubenda', root: '#iubenda-cs-banner', accept: '.iubenda-cs-accept-btn', reject: '.iubenda-cs-reject-btn' },
    { id: 'klaro', root: '.klaro .cookie-notice, .klaro .cookie-modal', accept: '.cm-btn-accept-all, .cm-btn-success', reject: '.cm-btn-decline' },
    { id: 'cookiefirst', root: '.cookiefirst-root, [data-cookiefirst-widget]', accept: '[data-cookiefirst-action="accept"]', reject: '[data-cookiefirst-action="reject"]' },
    { id: 'osano', root: '.osano-cm-dialog:not(.osano-cm-dialog--hidden)', accept: '.osano-cm-accept-all', reject: '.osano-cm-denyAll, .osano-cm-deny' },
    { id: 'trustarc', root: '#truste-consent-track', accept: '#truste-consent-button', reject: '#truste-consent-required' },
    { id: 'cookie-law-info', root: '#cookie-law-info-bar, .cli-modal.cli-show', accept: '#wt-cli-accept-all-btn, #cookie_action_close_header', reject: '#cookie_action_close_header_reject, #wt-cli-reject-btn' },
    { id: 'moove-gdpr', root: '#moove_gdpr_cookie_info_bar:not(.moove-gdpr-info-bar-hidden)', accept: '.moove-gdpr-infobar-allow-all', reject: '.moove-gdpr-infobar-reject-btn' },
    { id: 'civic', root: '#ccc, #ccc-notify', accept: '#ccc-notify-accept, #ccc-recommended-settings', reject: '#ccc-notify-reject, #ccc-reject-settings' },
    { id: 'axeptio', root: '#axeptio_overlay', accept: '#axeptio_btn_acceptAll', reject: '#axeptio_btn_dismiss' },
    { id: 'piwik-pro', root: '#ppms_cm_popup_overlay, #ppms_cm_consent_popup', accept: '#ppms_cm_agree-to-all', reject: '#ppms_cm_reject-all' },
    { id: 'hubspot', root: '#hs-eu-cookie-confirmation', accept: '#hs-eu-confirmation-button', reject: '#hs-eu-decline-button' },
    { id: 'shopify', root: '#shopify-pc__banner', accept: '#shopify-pc__banner__btn-accept', reject: '#shopify-pc__banner__btn-decline' },
    { id: 'termsfeed', root: '.termsfeed-com---nb', accept: '.cc-nb-okagree', reject: '.cc-nb-reject' },
    { id: 'cookieconsent', root: '#cc-main .cm, #cc_div #cm, .cc-window:not(.cc-invisible)',
      accept: '[data-cc="accept-all"], [data-role="all"], #c-p-bn, .cc-allow, .cc-dismiss',
      reject: '[data-cc="accept-necessary"], [data-role="necessary"], #c-s-bn, .cc-deny' },
  ];

  // Script/iframe hosts that announce a CMP before its banner exists (used to wait a little longer).
  const CMP_HINT_RE = /(?:cookiebot|cookieinformation|policy\.app\.cookieinformation|onetrust|cookielaw|cookiepro|usercentrics|didomi|privacy-center|sourcepoint|privacy-mgmt|sp-prod|consentmanager|quantcast|inmobi|cookieyes|cookie-script|iubenda|cookiefirst|osano|trustarc|axept|civiccomputing|piwik\.pro|gravito|cookiehub|complianz|borlabs|klaro|fundingchoices)/i;

  // ------------------------------------------------------------------------------------------------
  // 2. Wording. Labels are normalised (lower case, collapsed whitespace, surrounding punctuation and
  // arrows removed) and must match a phrase EXACTLY, so "Accepter kun nødvendige" can never be read as
  // "accepter". Notice phrases close information-only banners and are used in accept mode only.
  // ------------------------------------------------------------------------------------------------
  const PHRASES = {
    accept: [
      // Danish
      'accepter alle', 'acceptér alle', 'accepter alle cookies', 'acceptér alle cookies', 'accepter', 'acceptér', 'accepter og luk',
      'accepter og fortsæt', 'tillad alle', 'tillad alle cookies', 'tillad cookies', 'godkend alle', 'godkend alle cookies', 'godkend',
      'giv samtykke', 'giv samtykke til alle', 'jeg accepterer', 'jeg giver samtykke', 'ja tak', 'ja, tak', 'ja til alle', 'ok til alle', 'okay til alle',
      // Norwegian / Swedish / Icelandic
      'godta alle', 'godta', 'aksepter alle', 'aksepter', 'tillat alle', 'jeg godtar', 'godta alle informasjonskapsler',
      'acceptera alla', 'acceptera', 'godkänn alla', 'tillåt alla', 'jag godkänner', 'acceptera alla cookies', 'samþykkja allt', 'samþykkja',
      // English
      'accept all', 'accept all cookies', 'accept', 'accept cookies', 'allow all', 'allow all cookies', 'allow cookies', 'agree', 'i agree',
      'agree and close', 'agree & close', 'i accept', 'yes, i agree', 'accept and continue', 'agree and continue', 'accept & continue', 'accept and close',
      // German / Dutch / French / Finnish / Spanish / Italian / Polish
      'alle akzeptieren', 'akzeptieren', 'alle zulassen', 'alle cookies akzeptieren', 'zustimmen', 'einverstanden', 'alles akzeptieren', 'ich stimme zu',
      'alles accepteren', 'accepteren', 'alle cookies accepteren', 'akkoord', 'alles toestaan',
      'tout accepter', 'accepter tout', "j'accepte", 'accepter et fermer', 'accepter et continuer',
      'hyväksy kaikki', 'hyväksy', 'aceptar todo', 'aceptar todas', 'aceptar', 'accetta tutti', 'accetta', 'zaakceptuj wszystkie', 'akceptuję',
    ],
    reject: [
      // Danish
      'afvis alle', 'afvis', 'afvis alle cookies', 'afvis cookies', 'kun nødvendige', 'kun nødvendige cookies', 'brug kun nødvendige cookies',
      'tillad kun nødvendige', 'tillad kun nødvendige cookies', 'accepter kun nødvendige', 'acceptér kun nødvendige', 'accepter kun nødvendige cookies',
      'nej tak', 'nej, tak', 'nej til alle', 'fortsæt uden at acceptere', 'tillad valgte', 'gem valg',
      // Norwegian / Swedish / Icelandic
      'avvis alle', 'avvis', 'kun nødvendige informasjonskapsler', 'bare nødvendige', 'godta kun nødvendige', 'nei takk',
      'avvisa alla', 'neka alla', 'avvisa', 'neka', 'endast nödvändiga', 'acceptera endast nödvändiga', 'endast nödvändiga cookies', 'hafna öllu',
      // English
      'reject all', 'reject', 'reject all cookies', 'decline', 'decline all', 'deny', 'deny all', 'necessary only', 'only necessary',
      'only necessary cookies', 'necessary cookies only', 'use necessary cookies only', 'accept necessary', 'accept only necessary',
      'accept necessary cookies', 'reject non-essential', 'reject optional cookies', 'continue without accepting',
      // German / Dutch / French / Finnish / Spanish / Italian / Polish
      'alle ablehnen', 'ablehnen', 'nur notwendige', 'nur notwendige cookies', 'nur essenzielle', 'nur essenzielle cookies', 'weiter ohne einwilligung',
      'alles weigeren', 'weigeren', 'alleen noodzakelijke', 'alleen noodzakelijke cookies',
      'tout refuser', 'refuser', 'continuer sans accepter', 'hylkää kaikki', 'vain välttämättömät', 'rechazar todo', 'rechazar', 'rifiuta tutto', 'rifiuta',
      'odrzuć wszystkie',
    ],
    notice: ['ok', 'okay', 'forstået', 'jeg forstår', 'det er ok', 'got it', 'understood', 'i understand', 'luk', 'lukk', 'stäng', 'close', 'schließen', 'fermer', 'sulje', 'x', '×', '✕'],
  };
  const PHRASE_SETS = Object.fromEntries(Object.entries(PHRASES).map(([k, v]) => [k, new Set(v)]));

  const COOKIE_WORDS_RE = /(?:cookie|samtykke|consent|privatliv|persondata|personoplysninger|gdpr|tracking|sporing|informasjonskapsler|einwilligung|datenschutz|integritet|personvern|evästeet|tietosuoja|vie privée|traceurs|privacy|vafrakökur)/i;

  const HEURISTIC_CONTAINERS = '[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog[open],[id*="cookie" i],[class*="cookie" i],[id*="consent" i],[class*="consent" i],[id*="gdpr" i],[class*="gdpr" i],[id*="samtykke" i],[class*="samtykke" i],[id*="privacy" i],[class*="privacy" i],[aria-label*="cookie" i],[aria-label*="samtykke" i],[aria-label*="consent" i],[aria-label*="privatliv" i]';
  const BUTTONS = 'button,[role="button"],a,input[type="button"],input[type="submit"],[tabindex="0"]';
  const LOCK_CLASS_RE = /^(?:no-?scroll|noscroll|overflow-hidden|modal-open|scroll-?lock(?:ed)?|lock-?scroll|disable-?scroll|is-locked|has-overlay|cookie[-\w]*|consent[-\w]*|cmp[-\w]*|gdpr[-\w]*|didomi-popup-open|sp-message-open|coi-overflow-hidden|noScroll)$/i;

  const clicked = new WeakSet();

  // ------------------------------------------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------------------------------------------
  function normalizeLabel(s) {
    return String(s || '').normalize('NFC').toLowerCase().replace(/[\s\u00a0]+/g, ' ')
      .replace(/^[\s"'«»“”„›‹>→✓✔·•|-]+|[\s"'«»“”„.!:›‹>→✓✔·•|-]+$/g, '').trim();
  }

  function classifyLabel(label) {
    const n = normalizeLabel(label);
    if (!n || n.length > 60) return '';
    if (PHRASE_SETS.reject.has(n)) return 'reject';
    if (PHRASE_SETS.accept.has(n)) return 'accept';
    if (PHRASE_SETS.notice.has(n)) return 'notice';
    return '';
  }

  function labelOf(el) {
    const own = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent);
    return [own, el.getAttribute?.('aria-label'), el.getAttribute?.('title')].map(x => String(x || '').trim()).find(Boolean) || '';
  }

  function visible(el) {
    try {
      if (!el || !el.isConnected) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const st = getComputedStyle(el);
      return st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity || 1) > 0.05;
    } catch { return false; }
  }

  /** querySelectorAll over a root and its open shadow roots (bounded). */
  function deepAll(root, selector, limit = 200) {
    const out = [];
    const walk = (r, depth) => {
      if (!r || depth > 4 || out.length >= limit) return;
      try { for (const el of r.querySelectorAll(selector)) { out.push(el); if (out.length >= limit) return; } } catch { return; }
      try {
        for (const host of r.querySelectorAll('*')) if (host.shadowRoot) walk(host.shadowRoot, depth + 1);
      } catch {}
    };
    walk(root, 0);
    return out;
  }

  function scopesFor(roots) {
    return roots.flatMap(r => [r, r.shadowRoot].filter(Boolean));
  }

  function firstVisible(scopes, selector) {
    if (!selector) return null;
    for (const s of scopes) {
      let list;
      try { list = s.querySelectorAll(selector); } catch { continue; }
      for (const el of list) if (visible(el) && !el.disabled) return el;
    }
    return null;
  }

  function isNavigatingLink(el) {
    if (el.tagName !== 'A') return false;
    const raw = (el.getAttribute('href') || '').trim();
    if (!raw || raw === '#' || /^javascript:/i.test(raw)) return false;
    try {
      const u = new URL(raw, location.href);
      return !(u.origin === location.origin && u.pathname === location.pathname && u.search === location.search);
    } catch { return true; }
  }

  function press(el) {
    clicked.add(el);
    try { el.click(); } catch {}
  }

  function scrollLocked() {
    try {
      const h = getComputedStyle(document.documentElement), b = document.body ? getComputedStyle(document.body) : null;
      const hidden = /hidden|clip/.test(h.overflowY) || (b && (/hidden|clip/.test(b.overflowY) || b.position === 'fixed'));
      const tall = Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0) > innerHeight + 200;
      return Boolean(hidden && tall);
    } catch { return false; }
  }

  function hasCmpHint() {
    try {
      for (const s of document.scripts) if (s.src && CMP_HINT_RE.test(s.src)) return true;
      for (const f of document.querySelectorAll('iframe[src]')) if (CMP_HINT_RE.test(f.src)) return true;
    } catch {}
    return false;
  }

  function rootsOf(rule) {
    let found = [];
    try { found = [...document.querySelectorAll(rule.root)]; } catch {}
    if (rule.requireMarker) found = found.filter(r => r.querySelector(rule.requireMarker));
    return found;
  }

  /** Fixed/sticky (itself or within three ancestors) or a dialog — i.e. it sits on top of the page. */
  function overlayish(el) {
    try {
      if (el.matches('[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog[open]')) return true;
      let n = el;
      for (let i = 0; n && n.nodeType === 1 && i < 4; i++, n = n.parentElement) {
        const pos = getComputedStyle(n).position;
        if (pos === 'fixed' || pos === 'sticky') return true;
      }
    } catch {}
    return false;
  }

  function hasDecisionButton(el) {
    try {
      for (const b of el.querySelectorAll(BUTTONS)) if (visible(b) && !isNavigatingLink(b) && classifyLabel(labelOf(b))) return true;
    } catch {}
    return false;
  }

  /**
   * Heuristic banners: visible, overlay-like containers that talk about cookies/consent and offer at
   * least one recognised accept/reject/notice button. Innermost first. A footer that merely mentions
   * "cookies" is never a banner, so the cosmetic fallback cannot hide page content.
   */
  function heuristicContainers() {
    const set = new Set();
    for (const el of deepAll(document, HEURISTIC_CONTAINERS, 300)) set.add(el);
    try {
      for (const el of document.querySelectorAll('body > *, body > * > *')) {
        const pos = getComputedStyle(el).position;
        if (pos === 'fixed' || pos === 'sticky') set.add(el);
      }
    } catch {}
    const out = [];
    for (const el of set) {
      if (el === document.body || el === document.documentElement || !visible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim();
      if (text.length < 20 || text.length > 6000 || !COOKIE_WORDS_RE.test(text)) continue;
      if (!overlayish(el) || !hasDecisionButton(el)) continue;
      out.push({ el, len: text.length });
    }
    out.sort((a, b) => a.len - b.len);
    return out.map(x => x.el);
  }

  function pickButton(scopes, mode) {
    let notice = null, noticeCount = 0;
    for (const s of scopes) {
      let list;
      try { list = s.querySelectorAll(BUTTONS); } catch { continue; }
      const buttons = [...list].filter(b => visible(b) && !b.disabled && !clicked.has(b) && !isNavigatingLink(b));
      noticeCount += buttons.length;
      for (const b of buttons) {
        const kind = classifyLabel(labelOf(b));
        if (kind === mode) return b;
        if (kind === 'notice' && !notice) notice = b;
      }
    }
    // Information-only banners ("Vi bruger cookies … [OK]") — accept mode only, few choices.
    return mode === 'accept' && notice && noticeCount <= 3 ? notice : null;
  }

  // ------------------------------------------------------------------------------------------------
  // Public API (called per frame by the service worker)
  // ------------------------------------------------------------------------------------------------

  /** One detection + at most one click. */
  function step(mode) {
    const out = { frame: location.origin, showing: false, cmps: [], hint: hasCmpHint(), acted: null, locked: scrollLocked() };
    if (mode !== 'accept' && mode !== 'reject') return out;

    for (const rule of CMP_RULES) {
      const roots = rootsOf(rule);
      if (!roots.length) continue;
      out.cmps.push(rule.id);
      const scopes = scopesFor(roots);
      const btn = firstVisible(scopes, rule[mode]);
      const showing = roots.some(visible) || !!btn || !!firstVisible(scopes, rule.accept) || !!firstVisible(scopes, rule.reject);
      if (!showing) continue;
      out.showing = true;
      if (btn && !clicked.has(btn)) {
        press(btn);
        out.acted = { cmp: rule.id, method: 'cmp-rule', label: labelOf(btn).slice(0, 40) };
        return out;
      }
      const byText = pickButton(scopes, mode);
      if (byText) {
        press(byText);
        out.acted = { cmp: rule.id, method: 'cmp-wording', label: labelOf(byText).slice(0, 40) };
        return out;
      }
      if (mode === 'reject' && rule.open) {
        const open = firstVisible(scopes, rule.open);
        if (open && !clicked.has(open)) {
          press(open);
          out.acted = { cmp: rule.id, method: 'cmp-open-settings', label: labelOf(open).slice(0, 40) };
          return out;
        }
      }
    }

    for (const c of heuristicContainers()) {
      out.showing = true;
      const b = pickButton(scopesFor([c]), mode);
      if (b) {
        press(b);
        out.acted = { cmp: 'generic', method: 'wording', label: labelOf(b).slice(0, 40) };
        return out;
      }
    }
    return out;
  }

  /** Cosmetic fallback: hide identified banners/backdrops and unlock scrolling. */
  function cosmetic() {
    let hidden = 0;
    const hide = el => {
      if (!el || el === document.body || el === document.documentElement || el.hasAttribute?.('data-cc-hidden')) return;
      el.style.setProperty('display', 'none', 'important');
      el.setAttribute('data-cc-hidden', '1');
      hidden++;
    };
    const lockClasses = new Set();
    for (const rule of CMP_RULES) {
      const roots = rootsOf(rule);
      if (!roots.length) continue;
      (rule.lockClasses || []).forEach(c => lockClasses.add(c));
      const scopes = scopesFor(roots);
      if (roots.some(visible) || firstVisible(scopes, rule.accept) || firstVisible(scopes, rule.reject)) roots.forEach(hide);
      if (rule.backdrop) { try { document.querySelectorAll(rule.backdrop).forEach(el => { if (visible(el)) hide(el); }); } catch {} }
    }
    for (const c of heuristicContainers()) hide(c);
    // Generic backdrop: a fixed, near-empty layer covering (almost) the whole viewport.
    try {
      for (const el of document.querySelectorAll('body > *, body > * > *')) {
        if (!visible(el)) continue;
        const st = getComputedStyle(el);
        if (st.position !== 'fixed') continue;
        const r = el.getBoundingClientRect();
        const covers = r.width >= innerWidth * 0.9 && r.height >= innerHeight * 0.9;
        const emptyish = (el.innerText || '').trim().length < 40 && el.querySelectorAll('a[href],img,video,iframe').length === 0;
        if (covers && emptyish && Number(st.zIndex || 0) >= 10) hide(el);
      }
    } catch {}
    const wasLocked = scrollLocked();
    for (const node of [document.documentElement, document.body].filter(Boolean)) {
      for (const c of [...node.classList]) if (lockClasses.has(c) || LOCK_CLASS_RE.test(c)) node.classList.remove(c);
      try {
        const st = getComputedStyle(node);
        if (/hidden|clip/.test(st.overflowY)) node.style.setProperty('overflow-y', 'auto', 'important');
        if (/hidden|clip/.test(st.overflow)) node.style.setProperty('overflow', 'auto', 'important');
        if (node === document.body && st.position === 'fixed') { node.style.setProperty('position', 'static', 'important'); node.style.removeProperty('top'); }
      } catch {}
    }
    return { frame: location.origin, hidden, unlocked: wasLocked && !scrollLocked(), stillLocked: scrollLocked() };
  }

  function state() {
    const s = step('none');
    let showing = false;
    for (const rule of CMP_RULES) {
      const roots = rootsOf(rule);
      if (roots.length && (roots.some(visible) || firstVisible(scopesFor(roots), rule.accept) || firstVisible(scopesFor(roots), rule.reject))) { showing = true; break; }
    }
    if (!showing) showing = heuristicContainers().length > 0;
    return { frame: s.frame, showing, locked: s.locked };
  }

  globalThis.__ccConsent = {
    step, cosmetic, state, version: '1.7.0',
    _test: { normalizeLabel, classifyLabel, PHRASES, CMP_RULES },
  };
})();
