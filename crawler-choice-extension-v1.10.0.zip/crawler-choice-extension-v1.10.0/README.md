# Crawler Choice – Heritrix or Browsertrix v1.10.0

by Thomas Smedebøl, Royal Danish Library

Chrome (MV3) extension that recommends **Heritrix** or **Browsertrix** for a site, based on measured
differences between raw HTTP and real browser behaviour on a small, deterministic set of sample pages.

## Install

1. `chrome://extensions` → enable *Developer mode* → *Load unpacked* → select this folder.
2. Open the extension's *Details* and enable **Allow in Incognito** (required: tests run in fresh Incognito windows).
3. Optional: Gemini Nano (Prompt API). The popup shows its availability and offers *Download model* when needed.

Requires Chrome 150+ (DevTools-protocol flat sessions, `AbortSignal.any`, Prompt API for extensions).

## Using it

Open the site in a normal window, click the toolbar icon, choose settings and press **Analyze**.
While tests run, Chrome shows a *“Crawler Choice started debugging this browser”* bar — that is the
DevTools-level request guard. **Cancel** stops a run at any time. When finished, export:

- **Evidence JSON** – every measurement behind the decision (usable as a regression fixture).
- **Browsertrix config** – YAML hints: seeds/scope, `behaviors`, `clickSelector`, timeouts.
- **Heritrix seeds** – start URL plus discovered sitemap documents, and the runtime data (XHR/fetch)
  hosts seen in the tests as seed URLs such as `https://api.x.dk/` (same-site active, third-party commented out).

| Setting | Default | Meaning |
|---|---|---|
| Test scope | Whole site | *Whole site*: sitemap discovery + representative samples. *Active tab URL only*: tests just the current page (no sitemaps, no sampling) |
| Samples | 7 | 5–20 representative pages (whole-site only); always includes a page from each of the two most common sitemap URL patterns |
| Consent banners | Leave untouched | *Try reject all* or *Try accept all + hide leftovers* before measuring: known CMPs (Cookiebot, Cookie Information, OneTrust, Usercentrics, Didomi, Sourcepoint, …) and button wording in Danish and other European languages, in every frame; accept mode then hides a remaining banner and unlocks scrolling |
| Test windows | Unfocused, visible | *Minimized* is less intrusive but Chrome throttles hidden pages |
| Max run time | 6 min | Hard deadline for the whole run |
| Respect robots.txt | off | Exclude `Disallow`ed URLs from sampling (whole-site only; legal-deposit crawls usually ignore robots) |
| Check Heritrix's speculative URLs | on | Probe up to 60 URLs only Heritrix's heuristics found (HEAD, no cookies) to estimate the fictive share |
| Gemini Nano | off | Second opinion; can confirm or veto non-decisive evidence |
| Stop at decisive evidence | on | Early exit (whole-site only) |

A single-page result describes that URL only; the exports then seed only that URL (`scopeType: page`).

See **guide.html** (the *Guide* button) for the full method and evidence table.

## Comparison basis

The raw side of every raw-vs-rendered comparison is what **Heritrix 3.14.1** would discover in the
fetched HTML: a source-order port of its `ExtractorHTML`, inline `ExtractorJS` and `ExtractorCSS`,
verified against Heritrix's own unit tests. See the guide section *Comparison basis*.

## Layout

```
background.js        service-worker orchestration (Chrome APIs only)
offscreen.html/.js   raw-HTML analysis (Heritrix 3.14.1 emulation; DOMParser for text/frameworks) + Gemini Nano fallback
probe/injected.js    isolated-world DOM probe (snapshots, phases, scroll, clicks, menus, media, viewers)
probe/consent.js     consent-banner handler, injected into every frame (CMP rules, wording, cosmetic fallback)
popup.*              UI (Port-based updates, settings, cancel, export)
lib/psl.js           Public Suffix List lookup (lib/psl-data.js is generated)
lib/fetcher.js       polite fetcher: per-host limits, 429/503 back-off, charset decoding
lib/sitemaps.js      robots.txt + sitemap discovery/parsing
lib/locale.js        page language and sitemap-locale heuristics
lib/heritrix-extractor.js  Heritrix 3.14.1 link-extraction emulation (ExtractorHTML + inline ExtractorJS/CSS)
lib/heritrix-data.js       generated tables from the Heritrix sources (TLDs, MIME types, HTML tags, entities)
lib/raw-basis.js           raw comparison basis per sample (URL set, page-like count, summary)
lib/url-comparison.js      unique-URL totals, browser vs Heritrix (short report lines)
lib/url-check.js           URL check: seeded sample of speculative Heritrix-only URLs, control probe, verdicts, estimate
guide.html/.css/.js  user guide (close button in guide.js)
lib/samples.js       deterministic sample selection (incl. the two sitemap-pattern samples)
lib/urlPattern.js    sitemap URL-pattern normalisation and top-pattern selection
lib/cdp.js           DevTools-protocol session: network log, request guard, focus emulation
lib/consent-guard.js which non-GET requests the guard allows while a consent banner is handled
lib/network.js       network-entry classification, polling detection, runtime data (AJAX) hosts
lib/scoring.js       per-sample evidence, baseline correction, prevalence weighting, decision
lib/ai-core.js       Gemini Nano prompt/schema, sanitised payload, quota/timeout handling
lib/state.js         serialised, throttled run-state store + history + export storage
lib/export.js        Browsertrix YAML / Heritrix seeds
tests/               node:test unit tests and fixture replays
tools/               PSL builder, synthetic fixture generator
```

## Development

```
npm test              # node --test, no dependencies
npm run build:psl     # refresh lib/psl-data.js from tools/public_suffix_list.dat
node tools/make-fixtures.mjs
```

To turn a real site into a regression case: export its *Evidence JSON*, copy it to `tests/fixtures/`,
add `"expectedDecision": "Heritrix"` (or `"Browsertrix"`) and optionally `expectedCodes` /
`forbiddenCodes`, then run `npm test`. Evidence exports contain URLs and measurements from the
analysed site; review them before committing (e.g. embargoed or rights-restricted material).

`package.json`, `tests/` and `tools/` are development-only; Chrome ignores them. Remove them when
packaging for the Chrome Web Store if you prefer a smaller bundle.
