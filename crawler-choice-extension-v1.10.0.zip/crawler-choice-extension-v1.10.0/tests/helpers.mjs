// Builders for synthetic raw/rendered sample measurements used by scoring tests and fixtures.
export function links(prefix, n, start = 0) {
  return Array.from({ length: n }, (_, i) => `https://example.dk/${prefix}/${start + i}`);
}

export function raw(over = {}) {
  const l = over.links ?? links('a', 60);
  return {
    ok: true, status: 200, truncated: false, textLength: 9000, scriptCount: 6, frameworks: [], staticUrls: [],
    manifestUrls: [], challenge: { challenge: false, reason: '' }, ...over, links: l, internalLinkCount: l.length,
  };
}

const net0 = { total: 0, noise: 0, data: 0, api: 0, manifestCount: 0, segmentCount: 0, manifests: [], segments: [], pageAssetCount: 0 };
export const net = (o = {}) => ({ ...net0, ...o });
export const dom = (o = {}) => ({ netElements: 0, overlayElements: 0, text: 0, newLinks: [], ...o });

export function rendered(over = {}) {
  const rawLinks = over.rawLinks ?? links('a', 60);
  return {
    role: 'section',
    load: { links: rawLinks, linkCount: rawLinks.length, textLength: 9500, shadowRootCount: 0, shadowLinks: [], frameworks: [], crossOriginIframes: 0, challenge: false, scrollLocked: false, ...(over.load || {}) },
    baseline: { durationMs: 3000, dom: dom(), net: net(), ...(over.baseline || {}) },
    scroll: { durationMs: 6000, info: { steps: 10, bottomLoads: 0, reachedStableBottom: true }, dom: dom(), net: net(), ...(over.scroll || {}) },
    clicks: over.clicks || [],
    menus: over.menus || [],
    media: over.media || { playbackAttempted: 0, playbackStarted: 0, before: { segmentCount: 0, manifestCount: 0 }, net: net() },
    viewer: over.viewer || { detected: false, tested: 0, strongFrames: [] },
    networkAll: net(over.networkAll || {}),
    runtimeOnly: { total: 0, api: 0, meaningful: 0, ...(over.runtimeOnly || {}) },
    polling: over.polling || { detected: false, candidates: [] },
    spa: { routeEvents: 0, mainNavigations: 0 },
  };
}
