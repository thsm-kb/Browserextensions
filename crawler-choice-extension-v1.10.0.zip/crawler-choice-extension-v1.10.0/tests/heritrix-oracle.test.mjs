// Oracle: the test cases of Heritrix 3.14.1's own unit tests, transcribed from
//   modules/src/test/java/org/archive/modules/extractor/ExtractorHTMLTest.java
//   modules/src/test/java/org/archive/modules/extractor/ExtractorJSTest.java
//   modules/src/test/java/org/archive/modules/extractor/ExtractorCSSTest.java
//   commons/src/test/java/org/archive/util/UriUtilsTest.java (isDataUri)
// Expected values are Heritrix's, unchanged. Expected URIs are passed through new URL() only to apply
// the same root-slash/percent-encoding normalisation as UURIFactory.getInstance(expected) does in the
// Java tests. Where a Java test compares the full sorted outlink array (genericCrawl), so do we —
// duplicates included, because Heritrix's outlink collection keeps them.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HeritrixUrlExtractor, HeritrixUriUtils, extractHeritrixFromJavascript } from '../lib/heritrix-extractor.js';

const norm = u => new URL(u).href;
const run = (html, url, config = {}) => new HeritrixUrlExtractor(url, config).extractHtml(html);
const all = (html, url, config) => run(html, url, config).discoveries.map(d => d.url).sort();
const set = (html, url, config) => new Set(run(html, url, config).discoveries.map(d => d.url));
const genericCrawl = (url, html, dest) => assert.deepEqual(all(html, url), dest.map(norm).sort());

// ---------------------------------------------------------------------------------------------
// ExtractorHTMLTest
// ---------------------------------------------------------------------------------------------

test('VALID_TEST_DATA (quoting variants, unclosed tags)', () => {
  const base = 'http://www.archive.org/start/';
  const cases = [
    ['<a href="http://www.slashdot.org">yellow journalism</a> A', 'http://www.slashdot.org'],
    ["<a href='http://www.slashdot.org'>yellow journalism</a> A", 'http://www.slashdot.org'],
    ['<a href=http://www.slashdot.org>yellow journalism</a> A', 'http://www.slashdot.org'],
    ['<a href="http://www.slashdot.org">yellow journalism A', 'http://www.slashdot.org'],
    ["<a href='http://www.slashdot.org'>yellow journalism A", 'http://www.slashdot.org'],
    ['<a href=http://www.slashdot.org>yellow journalism A', 'http://www.slashdot.org'],
    ['<a href="http://www.slashdot.org"/>yellow journalism A', 'http://www.slashdot.org'],
    ["<a href='http://www.slashdot.org'/>yellow journalism A", 'http://www.slashdot.org'],
    ['<a href=http://www.slashdot.org/>yellow journalism A', 'http://www.slashdot.org'],
    ['<img src="foo.gif"> IMG', 'http://www.archive.org/start/foo.gif'],
  ];
  for (const [html, expected] of cases) assert.ok(set(html, base).has(norm(expected)), html);
});

test('testNoWhitespaceBeforeValidAttribute', () => {
  assert.deepEqual(all('<frame name="main"src="http://expected.example.com/"> ', 'http://www.example.com'), ['http://expected.example.com/']);
});

test('testOnlyExtractFormGets', () => {
  const html = '<form method="get" action="http://www.example.com/ok1"> '
    + '<form action="http://www.example.com/ok2" method="get"> '
    + '<form method="post" action="http://www.example.com/notok"> '
    + '<form action="http://www.example.com/ok3"> ';
  assert.equal(run(html, 'http://www.example.com').discoveries.length, 3);
  assert.ok(!set(html, 'http://www.example.com').has('http://www.example.com/notok'));
});

test('testMetaContentURI', () => {
  const html = '<meta property="og:video" content="http://www.example.com/absolute.mp4" /> '
    + '<meta property="og:video" content="/relative.mp4" /> '
    + '<meta property="og:video:height" content="333" />'
    + '<meta property="og:video:type" content="video/mp4" />'
    + '<meta property="strangeproperty" content="notaurl" meaninglessurl="http://www.example.com/shouldnotbeextracted.html" />';
  assert.deepEqual(all(html, 'http://www.example.com'), ['http://www.example.com/absolute.mp4', 'http://www.example.com/relative.mp4']);
});

test('testMetaRobots (default robots policy obeys nofollow)', () => {
  const html = "Blah Blah <meta name='robots' content='index,nofollow'><a href='blahblah'>blah</a> blahblah";
  const r = run(html, 'http://www.example.com');
  assert.equal(r.discoveries.length, 0);
  assert.equal(r.stats.abortedByMetaRobots, true);
});

test('testBadRelativeLinks', () => {
  const html = '<a href="example.html;jsessionid=deadbeef:deadbeed?parameter=this:value"/>'
    + '<a href="example.html?parameter=this:value"/>';
  const links = [...set(html, 'http://www.example.com')];
  assert.ok(links.some(u => u.includes('/example.html;jsessionid=deadbeef:deadbeed?parameter=this:value')));
  assert.ok(links.some(u => u.includes('/example.html?parameter=this:value')));
});

test('testDataUrisAreIgnored / testTooLongUrisAreIgnored', () => {
  assert.equal(run("<img src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=='>", 'http://www.example.com').discoveries.length, 0);
  assert.equal(run(`<img src='data:image/png;base64,${'A'.repeat(5000)}'>`, 'http://www.example.com').discoveries.length, 0);
});

test('testRelativeBaseHrefRelativeLinks / testFirstBaseHrefRelativeLinks / testAbsoluteBaseHrefRelativeLinks', () => {
  const doc = 'https://www.schmid-gartenpflanzen.de/forum/index.php/mv/msg/7627/216142/0/';
  const img = '<img src="index.php/fa/89652/0/" border="0" alt="index.php/fa/89652/0/" />';
  assert.ok([...set('<base href="/forum/"/>\n' + img, doc)].some(u => u.includes('.de/forum/index.php/fa/89652/0/')));
  assert.ok([...set('<base href="/first/"/>\n<base href="/forum/"/>\n' + img, doc)].some(u => u.includes('.de/first/index.php/fa/89652/0/')));
  assert.ok([...set('<base href="https://www.schmid-gartenpflanzen.de/forum/"/>\n' + img, doc)].some(u => u.includes('.de/forum/index.php/fa/89652/0/')));
});

test('testSpeculativeLinkExtraction', () => {
  const html = '<script type="text/javascript">_parameter="www.anotherexample.com";_anotherparameter="www.example.com/index.html";</script>';
  const s = set(html, 'https://www.example.com');
  assert.ok(s.has('http://www.anotherexample.com/'));
  assert.ok(s.has('https://www.example.com/index.html'));
});

test('testScriptTagWritingScriptType', () => {
  const html = '<script type="text/javascript">'
    + 'var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");'
    + " document.write(unescape(\"%3Cscript src='\" + gaJsHost + \"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E\"));"
    + '</script>';
  assert.deepEqual(all(html, 'http://www.example.com/en/fiche/dossier/322/'), []);
});

test('testOutLinksWithBaseHref', () => {
  const html = '<base href="http://www.example.com/"><a href="def/another1.html"><a href="ghi/another2.html">';
  const links = all(html, 'http://www.example.com/abc/index.html');
  assert.equal(links[1], 'http://www.example.com/def/another1.html');
  assert.equal(links[2], 'http://www.example.com/ghi/another2.html');
});

const ZOOMIFY = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" id="ZoomifySlideshowViewer" height="372" width="590">\n'
  + '    <param name="flashvars" value="zoomifyXMLPath=ParamZoomifySlideshowViewer.xml">\n'
  + '    <param name="menu" value="false">\n'
  + '    <param name="bgcolor" value="#000000">\n'
  + '    <param name="src" value="ZoomifySlideshowViewer.swf">\n'
  + '    <embed flashvars="zoomifyXMLPath=EmbedZoomifySlideshowViewer.xml" src="ZoomifySlideshowViewer.swf" menu="false" bgcolor="#000000" pluginspage="http://www.adobe.com/go/getflashplayer" type="application/x-shockwave-flash" name="ZoomifySlideshowViewer" height="372" width="590">\n'
  + '</object> ';

test('testFlashvarsParamValue / testFlashvarsEmbedAttribute', () => {
  const s = set(ZOOMIFY, 'http://www.example.com/');
  assert.ok(s.has('http://www.example.com/ParamZoomifySlideshowViewer.xml'));
  assert.ok(s.has('http://www.example.com/EmbedZoomifySlideshowViewer.xml'));
});

test('testConditionalComment1', () => {
  const links = all('<!--[if IE 6]><img src="foo.gif"><![endif]--><!--[if IE 6]><script src="foo.js"><![endif]-->', 'http://www.example.com/');
  assert.equal(links[0], 'http://www.example.com/foo.gif');
  assert.equal(links[1], 'http://www.example.com/foo.js');
});

test('testImgSrcSetAttribute', () => {
  const html = '<img width="800" height="1200" src="/images/foo.jpg" class="attachment-full size-full" alt="" '
    + 'srcset="a,b,c,,, /images/foo1.jpg 800w,data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7 700w, /images/foo2.jpg 480w(data:,foo, ,), /images/foo3.jpg 96w(x" '
    + 'sizes="(max-width: 800px) 100vw, 800px">';
  const dest = ['http://www.example.com/a,b,c', 'http://www.example.com/images/foo.jpg', 'http://www.example.com/images/foo1.jpg',
    'http://www.example.com/images/foo2.jpg', 'http://www.example.com/images/foo3.jpg'];
  const links = all(html, 'http://www.example.com/');
  for (let i = 0; i < links.length; i++) assert.equal(links[i], dest[i]); // Java loops over links.length
  assert.equal(links.length, dest.length);
});

test('testSourceSrcSetAttribute', () => {
  const html = '<picture><source media="(min-width: 992px)" srcset="images/foo1.jpg"> '
    + '<source media="(min-width: 500px)" SRCSET="images/foo2.jpg"> '
    + '<source media="(min-width: 0px)" srcSet="images/foo3-1x.jpg 1x, images/foo3-2x.jpg 2x"> '
    + '<img src="images/foo.jpg" alt=""> </picture>';
  genericCrawl('http://www.example.com/', html, ['http://www.example.com/images/foo.jpg', 'http://www.example.com/images/foo1.jpg',
    'http://www.example.com/images/foo2.jpg', 'http://www.example.com/images/foo3-1x.jpg', 'http://www.example.com/images/foo3-2x.jpg']);
});

test('testDataAttributes20Minutes', () => {
  const img = 'https://img.20mn.fr/shn9o66FT2-UHl5dl8D38Q/120x78_illustration-avocat.jpg';
  const img2 = 'https://img.20mn.fr/shn9o66FT2-UHl5dl8D38Q/240x156_illustration-avocat.jpg';
  genericCrawl('https://www.20minutes.fr/', `<img class="b-lazy" width="120" height="78"data-src="${img}"sizes="7.5em" alt="Illustration d&#039;un avocat."/>`, [img]);
  genericCrawl('https://www.20minutes.fr/', `<img class="b-lazy" width="120" height="78"data-srcset="${img} 120w,${img2} 240w"sizes="7.5em" alt="Illustration d&#039;un avocat."/>`, [img, img2]);
  genericCrawl('https://www.20minutes.fr/', `<img class="b-lazy" width="120" height="78"data-srcset="${img} 120w" />`, [img]);
});

test('testDataAttributesTelerama', () => {
  const orig = 'https://www.telerama.fr/sites/tr_master/files/styles/m_640x314/public/standup.jpg?itok=w1aDSzBQsc=1012e84ed57e1b1e6ea74a47ec094242';
  const gif = 'https://www.telerama.fr/sites/tr_master/themes/tr/images/trans.gif';
  genericCrawl('https://www.telerama.fr/', `<img itemprop="image" src="${gif}" data-original="${orig}"/>`, [orig, gif]);
});

test('testDataAttributesNouvelObs (duplicates kept)', () => {
  const u = 'http://focus.nouvelobs.com/2020/02/07/0/0/640/320/633/306/75/0/59de545_3vVuzAnVb95lp1Hm0OwQ_Jk2.jpeg';
  genericCrawl('https://www.telerama.fr/', `<source media="(min-width: 640px)" data-original-set="${u}"srcset="${u}">`, [u, u]);
});

test('testDataAttributesEuronews', () => {
  const p = 'https://static.euronews.com/articles/stories/04/54/38/12/';
  const f = s => `${p}${s}_cmsv2_081071de-f9f4-5341-9512-94f5f494f45f-4543812.jpg`;
  const sizes = ['100x56', '150x84', '300x169', '400x225', '600x338', '750x422', '1000x563', '1200x675'];
  const widths = [100, 150, 300, 400, 600, 750, 1000, 1200];
  const html = `<img class="m-img lazyload" src="/images/vector/fallback.svg"data-src="${f('400x225')}"`
    + `data-srcset="${sizes.map((s, i) => `${f(s)} ${widths[i]}w`).join(', ')}"`
    + 'data-sizes="(max-width: 768px) 33vw, (max-width: 1024px) 25vw, (max-width: 1280px) 17vw, 17vw"'
    + 'title="La lutte contre l&#039;épidémie de Covid-19 continue en Europe et dans le monde"/>';
  genericCrawl('https://www.euronews.com/', html, [...sizes.map(f), f('400x225'), 'https://www.euronews.com/images/vector/fallback.svg']);
});

test('testDataAttributesLeMonde', () => {
  const a = 'http://img.lemde.fr/2020/02/29/0/0/4818/3212/384/0/60/0/c7dda5e_5282901-01-06.jpg';
  const b = 'http://img.lemde.fr/2020/02/29/0/0/4818/3212/114/0/95/0/c7dda5e_5282901-01-06.jpg';
  const html = `<img data-srcset="${a} 198w, ${b} 114w" data-src="${a}" srcset="${a} 198w, ${b} 114w" src="${a}" >`;
  genericCrawl('https://www.lemonde.fr/', html, [b, b, a, a, a, a]);
});

test('testDataFullSrcAttributesSlate', () => {
  const r = (id, sz) => `/resizer/${id}=/${sz}/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/PSAGE45Q5NEPVI75KP4AVSZ4OE.jpg`;
  const items = [['opD2fzNY__8TCVlehObW4PRYsMQ', '120x75', 120], ['xZlmD3G7rAQ1A6yHH1_YnwdL3rw', '240x150', 240], ['hIvEezJm81xiHmNW4QyYKm7_y3Q', '300x187', 300],
    ['Yq8wR5hGgk2noF6rFM3IpnLGCJI', '360x225', 360], ['T_8cJnL18KoYyOlLejO-2hz2YhM', '600x375', 600]];
  const full = '/sites/default/files/styles/330x188/public/alexander-andrews-qjyxsc4xb84-unsplash.jpg';
  const html = `<img data-full-src="${full}" srcset="${items.map(([id, sz, w], i) => `${r(id, sz)} ${w}w${i === 0 ? ',  ' : i < items.length - 1 ? ', ' : ''}`).join('')}" >`;
  genericCrawl('https://www.slate.fr/', html, [...items.map(([id, sz]) => `https://www.slate.fr${r(id, sz)}`), `https://www.slate.fr${full}`]);
});

test('testDataLazyAttributes', () => {
  const a = 'https://img.lemde.fr/2023/05/08/182/0/3543/2362/220/146/30/0/11bfa3f_1683552799386-2023-04-22-heg-manoeuvre-0318.JPG';
  const b = 'https://img.lemde.fr/2023/05/08/0/260/2834/2834/120/120/30/0/11bfa3f_1683552799386-2023-04-22-heg-manoeuvre-0318.JPG';
  genericCrawl('https://www.lemonde.fr/', `<source class="js-media-live-srcset" data-lazy-srcset="${a}" media="(min-width: 576px)">\n<img class="js-media-live" data-lazy="${b}" alt=""> \n`, [b, a]);
});

test('testSourceSrcsetAttributes', () => {
  const p = w => `/fr/rimage/ftw_webp_${w}/image/10/1c386e7cddfbf205b9a6fb4ca7ce9666`;
  const html = `<picture>\n<source srcset="${p(240)} 240w" data-srcset="${p(240)} 240w, ${p(288)} 288w, ${p(384)} 384w, ${p(480)} 480w, ${p(2304)} 2304w" data-aspectratio="1.7776666666667" type="image/webp" sizes="1vw">\n</picture>`;
  genericCrawl('https://www.lemonde.fr/', html, [2304, 240, 240, 288, 384, 480].map(w => `https://www.lemonde.fr${p(w)}`));
});

test('testDataSrcAttributes (data-src / -small / -medium are srcset-split on img)', () => {
  const c = n => `http://www.104.fr/cache/media/visuels-generaux/bandeau-home/${n}.jpg`;
  const html = '<img class="b-lazy image-large" \nsrc="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="\n'
    + `data-src-small="${c('c80-468ffd')}, ${c('c233-f551d3')}" \ndata-src-medium="${c('c80-af15f9')}, ${c('c18029b')}" \ndata-src="${c('c8f5db0')}, ${c('c84eebf')}" \nalt=""/>`;
  genericCrawl('https://www.104.fr/', html, ['c18029b', 'c233-f551d3', 'c80-468ffd', 'c80-af15f9', 'c84eebf', 'c8f5db0'].map(c));
});

test('testSrcSetAttributes', () => {
  const r = (id, sz) => `/resizer/${id}=/${sz}/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/PSAGE45Q5NEPVI75KP4AVSZ4OE.jpg`;
  const src = 'http://cloudfront-eu-central-1.images.arcpublishing.com/leparisien/PSAGE45Q5NEPVI75KP4AVSZ4OE.jpg';
  const html = `<div class="lp-image-responsive"><img class="lp-image-responsive_img" src="${src}" alt="Les Insoumis LP/Arnaud Journois" `
    + `srcset="${r('opD2fzNY_8TCVlehObW4PRYsMQ', '120x75')} 120w, ${r('xZlmD3G7rAQ1A6yHH1_YnwdL3rw', '240x150')} 240w, ${r('T_8cJnL18KoYyOlLejO-2hz2YhM', '600x375')} 600w" `
    + 'sizes="(max-width: 739px) 120px, (min-width: 740px) 300px" loading="lazy" fetchpriority="low"></div>';
  genericCrawl('https://www.parisien.fr/', html, [src, ...[['T_8cJnL18KoYyOlLejO-2hz2YhM', '600x375'], ['opD2fzNY_8TCVlehObW4PRYsMQ', '120x75'], ['xZlmD3G7rAQ1A6yHH1_YnwdL3rw', '240x150']].map(([i, s]) => `https://www.parisien.fr${r(i, s)}`)]);
});

test('testLinkRel', () => {
  const html = "<link href='/pingback' rel='pingback'>"
    + "<link href='/style.css' rel=stylesheet>"
    + "<link rel='my stylesheet rocks' href=/style2.css>"
    + '<link rel=icon href=/icon.ico>'
    + "<link href='http://dns-prefetch.example.com/' rel=dns-prefetch>"
    + '<link href=/without-rel>'
    + '<link href=/empty-rel rel=>'
    + "<link href=/just-spaces rel='   '>"
    + '<link href=/canonical rel=canonical>'
    + '<link href=/unknown rel=unknown>';
  const actual = run(html, 'https://www.example.org/').discoveries.map(d => `${d.hop} ${d.url}`).sort();
  assert.deepEqual(actual, ['E https://www.example.org/icon.ico', 'E https://www.example.org/style.css', 'E https://www.example.org/style2.css',
    'L https://www.example.org/canonical', 'L https://www.example.org/unknown']);
});

test('testDisobeyRelNofollow / testRelNofollow', () => {
  const a = '<a href=/normal><a href=/nofollow rel=nofollow><a href=/both><a href=/both rel=nofollow>';
  assert.deepEqual([...set(a, 'https://www.example.org/', { obeyRelNofollow: false })].sort(),
    ['https://www.example.org/both', 'https://www.example.org/nofollow', 'https://www.example.org/normal']);
  const b = '<a href=/normal></a><a href=/nofollow rel=nofollow></a><a href=/both></a><a href=/both rel=nofollow></a>'
    + "<a href=/multi1 rel='noopener nofollow'></a><a href=/multi2 rel=\"nofollow nopener\"></a><a href=/multi3 rel='noopener nofollow noentry'></a>";
  assert.deepEqual([...set(b, 'https://www.example.org/', { obeyRelNofollow: true })].sort(), ['https://www.example.org/both', 'https://www.example.org/normal']);
});

// ---------------------------------------------------------------------------------------------
// ExtractorJSTest — standalone .js resource, via = http://www.archive.org/foo/dummy.js
// ---------------------------------------------------------------------------------------------

const JS_CASES = [
  ['var foo = "http://www.example.com/outlink";', 'http://www.example.com/outlink'],
  ['var foo = "<a href=\\"http://www.example.com/outlink\\">link in html in string</a>";', 'http://www.example.com/outlink'],
  ['var foo = "<a href=\\"http:\\/\\/www.example.com\\/outlink\\">link in html in string with gratuitous escaping</a>";', 'http://www.example.com/outlink'],
  ["'string with spaces','http://example.com/outlink'", 'http://example.com/outlink'],
  ["'string_with_\\'nested/quoted/relative/url.html\\'_inside_of_it'", 'http://www.archive.org/foo/nested/quoted/relative/url.html'],
  ["scheme-less_\\\\\\'example.org/outlink\\\\\\'_with_extra_escaping on the quotes", 'http://example.org/outlink'],
  ["var h1=Math.max.apply(null, $('.ro1 div.box').map(function(){return $(this).height()}).get());", null],
  ["if(window.archive_analytics) { window.archive_analytics.values['server_ms'] = 114; window.archive_analytics.values['server_name'] = \"www26.us.archive.org\"};", 'http://www26.us.archive.org/'],
  ['"layoutAction" : "https:\\/\\/example.com\\/rest\\/dashboards\\/1.0\\/10000\\/layout"', 'https://example.com/rest/dashboards/1.0/10000/layout'],
  ["ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www", null],
  ["_gaq.push(['_setDomainName', '.example.com']);", null],
  ["_gaq.push(['_setDomainName', 'example.com']);", 'http://example.com/'],
  ["document.write(unescape(\"%3Cscript src='\" + cdJsHost + \"j.example.com/cr.js' type='text/javascript'%3E%3C/script%3E\"));", null],
  ['scr.src = host + "/j/roundtrip.js";', 'http://www.archive.org/j/roundtrip.js'],
  ["c+'\" width=\"'+b+'\" border=\"0\" src=\"'+a+'\" />'};return 0==a.example_conversion_format&&a.example_conversion_domain==f?'<a href=\"'+(r(b)+\"//services.example.com/sitestats/\"+({ar:1,bg:1,cs:1,da:1,de:1,el:1,en_AU:1,en_US:1,en_GB:1,es:1,", 'http://services.example.com/sitestats/'],
  ['_CN:1,zh_TW:1}[a.example_conversion_language]?a.example_conversion_language+".html":"en_US.html")+"?cid="+i(a.example_conversion_id))+', 'http://www.archive.org/foo/en_US.html'],
  ["var blah='/question/mark/but/no/query/string.html?';", null],
  ["var blah='/query/string/without/equals.html?foo';", null],
  ["var blah='/query/string/without/value.html?foo=';", 'http://www.archive.org/query/string/without/value.html?foo='],
  ["var blah='/query/string/without/double/equals.html?foo==bar';", null],
  ["var blah='/good/query/string.html?foo=bar';", 'http://www.archive.org/good/query/string.html?foo=bar'],
  ["var blah='/good/query/string.html?foo=bar#with-good-hash-fragment';", 'http://www.archive.org/good/query/string.html?foo=bar'],
  ["var blah='/good/query/string.html?foo=bar#with!bad!hash-fragment';", null],
  ["var blah='/bad!/path/segment.html?foo=bar';", null],
  ["var blah='/good/query/value/with/url-escaping.html?foo=bar%20bar';", 'http://www.archive.org/good/query/value/with/url-escaping.html?foo=bar%20bar'],
  ['\\u0027project_detail.aspx?guid=unicodesinglequote\\u0027', 'http://www.archive.org/foo/project_detail.aspx?guid=unicodesinglequote'],
  ['\\u0022project_detail.aspx?guid=unicodedoublequote\\u0022', 'http://www.archive.org/foo/project_detail.aspx?guid=unicodedoublequote'],
  ["{url: '/static/0000/2683/good_filename_with.two_dots.jpg',caption:'blah blah' }", 'http://www.archive.org/static/0000/2683/good_filename_with.two_dots.jpg'],
  ["{nonUrl: 'non-filename.with_two.dots',etc:'foo foo' }", null],
  ['"FileRef": "\\u002fsites\\u002fprb\\u002fPublic Comment Emails PDF\\u002fOpen Records Law_1r71vq4i.pdf","', 'http://www.archive.org/sites/prb/Public Comment Emails PDF/Open Records Law_1r71vq4i.pdf'],
  ['"FileRef": "\\u002fsites\\u002fprb\\u002fPublic Comment Emails PDF\\u002fOpen Records Law_1r71vq4i.bad","', null],
  ['"FileRef": "\\u002fsites\\u002fprb\\u002fPublic Comment Emails PDF\\u002fOpenRecordsLaw_1r71vq4i.bad","', null],
  ['"FileRef": "\\u002fsites\\u002fprb\\u002fPublic Comment Emails PDF\\u002fOpen Records Law_1r71vq4i","', null],
  ['"FileRef": "\\u002fsites\\u002fprb\\u002fPublic Comment Emails PDF\\u002fOpenRecordsLaw_1r71vq4i","', null],
];

test('ExtractorJSTest VALID_TEST_DATA (standalone JS, resolved against via)', () => {
  const via = 'http://www.archive.org/foo/dummy.js';
  for (const [code, expected] of JS_CASES) {
    const found = extractHeritrixFromJavascript(code, via, via).discoveries.map(d => d.url);
    if (expected === null) assert.deepEqual(found, [], code);
    else assert.ok(found.includes(norm(expected)), `${code}\n  expected ${norm(expected)}\n  got ${JSON.stringify(found)}`);
  }
});

// ---------------------------------------------------------------------------------------------
// ExtractorCSSTest (processStyleCode), base http://www.archive.org/start/
// ---------------------------------------------------------------------------------------------

test('ExtractorCSSTest VALID_TEST_DATA', () => {
  const cases = [
    ['@import url(http://www.archive.org)', 'http://www.archive.org'],
    ["@import url('http://www.archive.org')", 'http://www.archive.org'],
    ['@import url(    "  http://www.archive.org  "   )', 'http://www.archive.org'],
    ['table { border: solid black 1px}\n@import url(style.css)', 'http://www.archive.org/start/style.css'],
  ];
  for (const [css, expected] of cases) {
    const x = new HeritrixUrlExtractor('http://www.archive.org/start/');
    x.processCss(css);
    assert.ok(x.result().discoveries.some(d => d.url === norm(expected)), css);
  }
});

// ---------------------------------------------------------------------------------------------
// UriUtilsTest.testIsDataUri
// ---------------------------------------------------------------------------------------------

test('UriUtilsTest.testIsDataUri', () => {
  for (const s of ['data:,hello', 'data:text/plain,hello', '   data:,hello', '   dAtA:,hello//  ']) assert.equal(HeritrixUriUtils.isDataUri(s), true, s);
  for (const s of ['', ' http://example.org/', 'http://example.org/', '\0\x01\x02\x03garbage']) assert.equal(HeritrixUriUtils.isDataUri(s), false, s);
});
