import { test } from 'node:test';
import assert from 'node:assert/strict';
import { urlPattern, classifySegment, matchesPattern, pickMember, selectDominantPattern, selectTopPatterns, groupHost } from '../lib/urlPattern.js';

const P = url => urlPattern(url)?.path ?? null;

test('leaf segment is dropped; trailing slash is irrelevant', () => {
  assert.equal(P('https://x.dk/nyheder/indland/some-article'), '/nyheder/indland/');
  assert.equal(P('https://x.dk/nyheder/indland/some-article/'), '/nyheder/indland/');
  assert.equal(P('https://x.dk/om-os'), '/');
  assert.equal(P('https://x.dk/side.html?id=7#top'), '/');
});

test('identifier segments truncate the pattern at their parent', () => {
  assert.equal(P('https://x.dk/produkt/48213/'), '/produkt/');
  assert.equal(P('https://x.dk/produkt/48213'), '/produkt/');
  assert.equal(P('https://x.dk/produkt/48213/anmeldelser'), '/produkt/');
  assert.equal(P('https://x.dk/sag/3f2504e0-4f89-11d3-9a0c-0305e82c3301/bilag'), '/sag/');
  assert.equal(P('https://x.dk/objekt/a1b2c3d4e5f6/vis'), '/objekt/');
  assert.equal(P('https://x.dk/p/a7f3k2x9/detalje'), '/p/');
});

test('words containing digits stay literal', () => {
  assert.equal(P('https://x.dk/tema/covid19/artikel'), '/tema/covid19/');
  assert.equal(P('https://x.dk/guides/html5/intro'), '/guides/html5/');
  assert.equal(P('https://x.dk/b2b/kunder/side'), '/b2b/kunder/');
});

test('date segments become placeholders', () => {
  assert.equal(P('https://x.dk/2024/05/12/slug'), '/{yyyy}/{mm}/{dd}/');
  assert.equal(P('https://x.dk/nyheder/2024/05/slug'), '/nyheder/{yyyy}/{mm}/');
  assert.equal(P('https://x.dk/nyheder/2024/05/13'), '/nyheder/{yyyy}/{mm}/');
  assert.equal(P('https://x.dk/arkiv/2024-05-12/slug'), '/arkiv/{date}/');
  assert.equal(P('https://x.dk/arkiv/20240512/slug'), '/arkiv/{date}/');
  assert.equal(urlPattern('https://x.dk/2024/05/12/slug').placeholders, 3);
});

test('month/day only count directly after year/month', () => {
  assert.equal(classifySegment('12', ''), 'id');
  assert.equal(classifySegment('12', 'year'), 'month');
  assert.equal(classifySegment('31', 'month'), 'day');
  assert.equal(classifySegment('13', 'year'), 'id');
  assert.equal(P('https://x.dk/side/12/foo'), '/side/');
});

test('locale prefixes are kept and counted separately', () => {
  assert.equal(P('https://x.dk/da/nyheder/a'), '/da/nyheder/');
  assert.equal(P('https://x.dk/en/news/b'), '/en/news/');
});

test('homepage and non-HTTP URLs have no pattern', () => {
  assert.equal(urlPattern('https://x.dk/'), null);
  assert.equal(urlPattern('https://x.dk'), null);
  assert.equal(urlPattern('javascript:alert(1)'), null);
  assert.equal(urlPattern('mailto:a@x.dk'), null);
  assert.equal(urlPattern('not a url'), null);
});

test('hostile or odd segments are decoded safely', () => {
  assert.equal(P('https://x.dk/%C3%B8konomi/artikel'), '/økonomi/');
  assert.equal(P('https://x.dk/a%2Fb/c'), '/a%2fb/');      // an encoded slash cannot fake a deeper folder
  assert.equal(P('https://x.dk/a%E0%A4%A/c'), '/a%e0%a4%a/'); // invalid escape is kept as-is
  assert.equal(P('https://x.dk/a%0Ab/c'), '/ab/');           // control characters stripped
  const deep = 'https://x.dk/' + Array.from({ length: 40 }, (_, i) => `s${'x'.repeat(i % 3)}`).join('/') + '/leaf';
  assert.ok(urlPattern(deep).depth <= 8);
  assert.ok(P(`https://x.dk/${'a'.repeat(5000)}/leaf`).length < 130);
});

test('matchesPattern compares host and normalized path', () => {
  const dom = { host: 'x.dk', pattern: '/produkt/' };
  assert.equal(matchesPattern('https://www.x.dk/produkt/1', dom), true);
  assert.equal(matchesPattern('https://x.dk/produkt/1', dom), true);
  assert.equal(matchesPattern('https://www.x.dk/produkt/9/foto', dom), true);
  assert.equal(matchesPattern('https://shop.x.dk/produkt/1', dom), false);
  assert.equal(matchesPattern('https://www.x.dk/', dom), false);
  assert.equal(matchesPattern('https://www.x.dk/produkt/1', null), false);
});

const entries = urls => urls.map(u => (typeof u === 'string' ? { url: u, lastmod: '' } : u));

test('selects the most common pattern and reports its share', () => {
  const res = selectDominantPattern(entries([
    'https://x.dk/produkt/1', 'https://x.dk/produkt/2', 'https://x.dk/produkt/3/foto',
    'https://x.dk/nyheder/a', 'https://x.dk/nyheder/b',
    'https://x.dk/om-os', 'https://x.dk/',
  ]), { seed: 'https://x.dk' });
  assert.equal(res.pattern, '/produkt/');
  assert.equal(res.label, '/produkt/');
  assert.equal(res.count, 3);
  assert.equal(res.total, 6); // the homepage is not counted
  assert.equal(res.share, 0.5);
  assert.equal(res.rank, 1);
  assert.match(res.url, /^https:\/\/x\.dk\/produkt\//);
});

test('pick is deterministic and independent of input order', () => {
  const urls = Array.from({ length: 30 }, (_, i) => `https://x.dk/artikel/${i + 1}`);
  const a = selectDominantPattern(entries(urls), { seed: 'https://x.dk' });
  const b = selectDominantPattern(entries([...urls].reverse()), { seed: 'https://x.dk' });
  assert.equal(a.url, b.url);
  const other = Array.from({ length: 8 }, (_, i) => selectDominantPattern(entries(urls), { seed: `seed-${i}` }).url);
  assert.ok(new Set(other).size > 1, 'different seeds should be able to pick different pages');
});

test('duplicates (incl. fragments) are counted once', () => {
  const res = selectDominantPattern(entries([
    'https://x.dk/a/1', 'https://x.dk/a/1#x', 'https://x.dk/a/1',
    'https://x.dk/b/1', 'https://x.dk/b/2',
  ]), { seed: 's' });
  assert.equal(res.pattern, '/b/');
  assert.equal(res.total, 3);
});

test('ties: fewer placeholders, then shallower, then lexicographic', () => {
  let res = selectDominantPattern(entries([
    'https://x.dk/2024/05/a', 'https://x.dk/2024/05/b',
    'https://x.dk/zeta/a', 'https://x.dk/zeta/b',
  ]), { seed: 's' });
  assert.equal(res.pattern, '/zeta/');
  res = selectDominantPattern(entries([
    'https://x.dk/a/b/c/1', 'https://x.dk/a/b/c/2',
    'https://x.dk/q/1', 'https://x.dk/q/2',
  ]), { seed: 's' });
  assert.equal(res.pattern, '/q/');
  res = selectDominantPattern(entries([
    'https://x.dk/beta/1', 'https://x.dk/beta/2',
    'https://x.dk/alfa/1', 'https://x.dk/alfa/2',
  ]), { seed: 's' });
  assert.equal(res.pattern, '/alfa/');
});

test('flat sites: root-level pages are a legitimate pattern', () => {
  const res = selectDominantPattern(entries(['https://x.dk/', 'https://x.dk/a', 'https://x.dk/b', 'https://x.dk/c', 'https://x.dk/d/e']), { seed: 's' });
  assert.equal(res.pattern, '/');
  assert.equal(res.count, 3);
  assert.equal(selectDominantPattern(entries(['https://x.dk/']), { seed: 's' }), null);
});

test('minCount: a single URL is not a pattern', () => {
  assert.equal(selectDominantPattern(entries(['https://x.dk/a/1', 'https://x.dk/b/1']), { seed: 's' }), null);
  assert.ok(selectDominantPattern(entries(['https://x.dk/a/1', 'https://x.dk/b/1']), { seed: 's', minCount: 1 }));
});

test('eligibility filter runs before counting', () => {
  const res = selectDominantPattern(entries([
    'https://evil.example/x/1', 'https://evil.example/x/2', 'https://evil.example/x/3',
    'https://x.dk/ok/1', 'https://x.dk/ok/2',
  ]), { seed: 's', isEligible: u => new URL(u).hostname.endsWith('x.dk') });
  assert.equal(res.pattern, '/ok/');
  assert.equal(res.total, 2);
});

test('labels include the host only when several hosts are present', () => {
  const res = selectDominantPattern(entries([
    'https://www.x.dk/nyheder/1', 'https://www.x.dk/nyheder/2', 'https://www.x.dk/nyheder/3',
    'https://blog.x.dk/nyheder/1', 'https://blog.x.dk/nyheder/2',
  ]), { seed: 's' });
  assert.equal(res.label, 'x.dk/nyheder/');
  assert.equal(res.count, 3);
});

test('www and apex hosts are one group', () => {
  assert.equal(groupHost('WWW.X.dk.'), 'x.dk');
  assert.equal(groupHost('blog.x.dk'), 'blog.x.dk');
  const res = selectTopPatterns(entries([
    'https://www.x.dk/nyheder/1', 'https://www.x.dk/nyheder/2', 'https://x.dk/nyheder/3',
    'https://x.dk/sport/1', 'https://x.dk/sport/2',
  ]), { seed: 's' });
  assert.deepEqual(res.map(r => [r.label, r.count]), [['/nyheder/', 3], ['/sport/', 2]]);
});

test('top-2: ranks, shares and qualifying minimum', () => {
  const urls = [
    ...Array.from({ length: 6 }, (_, i) => `https://x.dk/produkt/${i}`),
    ...Array.from({ length: 4 }, (_, i) => `https://x.dk/nyheder/a${i}`),
    ...Array.from({ length: 2 }, (_, i) => `https://x.dk/blog/b${i}`),
    'https://x.dk/enlig/x',
  ];
  const res = selectTopPatterns(entries(urls), { seed: 's' });
  assert.deepEqual(res.map(r => [r.rank, r.pattern, r.count, r.total]), [[1, '/produkt/', 6, 13], [2, '/nyheder/', 4, 13]]);
  assert.equal(res[1].share, 0.308);
  assert.equal(selectTopPatterns(entries(urls), { seed: 's', n: 5 }).length, 3, 'single-URL pattern never qualifies');
  assert.equal(selectTopPatterns(entries(['https://x.dk/a/1', 'https://x.dk/a/2']), { seed: 's' }).length, 1);
  assert.deepEqual(selectTopPatterns([], { seed: 's' }), []);
  assert.equal(selectDominantPattern(entries(urls), { seed: 's' }).pattern, '/produkt/');
});

test('with lastmod, the pick comes from the newest half', () => {
  const members = Array.from({ length: 10 }, (_, i) => ({ url: `https://x.dk/a/${i}`, ts: Date.UTC(2020 + i, 0, 1) }));
  for (let s = 0; s < 25; s++) {
    const m = pickMember(members, `seed-${s}`);
    assert.ok(m.ts >= Date.UTC(2025, 0, 1), `picked stale member ${m.url}`);
  }
  const undated = members.map(m => ({ ...m, ts: 0 }));
  const picks = new Set(Array.from({ length: 40 }, (_, s) => pickMember(undated, `s${s}`).url));
  assert.ok([...picks].some(u => /\/a\/[0-4]$/.test(u)), 'without lastmod every member is eligible');
});
