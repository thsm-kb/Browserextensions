import { test } from 'node:test';
import assert from 'node:assert/strict';
import { chooseSamples, applyPatternSamples, isPatternEligible, RENDER_ROLE_ORDER, selectRenderTargets } from '../lib/samples.js';
import { matchesPattern } from '../lib/urlPattern.js';

const ROOT = 'x.dk';
const E = urls => urls.map(url => ({ url, lastmod: '', sourceSitemap: 'https://x.dk/sitemap.xml' }));

// News-ish front structure, but most content is products and the second-most is recipes.
function siteEntries() {
  const urls = [];
  for (const s of ['nyheder', 'sport', 'kultur', 'politik']) {
    urls.push(`https://x.dk/${s}/`);
    for (let i = 0; i < 4; i++) urls.push(`https://x.dk/${s}/artikel-${s}-${i}`);
  }
  for (let i = 0; i < 60; i++) urls.push(`https://x.dk/katalog-varer/vare/${1000 + i}`);
  for (let i = 0; i < 25; i++) urls.push(`https://x.dk/opskrifter/2024/0${(i % 9) + 1}/ret-${i}`);
  return E(urls);
}
const pat = (samples, rank) => samples.find(s => s.sitemapPattern?.rank === rank);

test('both top patterns get a sample when the sample is full', () => {
  const samples = chooseSamples({ entries: siteEntries(), currentUrl: 'https://x.dk/sport/', renderedLinks: [], rootDomain: ROOT, max: 7 });
  assert.equal(samples.length, 7);
  const p1 = pat(samples, 1), p2 = pat(samples, 2);
  assert.equal(p1.role, 'dominant-pattern');
  assert.match(p1.url, /^https:\/\/x\.dk\/katalog-varer\/vare\/\d+$/);
  assert.equal(p1.sitemapPattern.pattern, '/katalog-varer/vare/');
  assert.equal(p2.role, 'secondary-pattern');
  assert.equal(p2.sitemapPattern.pattern, '/opskrifter/{yyyy}/{mm}/');
  assert.equal(p2.sitemapPattern.covered, false);
  assert.ok(p1.sitemapPattern.replacedRole && p2.sitemapPattern.replacedRole);
  assert.ok(samples.some(s => s.role === 'front-page'));
  assert.ok(samples.some(s => s.role === 'current-page'));
});

test('deterministic across runs and input order', () => {
  const a = chooseSamples({ entries: siteEntries(), currentUrl: 'https://x.dk/', renderedLinks: [], rootDomain: ROOT, max: 7 });
  const b = chooseSamples({ entries: [...siteEntries()].reverse(), currentUrl: 'https://x.dk/', renderedLinks: [], rootDomain: ROOT, max: 7 });
  assert.equal(pat(a, 1).url, pat(b, 1).url);
  assert.equal(pat(a, 2).url, pat(b, 2).url);
});

test('a covered pattern is annotated, not replaced; the other still gets a sample', () => {
  const samples = chooseSamples({ entries: siteEntries(), currentUrl: 'https://x.dk/katalog-varer/vare/1010', renderedLinks: [], rootDomain: ROOT, max: 7 });
  const cur = samples.find(s => s.role === 'current-page');
  assert.equal(cur.sitemapPattern.rank, 1);
  assert.equal(cur.sitemapPattern.covered, true);
  assert.equal(samples.filter(s => s.role === 'dominant-pattern').length, 0);
  assert.equal(pat(samples, 2).role, 'secondary-pattern');
});

test('appended (no replacement) when the sample has room', () => {
  const entries = E(['https://x.dk/a/1', 'https://x.dk/a/2', 'https://x.dk/a/3', 'https://x.dk/b/1', 'https://x.dk/b/2']);
  const samples = chooseSamples({ entries, currentUrl: 'https://x.dk/', renderedLinks: [], rootDomain: ROOT, max: 20 });
  const tagged = samples.filter(s => s.sitemapPattern);
  assert.equal(tagged.length, 2);
  assert.ok(tagged.every(s => !s.sitemapPattern.replacedRole));
});

test('only one qualifying pattern: one pattern sample', () => {
  const entries = E(['https://x.dk/a/1', 'https://x.dk/a/2', 'https://x.dk/b/1']);
  const samples = chooseSamples({ entries, currentUrl: 'https://x.dk/', renderedLinks: [], rootDomain: ROOT, max: 20 });
  assert.deepEqual(samples.filter(s => s.sitemapPattern).map(s => s.sitemapPattern.rank), [1]);
});

test('rendered navigation links never count toward the patterns', () => {
  const nav = Array.from({ length: 200 }, (_, i) => `https://x.dk/menu/punkt/${i}`);
  const samples = chooseSamples({ entries: siteEntries(), currentUrl: 'https://x.dk/', renderedLinks: nav, rootDomain: ROOT, max: 7 });
  assert.equal(pat(samples, 1).sitemapPattern.pattern, '/katalog-varer/vare/');
  assert.equal(pat(samples, 2).sitemapPattern.pattern, '/opskrifter/{yyyy}/{mm}/');
});

test('off-site, file-like, robots-disallowed and excluded URLs are not counted', () => {
  const entries = E([
    ...Array.from({ length: 20 }, (_, i) => `https://evil.example/x/${i}`),
    ...Array.from({ length: 20 }, (_, i) => `https://x.dk/filer/doc${i}.pdf`),
    ...Array.from({ length: 20 }, (_, i) => `https://x.dk/wp-content/p/${i}`),
    ...Array.from({ length: 20 }, (_, i) => `https://x.dk/privat/p/${i}`),
    'https://x.dk/ok/1', 'https://x.dk/ok/2', 'https://x.dk/ok/3', 'https://x.dk/ja/1', 'https://x.dk/ja/2',
  ]);
  const samples = chooseSamples({ entries, currentUrl: 'https://x.dk/', renderedLinks: [], rootDomain: ROOT, max: 7, robotsRules: [{ allow: false, path: '/privat/' }] });
  assert.deepEqual(samples.filter(s => s.sitemapPattern).map(s => [s.sitemapPattern.pattern, s.sitemapPattern.total]), [['/ok/', 5], ['/ja/', 5]]);
  assert.equal(isPatternEligible('https://x.dk/nyheder/page/2', ROOT), false);
});

const P = (rank, pattern, url) => ({ rank, url, host: 'x.dk', pattern, label: pattern, count: 5, total: 20, share: 0.25, entry: {} });

test('pattern 2 never displaces the sample covering pattern 1', () => {
  const chosen = [
    { url: 'https://x.dk/', role: 'front-page' },
    { url: 'https://x.dk/p/9', role: 'detail-supplement' },   // covers pattern 1
    { url: 'https://x.dk/z/x', role: 'detail' },
  ];
  applyPatternSamples(chosen, [P(1, '/p/', 'https://x.dk/p/1'), P(2, '/q/', 'https://x.dk/q/1')], 3);
  assert.equal(chosen[1].url, 'https://x.dk/p/9');
  assert.equal(chosen[1].sitemapPattern.covered, true);
  assert.equal(chosen[2].role, 'secondary-pattern');
  assert.equal(chosen[2].sitemapPattern.replacedRole, 'detail');
});

test('protected slots and pattern samples are never replaced', () => {
  const chosen = [{ url: 'https://x.dk/', role: 'front-page' }, { url: 'https://x.dk/c', role: 'current-page' }];
  applyPatternSamples(chosen, [P(1, '/p/', 'https://x.dk/p/1'), P(2, '/q/', 'https://x.dk/q/1')], 2);
  assert.deepEqual(chosen.map(s => s.role), ['front-page', 'current-page']);
  const three = [{ url: 'https://x.dk/', role: 'front-page' }, { url: 'https://x.dk/l/', role: 'listing' }];
  applyPatternSamples(three, [P(1, '/p/', 'https://x.dk/p/1'), P(2, '/q/', 'https://x.dk/q/1')], 2);
  assert.deepEqual(three.map(s => s.role), ['front-page', 'dominant-pattern'], 'pattern 2 has no free slot left');
  assert.equal(applyPatternSamples(three, [], 2), three);
});

test('replacement order prefers detail-supplement over listing', () => {
  const chosen = [
    { url: 'https://x.dk/', role: 'front-page' },
    { url: 'https://x.dk/nyheder/', role: 'listing' },
    { url: 'https://x.dk/a/x', role: 'detail-supplement' },
    { url: 'https://x.dk/b/x', role: 'detail' },
  ];
  applyPatternSamples(chosen, [P(1, '/p/', 'https://x.dk/p/1')], 4);
  assert.equal(chosen[2].role, 'dominant-pattern');
  assert.equal(chosen[2].sitemapPattern.replacedRole, 'detail-supplement');
  assert.ok(matchesPattern(chosen[2].url, P(1, '/p/')));
});

test('pattern samples are rendered right after the front/current page', () => {
  const i = RENDER_ROLE_ORDER.indexOf('current-page');
  assert.deepEqual(RENDER_ROLE_ORDER.slice(i + 1, i + 3), ['dominant-pattern', 'secondary-pattern']);
  const t = selectRenderTargets([
    { url: 'https://x.dk/a', role: 'detail' },
    { url: 'https://x.dk/q/1', role: 'secondary-pattern' },
    { url: 'https://x.dk/p/1', role: 'dominant-pattern' },
    { url: 'https://x.dk/', role: 'front-page' },
  ], 4);
  assert.deepEqual(t.map(s => s.role), ['front-page', 'dominant-pattern', 'secondary-pattern', 'detail']);
});
