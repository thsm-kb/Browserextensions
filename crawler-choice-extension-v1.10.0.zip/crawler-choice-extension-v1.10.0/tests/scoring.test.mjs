import test from 'node:test';
import assert from 'node:assert/strict';
import { sampleEvidence, aggregate, decide, baselineCorrect } from '../lib/scoring.js';
import { raw, rendered, links, dom, net } from './helpers.mjs';

const run = (pairs, ai) => {
  const samples = pairs.map(([r, x], i) => ({ url: `https://example.dk/s${i}`, role: x.role, evidence: sampleEvidence(r, x) }));
  const agg = aggregate(samples, {});
  return { agg, final: decide(agg, ai), samples };
};
const codesOf = ev => ev.codes.map(c => c.code);

test('static site → Heritrix with symmetric evidence', () => {
  const { final, agg } = run([[raw(), rendered()], [raw(), rendered()], [raw(), rendered()]]);
  assert.equal(final.decision, 'Heritrix');
  assert.ok(agg.heritrixScore > 0);
  assert.equal(agg.browsertrixScore, 0);
});

test('carousel churn during the idle baseline is subtracted from scroll', () => {
  const carousel = { netElements: 30, text: 600, newLinks: links('promo', 4) };
  const r = rendered({
    baseline: { durationMs: 3000, dom: dom(carousel), net: net({ data: 2 }) },
    scroll: { durationMs: 3000, info: { bottomLoads: 1 }, dom: dom({ netElements: 40, text: 800, newLinks: links('promo', 5, 4) }), net: net({ data: 2 }) },
  });
  const ev = sampleEvidence(raw(), r);
  assert.ok(!codesOf(ev).some(c => c.startsWith('SCROLL')), codesOf(ev).join());
});

test('consent banner insertions (overlayElements) never count as content', () => {
  const c = baselineCorrect({ durationMs: 1000, dom: dom({ netElements: 0, overlayElements: 300 }), net: net({ data: 3 }) }, { durationMs: 3000, dom: dom(), net: net() }, new Set());
  assert.equal(c.elements, 0);
});

test('infinite scroll with new internal links → decisive Browsertrix', () => {
  const r = rendered({ scroll: { durationMs: 8000, info: { bottomLoads: 3 }, dom: dom({ netElements: 400, text: 6000, newLinks: links('artikel', 24) }), net: net({ data: 3, api: 3 }) } });
  const { final, samples } = run([[raw(), r], [raw(), rendered()]]);
  assert.ok(codesOf(samples[0].evidence).includes('SCROLL_DISCOVERS_LINKS'));
  assert.equal(final.decision, 'Browsertrix');
  assert.equal(final.path, 'decisive-measured-signal');
});

test('links already in raw HTML do not count as discovered by scrolling', () => {
  const rawLinks = links('artikel', 80);
  const r = rendered({ rawLinks, scroll: { durationMs: 8000, info: { bottomLoads: 3 }, dom: dom({ netElements: 400, text: 6000, newLinks: rawLinks.slice(40, 70) }), net: net({ data: 3 }) } });
  const ev = sampleEvidence(raw({ links: rawLinks }), r);
  assert.ok(!codesOf(ev).includes('SCROLL_DISCOVERS_LINKS'));
});

test('load-more click → decisive', () => {
  const r = rendered({ clicks: [{ type: 'load-more', durationMs: 1700, dom: dom({ netElements: 60, text: 1200, newLinks: links('n', 8) }), net: net({ data: 1 }) }] });
  assert.ok(codesOf(sampleEvidence(raw(), r)).includes('CLICK_LOADS_PAGINATED_CONTENT'));
});

test('Next.js chunk scripts produce no streaming evidence', () => {
  const r = rendered({ networkAll: { segmentCount: 0, manifestCount: 0 } });
  assert.ok(!codesOf(sampleEvidence(raw({ frameworks: ['Next.js'] }), r)).some(c => /STREAM|SEGMENT|MANIFEST/.test(c)));
});

test('playback-triggered segments → decisive', () => {
  const r = rendered({ media: { playbackAttempted: 1, playbackStarted: 1, before: { segmentCount: 0 }, net: net({ segmentCount: 4 }) }, networkAll: { segmentCount: 4 } });
  assert.ok(codesOf(sampleEvidence(raw(), r)).includes('PLAYBACK_STARTS_MEDIA_SEGMENTS'));
});

test('challenge only counts with markers when our own fetcher was throttled', () => {
  const blocked = raw({ ok: false, status: 429, textLength: 200, challenge: { challenge: true, reason: 'status-429-with-bot-wording' } });
  assert.equal(sampleEvidence(blocked, rendered(), { fetcherThrottled: true }).comparable, false);
  const cf = raw({ ok: false, status: 403, textLength: 200, challenge: { challenge: true, reason: 'marker:_cf_chl_opt' } });
  const ev = sampleEvidence(cf, rendered(), { fetcherThrottled: true });
  assert.ok(codesOf(ev).includes('BROWSER_BYPASSES_CHALLENGE'));
});

test('Gemini Nano can veto the non-decisive multiple-strong path', () => {
  const shell = () => [raw({ textLength: 900, links: links('a', 5) }), rendered({ rawLinks: links('a', 50), load: { textLength: 12000 }, runtimeOnly: { api: 2, meaningful: 4 } })];
  const pairs = [shell(), shell(), [raw(), rendered()]];
  assert.equal(run(pairs).final.decision, 'Browsertrix');
  const vetoed = run(pairs, { status: 'ok', needsHighFidelity: false, confidence: 'high' }).final;
  assert.equal(vetoed.decision, 'Heritrix');
  assert.equal(vetoed.aiVeto, true);
});

test('prevalence weighting: a single weak sample does not flip the decision', () => {
  const r = rendered({ scroll: { durationMs: 6000, info: {}, dom: dom({ netElements: 30, text: 1500 }), net: net() } });
  const { final } = run([[raw(), r], [raw(), rendered()], [raw(), rendered()], [raw(), rendered()]]);
  assert.equal(final.decision, 'Heritrix');
});

test('single-page mode: two strong codes on the one sample are enough', () => {
  const shell = [raw({ textLength: 900, links: links('a', 5) }), rendered({ rawLinks: links('a', 50), load: { textLength: 12000 }, runtimeOnly: { api: 2, meaningful: 4 } })];
  const samples = [{ url: 'https://example.dk/app', role: 'current-page', evidence: sampleEvidence(...shell) }];
  const agg = aggregate(samples, {});
  assert.equal(decide(agg, null).decision, 'Heritrix');                          // site rule needs 2 samples
  assert.equal(decide(agg, null, { minStrongSamples: 1 }).decision, 'Browsertrix');
});
