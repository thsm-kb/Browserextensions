import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  selectProbeSample, controlUrlFor, hostBehaviour, classifyProbe, wilsonFpc, estimateFictive, runUrlCheck, urlCheckListing,
} from '../lib/url-check.js';
import { PoliteFetcher } from '../lib/fetcher.js';

const pool = Array.from({ length: 200 }, (_, i) => `https://x.dk/p/${i}`);

test('sample: seeded, order-independent, distinct, capped', () => {
  const a = selectProbeSample(pool, 60, 'https://x.dk');
  const b = selectProbeSample([...pool].reverse(), 60, 'https://x.dk');
  assert.deepEqual(a, b);
  assert.equal(new Set(a).size, 60);
  assert.notDeepEqual(selectProbeSample(pool, 60, 'https://y.dk'), a);
  assert.equal(selectProbeSample(pool.slice(0, 10), 60, 's').length, 10);
  assert.deepEqual(selectProbeSample([], 60, 's'), []);
});

test('control URL is made-up, same origin, stable per seed', () => {
  const c = controlUrlFor('https://x.dk', 'seed');
  assert.match(c, /^https:\/\/x\.dk\/crawler-choice-check-[0-9a-z]+\/[0-9a-z]+-not-a-page\.html$/);
  assert.equal(c, controlUrlFor('https://x.dk', 'seed'));
});

test('host behaviour from the control probe', () => {
  assert.equal(hostBehaviour({ status: 404 }), 'proper-404');
  assert.equal(hostBehaviour({ status: 410 }), 'proper-404');
  assert.equal(hostBehaviour({ status: 200, redirected: true, finalUrl: 'https://x.dk/' }), 'redirects-unknown');
  assert.equal(hostBehaviour({ status: 200 }), 'soft-404');
  assert.equal(hostBehaviour({ status: 403 }), 'blocked');
  assert.equal(hostBehaviour({ status: 0, error: 'timeout' }), 'no-answer');
  assert.equal(hostBehaviour(null), 'no-answer');
});

test('verdicts against the control', () => {
  const p404 = { status: 404 }, home = { status: 200, redirected: true, finalUrl: 'https://x.dk/' }, soft = { status: 200 }, blocked = { status: 403 };
  // proper 404 host
  assert.equal(classifyProbe({ status: 200 }, p404), 'live');
  assert.equal(classifyProbe({ status: 200, redirected: true, finalUrl: 'https://x.dk/new' }, p404), 'live');
  assert.equal(classifyProbe({ status: 404 }, p404), 'fictive');
  assert.equal(classifyProbe({ status: 410 }, p404), 'fictive');
  assert.equal(classifyProbe({ status: 403 }, p404), 'live', 'exists but restricted');
  assert.equal(classifyProbe({ status: 500 }, p404), 'unknown');
  assert.equal(classifyProbe({ status: 429 }, p404), 'unknown');
  assert.equal(classifyProbe({ status: 0, error: 'timeout' }, p404), 'unknown');
  // host that redirects unknown URLs to the front page
  assert.equal(classifyProbe({ status: 200, redirected: true, finalUrl: 'https://x.dk/#x' }, home), 'fictive');
  assert.equal(classifyProbe({ status: 200, redirected: true, finalUrl: 'https://x.dk/other' }, home), 'live');
  assert.equal(classifyProbe({ status: 200 }, home), 'live');
  // soft-404 host: a plain 200 says nothing
  assert.equal(classifyProbe({ status: 200 }, soft), 'unknown');
  assert.equal(classifyProbe({ status: 404 }, soft), 'fictive');
  assert.equal(classifyProbe({ status: 200, redirected: true, finalUrl: 'https://x.dk/a/' }, soft), 'live');
  // host that blocks everything
  assert.equal(classifyProbe({ status: 403 }, blocked), 'unknown');
  assert.equal(classifyProbe({ status: 200 }, blocked), 'live');
});

test('Wilson interval with finite-population correction', () => {
  const w = wilsonFpc(38, 58, 130);
  assert.ok(w.low < w.p && w.p < w.high);
  assert.ok(w.high - w.low < 0.25);
  const full = wilsonFpc(5, 10, 10);
  assert.ok(full.high - full.low < 1e-9, 'whole pool tested: no sampling uncertainty');
  assert.deepEqual(wilsonFpc(0, 0, 10), { p: 0, low: 0, high: 1 });
});

test('estimate: extrapolated with a range, exact when the whole pool was tested', () => {
  const results = [...Array(38).fill({ verdict: 'fictive' }), ...Array(20).fill({ verdict: 'live' }), ...Array(2).fill({ verdict: 'unknown' })];
  const e = estimateFictive(130, results);
  assert.deepEqual([e.tested, e.fictive, e.live, e.unknown, e.decided, e.exact], [60, 38, 20, 2, 58, false]);
  assert.equal(e.estimate, Math.round(38 / 58 * 130));
  assert.ok(e.low < e.estimate && e.estimate < e.high);
  const x = estimateFictive(3, [{ verdict: 'fictive' }, { verdict: 'live' }, { verdict: 'fictive' }]);
  assert.deepEqual([x.estimate, x.low, x.high, x.exact], [2, 2, 2, true]);
  assert.equal(estimateFictive(5, [{ verdict: 'unknown' }]).estimate, null);
});

// A fake site: /real/* exists, unknown paths behave per host type.
function fakeSite(kind) {
  const calls = [];
  const probe = async url => {
    calls.push(url);
    const path = new URL(url).pathname;
    const exists = path.startsWith('/real/');
    if (kind === 'proper') return { status: exists ? 200 : 404, finalUrl: url, redirected: false, method: 'HEAD' };
    if (kind === 'home') return exists ? { status: 200, finalUrl: url, redirected: false, method: 'HEAD' } : { status: 200, finalUrl: 'https://x.dk/', redirected: true, method: 'HEAD' };
    if (kind === 'soft') return { status: 200, finalUrl: url, redirected: false, method: 'HEAD' };
    return { status: 403, finalUrl: url, redirected: false, method: 'HEAD' };
  };
  return { probe, calls };
}
const mixed = [...Array.from({ length: 30 }, (_, i) => `https://x.dk/real/${i}`), ...Array.from({ length: 70 }, (_, i) => `https://x.dk/fake/${i}.js`)];

test('runUrlCheck on a host with proper 404s and on one that redirects unknown URLs home', async () => {
  for (const kind of ['proper', 'home']) {
    const { probe, calls } = fakeSite(kind);
    const r = await runUrlCheck(mixed, { probe, seed: 'https://x.dk', sampleSize: 40 });
    assert.equal(r.results.length, 40);
    assert.equal(calls.length, 41, 'one control + the sample');
    assert.ok(calls[0].includes('crawler-choice-check-'));
    for (const t of r.results) assert.equal(t.verdict, t.url.includes('/real/') ? 'live' : 'fictive', `${kind} ${t.url}`);
    assert.equal(r.estimate.unknown, 0);
    assert.ok(Math.abs(r.estimate.share - 0.7) < 0.2);
    assert.ok(r.estimate.low <= 70 && 70 <= r.estimate.high, `range ${r.estimate.low}–${r.estimate.high} covers the truth`);
  }
});

test('runUrlCheck refuses to guess on soft-404 and blocking hosts', async () => {
  for (const kind of ['soft', 'blocked']) {
    const r = await runUrlCheck(mixed, { probe: fakeSite(kind).probe, seed: 's', sampleSize: 20 });
    assert.equal(r.estimate.estimate, null, kind);
    assert.equal(r.estimate.unknown, 20);
  }
});

test('robots filter, abort and listing', async () => {
  const r = await runUrlCheck(mixed, { probe: fakeSite('proper').probe, seed: 's', sampleSize: 100, allowed: u => !u.includes('/fake/') });
  assert.equal(r.poolSize, 30);
  assert.equal(r.excludedByRobots, 70);
  const ctrl = new AbortController(); ctrl.abort();
  const a = await runUrlCheck(mixed, { probe: fakeSite('proper').probe, seed: 's', sampleSize: 5, signal: ctrl.signal });
  assert.ok(a.results.every(x => x.verdict === 'unknown' && x.error === 'not-run'));
  const listing = urlCheckListing(r);
  assert.match(listing.split('\n')[0], /^\[control · 404 · proper-404\] https:\/\/x\.dk\/crawler-choice-check-/);
  assert.match(listing, /\n\[live · 200\] https:\/\/x\.dk\/real\/0\n/);
  assert.equal(urlCheckListing(null), '');
});

test('fetcher.probe: HEAD, GET fallback, no cookies, throttling slows down', async () => {
  const seen = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    seen.push([init.method, init.credentials, url]);
    if (url.endsWith('/nohead') && init.method === 'HEAD') return new Response(null, { status: 405 });
    if (url.endsWith('/slow')) return new Response(null, { status: 429 });
    if (url.endsWith('/broken') && init.method === 'HEAD') throw new TypeError('network');
    return new Response(init.method === 'GET' ? 'x'.repeat(100000) : null, { status: 200 });
  };
  try {
    const f = new PoliteFetcher({ perHostConcurrency: 2, minGapMs: 0 });
    assert.deepEqual(await f.probe('https://x.dk/a'), { status: 200, finalUrl: 'https://x.dk/a', redirected: false, method: 'HEAD' });
    assert.equal((await f.probe('https://x.dk/nohead')).method, 'GET');
    assert.equal((await f.probe('https://x.dk/broken')).method, 'GET');
    const before = f.minGapMs;
    assert.equal((await f.probe('https://x.dk/slow')).status, 429);
    assert.ok(f.minGapMs >= before && f.summary().throttled === 1);
    assert.ok(seen.every(([, cred]) => cred === 'omit'));
  } finally { globalThis.fetch = realFetch; }
});
