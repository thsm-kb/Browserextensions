import { test } from 'node:test';
import assert from 'node:assert/strict';
import { collectAjaxHosts, mergeAjaxHosts, hostSeedUrl } from '../lib/network.js';
import { heritrixSeeds, ajaxScopeLines, browsertrixYaml } from '../lib/export.js';

const log = [
  { url: 'https://api.x.dk/v1/articles?page=2', type: 'Fetch', mime: 'application/json' },
  { url: 'https://api.x.dk/v1/articles?page=3', type: 'XHR', mime: 'application/json' },
  { url: 'https://www.x.dk/live/feed', type: 'EventSource', mime: 'text/event-stream' },
  { url: 'https://search.thirdparty.io/q?x=1', type: 'Fetch', mime: 'application/json' },
  { url: 'https://www.google-analytics.com/g/collect?v=2', type: 'Fetch' },           // noise
  { url: 'https://consent.cookiebot.com/x.json', type: 'XHR' },                      // noise (CMP)
  { url: 'https://api.x.dk/app.js', type: 'Script', mime: 'application/javascript' }, // not AJAX
  { url: 'wss://live.x.dk/socket', type: 'WebSocket' },                               // not fetchable by Heritrix
  { url: 'https://img.x.dk/a.jpg', type: 'Image', mime: 'image/jpeg' },
];

test('collectAjaxHosts keeps non-noise XHR/fetch/EventSource hosts only', () => {
  assert.deepEqual(collectAjaxHosts(log).map(h => [h.host, h.requests]), [['api.x.dk', 2], ['search.thirdparty.io', 1], ['www.x.dk', 1]]);
  assert.deepEqual(collectAjaxHosts(null), []);
});

test('mergeAjaxHosts classifies same-site, third-party and seed-covered hosts', () => {
  const merged = mergeAjaxHosts([collectAjaxHosts(log), collectAjaxHosts(log.slice(0, 1)), [{ host: '10.0.0.5', requests: 1, api: 0 }]], { rootDomain: 'x.dk', rootSeedHosts: ['www.x.dk'] });
  const by = Object.fromEntries(merged.map(h => [h.host, h]));
  assert.equal(by['api.x.dk'].samples, 2);
  assert.equal(by['api.x.dk'].requests, 3);
  assert.equal(by['api.x.dk'].sameSite, true);
  assert.equal(by['api.x.dk'].coveredBySeed, false);
  assert.equal(by['www.x.dk'].coveredBySeed, true);
  assert.equal(by['search.thirdparty.io'].sameSite, false);
  assert.equal(by['10.0.0.5'].surtable, false);
  assert.equal(merged[0].sameSite, true, 'same-site hosts first');
});

test('seed URLs for data hosts', () => {
  assert.equal(hostSeedUrl('api.x.dk'), 'https://api.x.dk/');
  assert.equal(hostSeedUrl('API.Example.co.uk', true), 'https://api.example.co.uk/');
  assert.equal(hostSeedUrl('legacy.x.dk', false), 'http://legacy.x.dk/');
  const plain = collectAjaxHosts([{ url: 'http://legacy.x.dk/api/x', type: 'XHR', mime: 'application/json' }]);
  assert.equal(plain[0].https, false);
  assert.equal(mergeAjaxHosts([plain], { rootDomain: 'x.dk' })[0].https, false);
  assert.equal(mergeAjaxHosts([[{ host: 'old.x.dk', requests: 1, api: 0 }]], { rootDomain: 'x.dk' })[0].https, true, 'older evidence defaults to https');
});

const bundle = (extra = {}) => ({
  version: '1.7.0', generatedAt: '2026-10-02T10:00:00.000Z',
  site: { url: 'https://www.x.dk/side', origin: 'https://www.x.dk', host: 'www.x.dk' },
  settings: { testScope: 'site' },
  sitemap: { documents: ['https://www.x.dk/sitemap.xml'] },
  ajaxHosts: mergeAjaxHosts([collectAjaxHosts(log)], { rootDomain: 'x.dk', rootSeedHosts: ['www.x.dk'] }),
  aggregate: { evidence: [] }, decision: { decision: 'Heritrix', confidence: 'low', path: 'x' }, warnings: [], samples: [],
  ...extra,
});

test('Heritrix seeds: same-site data hosts as seed URLs, third parties commented out', () => {
  const txt = heritrixSeeds(bundle());
  const lines = txt.trim().split('\n');
  assert.equal(lines[1], 'https://www.x.dk/');
  assert.equal(lines[2], 'https://www.x.dk/sitemap.xml');
  assert.ok(lines.includes('https://api.x.dk/'));
  assert.ok(lines.includes('#https://search.thirdparty.io/'));
  assert.equal(lines.filter(l => l === 'https://www.x.dk/').length, 1, 'the seed host is not added a second time');
  assert.ok(/Already in scope through the "\/" seed: www\.x\.dk/.test(txt));
  assert.ok(!lines.some(l => l.startsWith('+')), 'no SURT directives');
  // every non-comment line is a bare URL (no trailing comments)
  for (const l of lines.filter(l => l && !l.startsWith('#'))) assert.match(l, /^https?:\/\/\S+$/);
  // each data-host seed is preceded by its own description line
  const i = lines.indexOf('https://api.x.dk/');
  assert.match(lines[i - 1], /^# api\.x\.dk — \d+ requests? on \d+ samples?$/);
});

test('page-only seeds also carry the scope lines (a path seed covers no whole host)', () => {
  const ajaxHosts = mergeAjaxHosts([collectAjaxHosts(log)], { rootDomain: 'x.dk', rootSeedHosts: [] });
  const txt = heritrixSeeds(bundle({ settings: { testScope: 'page' }, ajaxHosts }));
  assert.ok(txt.split('\n').includes('https://www.x.dk/'), 'www host must be added when only a page is seeded');
  assert.equal(txt.split('\n')[1], 'https://www.x.dk/side');
  assert.ok(txt.split('\n').includes('https://api.x.dk/'));
});

test('no hosts / hostile host strings', () => {
  assert.deepEqual(ajaxScopeLines([]), ['', '# No runtime data (XHR/fetch) hosts were observed in the browser tests.']);
  const evil = ajaxScopeLines([{ host: 'api.x.dk\nhttps://evil.example/', requests: 1, samples: 1, sameSite: true }, { host: 'ok.x.dk', requests: 1, samples: 1, sameSite: true }]);
  assert.ok(!evil.some(l => l.includes('evil')));
  assert.ok(evil.includes('https://ok.x.dk/'));
  assert.ok(evil.some(l => /not plain host names/.test(l)));
});

test('Browsertrix YAML mentions observed hosts as a comment only', () => {
  const yaml = browsertrixYaml(bundle({ sitemap: { documents: [], robotsSitemaps: [] } }));
  assert.match(yaml, /^# Runtime data .*\n#   api\.x\.dk, /m);
});
