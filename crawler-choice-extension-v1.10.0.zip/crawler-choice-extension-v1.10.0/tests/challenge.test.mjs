import test from 'node:test';
import assert from 'node:assert/strict';
import { detectChallenge } from '../lib/challenge.js';

const big = 'Lorem ipsum dolor sit amet. '.repeat(400);

test('Akamai CDN assets and reCAPTCHA forms are not challenges (v1.4 false positive)', () => {
  const html = `<html><head><script src="https://www.google.com/recaptcha/api.js"></script></head><body><img src="https://img.akamaized.net/a.jpg"><p>akamai captcha</p>${big}</body></html>`;
  assert.equal(detectChallenge({ html, title: 'News', text: big + ' akamai captcha', status: 200 }).challenge, false);
});

test('Cloudflare interstitial is a challenge', () => {
  const html = '<html><head><title>Just a moment...</title></head><body><script>window._cf_chl_opt={}</script></body></html>';
  assert.equal(detectChallenge({ html, title: 'Just a moment...', text: 'Checking your browser', status: 403 }).challenge, true);
});

test('Challenge phrase on a large normal page is ignored', () => {
  assert.equal(detectChallenge({ html: '<p>x</p>', title: 'Access denied — a film review', text: big, status: 200 }).challenge, false);
});
