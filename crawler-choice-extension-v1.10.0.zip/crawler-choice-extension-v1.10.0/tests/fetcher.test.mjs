import test from 'node:test';
import assert from 'node:assert/strict';
import { sniffCharset, decodeText } from '../lib/fetcher.js';

test('charset from header, meta and default', () => {
  const latin = Uint8Array.from([0x3c, 0x70, 0x3e, 0xe6, 0xf8, 0xe5]); // <p>æøå in windows-1252
  assert.equal(sniffCharset(latin, 'text/html; charset=windows-1252'), 'windows-1252');
  assert.equal(decodeText(latin, 'windows-1252'), '<p>æøå');
  const meta = new TextEncoder().encode('<meta charset="iso-8859-1"><p>');
  assert.equal(sniffCharset(meta, 'text/html'), 'iso-8859-1');
  assert.equal(sniffCharset(new TextEncoder().encode('<p>'), ''), 'utf-8');
  assert.equal(decodeText(new Uint8Array([0x61]), 'not-a-charset'), 'a');
});
