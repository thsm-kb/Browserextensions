import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyEntry, summarizeWindow, detectPolling } from '../lib/network.js';

const e = (url, type, mime = '', t = 0, extra = {}) => ({ url, type, mime, t, method: 'GET', ...extra });

test('JS chunks are never media segments (v1.4 /chunk regex bug)', () => {
  for (const u of ['https://x.dk/_next/static/chunks/main-abc.js', 'https://x.dk/js/chunk-vendors.4f2.js', 'https://x.dk/chunks/12.ts']) {
    assert.equal(classifyEntry(e(u, 'Script', 'application/javascript')).segment, false, u);
  }
  // A TypeScript source map / module served as text is not a segment either.
  assert.equal(classifyEntry(e('https://x.dk/src/app.ts', 'Fetch', 'application/typescript')).segment, false);
});

test('HLS/DASH manifests and segments are MIME/type verified', () => {
  assert.equal(classifyEntry(e('https://v.dk/master.m3u8', 'XHR', 'application/vnd.apple.mpegurl')).manifest, true);
  assert.equal(classifyEntry(e('https://v.dk/play?id=1', 'Fetch', 'application/dash+xml')).manifest, true);
  assert.equal(classifyEntry(e('https://v.dk/seg-1.ts', 'XHR', 'video/mp2t')).segment, true);
  assert.equal(classifyEntry(e('https://v.dk/seg-1.m4s', 'Fetch', 'video/iso.segment')).segment, true);
  assert.equal(classifyEntry(e('https://v.dk/frag?n=3', 'XHR', 'video/mp4')).segment, true);
  // Progressive download of a single MP4 is not streaming.
  assert.equal(classifyEntry(e('https://v.dk/movie.mp4', 'Media', 'video/mp4')).segment, false);
});

test('analytics are noise', () => {
  assert.equal(classifyEntry(e('https://www.google-analytics.com/g/collect?v=2', 'Fetch')).noise, true);
  assert.equal(classifyEntry(e('https://x.dk/api/articles?page=2', 'Fetch', 'application/json')).data, true);
});

test('window summary counts distinct segments', () => {
  const s = summarizeWindow([e('https://v.dk/a.ts', 'XHR', 'video/mp2t', 10), e('https://v.dk/a.ts', 'XHR', 'video/mp2t', 11), e('https://v.dk/b.ts', 'XHR', 'video/mp2t', 12), e('https://x.dk/s.js', 'Script', 'text/javascript', 13)], 0, 100);
  assert.equal(s.segmentCount, 2);
});

test('polling detection requires periodic content endpoint', () => {
  const live = [0, 5000, 10000, 15000].map(t => e(`https://x.dk/api/live/feed?since=${t}`, 'Fetch', 'application/json', t, { bytes: 3000 }));
  assert.equal(detectPolling(live, 'x.dk').detected, true);
  const ga = [0, 5000, 10000, 15000].map(t => e('https://www.google-analytics.com/g/collect', 'Fetch', '', t));
  assert.equal(detectPolling(ga, 'x.dk').detected, false);
});
