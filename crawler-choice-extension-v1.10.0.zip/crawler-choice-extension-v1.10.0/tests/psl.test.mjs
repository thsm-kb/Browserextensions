import test from 'node:test';
import assert from 'node:assert/strict';
import { registrableDomain, publicSuffix, sameRegisteredDomain } from '../lib/psl.js';

test('ICANN suffixes', () => {
  assert.equal(registrableDomain('www.dr.dk'), 'dr.dk');
  assert.equal(registrableDomain('news.bbc.co.uk'), 'bbc.co.uk');
  assert.equal(registrableDomain('a.b.example.com.au'), 'example.com.au');
  assert.equal(publicSuffix('foo.co.uk'), 'co.uk');
});

test('PRIVATE suffixes keep tenants apart (v1.4 leaked across github.io/blogspot/netlify)', () => {
  assert.equal(registrableDomain('alice.github.io'), 'alice.github.io');
  assert.notEqual(registrableDomain('alice.github.io'), registrableDomain('bob.github.io'));
  assert.equal(registrableDomain('x.blogspot.com'), 'x.blogspot.com');
  assert.equal(registrableDomain('site.netlify.app'), 'site.netlify.app');
  assert.equal(sameRegisteredDomain('https://bob.github.io/', 'alice.github.io'), false);
});

test('wildcard and exception rules', () => {
  assert.equal(publicSuffix('foo.bar.kawasaki.jp'), 'bar.kawasaki.jp');   // *.kawasaki.jp
  assert.equal(registrableDomain('www.city.kawasaki.jp'), 'city.kawasaki.jp'); // !city.kawasaki.jp
});

test('IPs, single labels and unknown TLDs', () => {
  assert.equal(registrableDomain('192.168.1.10'), '192.168.1.10');
  assert.equal(registrableDomain('localhost'), 'localhost');
  assert.equal(registrableDomain('a.b.unknowntld'), 'b.unknowntld');
});
