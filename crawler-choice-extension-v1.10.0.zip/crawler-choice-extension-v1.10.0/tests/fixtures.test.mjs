// Replays every fixture in tests/fixtures/. Fixtures use the same shape as the popup's
// "Evidence JSON" export, so a real site's export can be dropped in as a regression case
// (add "expectedDecision" to the file).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';
import { sampleEvidence, aggregate, decide } from '../lib/scoring.js';

const dir = new URL('./fixtures/', import.meta.url);
for (const file of readdirSync(dir).filter(f => f.endsWith('.json'))) {
  const fx = JSON.parse(readFileSync(new URL(file, dir), 'utf8'));
  if (!fx.expectedDecision) continue;
  test(`fixture ${file}`, () => {
    const samples = fx.samples.map(s => ({ url: s.url, role: s.role, evidence: sampleEvidence(s.raw?.ok === undefined ? null : s.raw, s.rendered ? { ...s.rendered, role: s.role } : null, s.ctx || {}) }));
    const agg = aggregate(samples, { sitemapEntries: fx.sitemap?.entries || 0, sectionSamples: fx.samples.filter(s => s.role === 'section').length });
    const final = decide(agg, fx.ai || null);
    assert.equal(final.decision, fx.expectedDecision, JSON.stringify(agg.evidence.map(e => [e.code, e.count])));
    if (fx.expectedCodes) for (const c of fx.expectedCodes) assert.ok(agg.evidence.some(e => e.code === c), `missing ${c}`);
    if (fx.forbiddenCodes) for (const c of fx.forbiddenCodes) assert.ok(!agg.evidence.some(e => e.code === c), `unexpected ${c}`);
  });
}
