import test from 'node:test';
import assert from 'node:assert/strict';
import { decodeXmlEntities, isUnsafeBrowserSampleUrl, mapLimitUntil } from '../lib/util.js';

test('entity decoding is single-pass (v1.4 double-unescaped &amp;lt;)', () => {
  assert.equal(decodeXmlEntities('a&amp;lt;b'), 'a&lt;b');
  assert.equal(decodeXmlEntities('x&amp;y'), 'x&y');
  assert.equal(decodeXmlEntities('&#230;&#xF8;&aring;'), 'æø&aring;');
});

test('file-like URLs are rejected', () => {
  assert.equal(isUnsafeBrowserSampleUrl('https://x.dk/a.pdf'), true);
  assert.equal(isUnsafeBrowserSampleUrl('https://x.dk/a?download=1'), true);
  assert.equal(isUnsafeBrowserSampleUrl('https://x.dk/tag/news/'), false);
});

test('mapLimitUntil stops scheduling after stop', async () => {
  let started = 0;
  const { results, stopped } = await mapLimitUntil([1, 2, 3, 4, 5, 6], 1, async x => { started++; return { value: x, stop: x === 2 }; });
  assert.equal(stopped, true);
  assert.deepEqual(results, [1, 2]);
  assert.equal(started, 2);
});
