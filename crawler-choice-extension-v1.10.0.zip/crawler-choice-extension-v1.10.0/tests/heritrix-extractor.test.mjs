// Behaviour of the Heritrix 3.14.1 emulation not covered by Heritrix's own unit tests
// (see heritrix-oracle.test.mjs), plus the raw comparison basis and its effect on scoring.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  HeritrixUrlExtractor, HeritrixUriUtils as U, extractHeritrixOutlinks, heritrixAbsoluteUrls,
  unescapeHtml4, unescapeEcmaScript, HERITRIX_DEFAULTS,
} from '../lib/heritrix-extractor.js';
import { buildRawBasis } from '../lib/raw-basis.js';
import { sampleEvidence } from '../lib/scoring.js';
import { raw, rendered, links } from './helpers.mjs';

const DOC = 'https://example.dk/a/b/page.html';
const rec = (html, url = DOC, cfg) => extractHeritrixOutlinks(html, url, cfg).outlinks;
const byUrl = (html, url, cfg) => Object.fromEntries(rec(html, url, cfg).map(o => [o.absoluteUrl, o]));

test('guide §21 examples: relative, protocol-relative, base', () => {
  const r = byUrl('<img src="../img/test.jpg"><script src="//cdn.example.com/x.js"></script><base href="https://static.example.dk/foo/"><a href="later.html">x</a>');
  assert.ok(r['https://example.dk/a/img/test.jpg']);
  assert.ok(r['https://cdn.example.com/x.js'], 'scheme inherited from the document');
  assert.equal(r['https://static.example.dk/foo/later.html'].baseUrlUsed, 'https://static.example.dk/foo/');
});

test('source order: links before <base> keep the document URL; the first BASE wins; BASE href is itself a link', () => {
  const r = byUrl('<a href="x.html">1</a><base href="/b1/"><base href="/b2/"><a href="y.html">2</a>');
  assert.equal(r['https://example.dk/a/b/x.html'].baseUrlUsed, DOC);
  assert.ok(r['https://example.dk/b1/y.html']);
  assert.equal(r['https://example.dk/b1/'].context, 'base/@href');
  assert.equal(r['https://example.dk/b1/'].hop, 'L');
  assert.ok(!r['https://example.dk/b2/y.html']);
});

test('records carry the required fields', () => {
  const [o] = rec('<img src="../image.jpg">');
  for (const k of ['rawValue', 'absoluteUrl', 'baseUrlUsed', 'sourceType', 'element', 'attribute', 'context', 'hopType', 'hop', 'extractor', 'speculative']) assert.ok(k in o, k);
  assert.deepEqual([o.rawValue, o.absoluteUrl, o.context, o.hopType, o.hop, o.extractor, o.speculative], ['../image.jpg', 'https://example.dk/a/image.jpg', 'img/@src', 'EMBED', 'E', 'ExtractorHTML', false]);
});

test('hop types and contexts', () => {
  const r = byUrl(`<a href="/nav">n</a><iframe src="/frame"></iframe><meta http-equiv="refresh" content="0; URL='/moved'">
    <script>var u = '/api/items.json';</script><a href="javascript:go('/via/js.html')">j</a><div onclick="load('/on/click.html')"></div>`);
  assert.deepEqual([r['https://example.dk/nav'].hop, r['https://example.dk/frame'].hop, r['https://example.dk/moved'].hop], ['L', 'E', 'R']);
  for (const u of ['https://example.dk/api/items.json', 'https://example.dk/via/js.html', 'https://example.dk/on/click.html']) {
    assert.deepEqual([r[u].hop, r[u].context, r[u].extractor, r[u].speculative], ['X', '=JS_MISC', 'ExtractorJS', true], u);
  }
  assert.equal(byUrl('<iframe src="/frame"></iframe>', DOC, { treatFramesAsEmbedLinks: false })['https://example.dk/frame'].hop, 'L');
});

test('[3.14.1] quirks are reproduced', () => {
  // A[data-remote=true]: first HREF is delayed and emitted as NAVLINK with the special context
  const dr = byUrl('<a data-remote="true" href="/remote">x</a>')['https://example.dk/remote'];
  assert.deepEqual([dr.hop, dr.context], ['L', "a[data-remote='true']/@href"]);
  // LINK without REL yields nothing; imagesrcset is never reached
  assert.deepEqual(rec('<link href="/norel.css"><link rel="preload" imagesrcset="/a.jpg 1x" href="/p.jpg">').map(o => o.absoluteUrl), ['https://example.dk/p.jpg']);
  // '>' inside an attribute value ends the tag: the following href is lost
  assert.equal(rec('<a title="a>b" href="/lost">x</a>').length, 0);
  // comments skipped, conditional comments scanned
  assert.deepEqual(rec('<!-- <a href="/c1">x</a> --><!--[if IE]><a href="/c2">y</a><![endif]-->').map(o => o.absoluteUrl), ['https://example.dk/c2']);
  // <style> element text is not HTML-unescaped. Quoted url(): "&amp" -> "&" leaves "&;".
  // Unquoted url(): the lazy CSS pattern already stops at the first ';' (truncated URL).
  assert.ok(byUrl("<style>.x{background:url('/q?a=1&amp;b=2')}</style>")['https://example.dk/q?a=1&;b=2']);
  assert.ok(byUrl('<style>.x{background:url(/q?a=1&amp;b=2)}</style>')['https://example.dk/q?a=1&']);
  assert.ok(byUrl('<div style="background:url(/q?a=1&amp;b=2)"></div>')['https://example.dk/q?a=1&b=2']);
  // META content: tested after speculativeFixup, but the unfixed value is added (relative!)
  assert.ok(byUrl('<meta name="x" content="example.com/foo">')['https://example.dk/a/b/example.com/foo']);
  // OBJECT resources resolve against CODEBASE, which resolves against the document URI (not the base)
  const ob = byUrl('<base href="https://static.example.dk/"><object codebase="/applets/" data="movie.swf" archive="a.jar  b.jar"></object>');
  assert.ok(ob['https://static.example.dk/applets/'], 'codebase itself is a NAVLINK against the base');
  for (const f of ['movie.swf', 'a.jar', 'b.jar']) assert.equal(ob[`https://example.dk/applets/${f}`].context, 'object');
  assert.ok(byUrl('<applet code="Foo"></applet>')['https://example.dk/a/b/Foo.class']);
});

test('forms, VALUE and FLASHVARS heuristics', () => {
  const r = byUrl(`<form action="/get"><input type="hidden" value="/next/page.html"><input value="Søg"><input value="1.2"></form>
    <form action="/post" method="POST"></form><embed flashvars="file=%2Fv%2Fclip.mp4&amp;t=Hej&x">`);
  assert.ok(r['https://example.dk/get']);
  assert.ok(!r['https://example.dk/post']);
  assert.equal(r['https://example.dk/next/page.html'].speculative, true);
  assert.equal(r['https://example.dk/v/clip.mp4'].hop, 'X');
  assert.equal(Object.keys(r).length, 3);
  assert.ok(byUrl('<form action="/post" method="post"></form>', DOC, { extractOnlyFormGets: false })['https://example.dk/post']);
  assert.equal(rec('<form action="/get"></form>', DOC, { ignoreFormActionUrls: true }).length, 0);
  assert.equal(rec('<input value="/x/y.html">', DOC, { extractValueAttributes: false }).length, 0);
});

test('meta robots nofollow follows the configuration', () => {
  const html = '<meta name="robots" content="noindex, nofollow"><a href="/x">x</a>';
  assert.equal(rec(html).length, 0, 'Heritrix default policy obeys it');
  assert.equal(rec(html, DOC, { obeyMetaRobotsNofollow: false }).length, 1);
});

test('JS strings: Heritrix false-positive filters', () => {
  const urls = [...heritrixAbsoluteUrls(`<script>
    var a='text/xml', b='application/json', c='1.2.3', d='div.menu', e='a.help', f='image/png', g='foo.bar.baz', h='.x.js',
        ok1='/photos/', ok2='../../foo/bar.html', ok3='foo/bar', ok4='jquery.min.js', ok5='//cdn.example.com/lib.js';
  </script>`, DOC)].sort();
  assert.deepEqual(urls, ['https://cdn.example.com/lib.js', 'https://example.dk/a/b/foo/bar', 'https://example.dk/a/b/jquery.min.js', 'https://example.dk/foo/bar.html', 'https://example.dk/photos/']);
});

test('speculativeFixup: 2010 TLD list and same-host scheme', () => {
  assert.equal(U.speculativeFixup('example.com/foo', DOC), 'http://example.com/foo');
  assert.equal(U.speculativeFixup('example.dk/foo', DOC), 'https://example.dk/foo', 'same host keeps https');
  assert.equal(U.speculativeFixup('shop.example.shop/x', DOC), 'shop.example.shop/x', '.shop is not in the 2010 list');
  assert.equal(U.speculativeFixup('a?b=1&amp;c=2', DOC), 'a?b=1&c=2');
  assert.equal(U.speculativeFixup('https%3A%2F%2Fexample.org%2Fa%20b', DOC), 'https://example.org/a b');
});

test('isVeryLikelyUri / isPossibleUri edge cases', () => {
  assert.equal(U.isPossibleUri('abc'), false);
  assert.equal(U.isPossibleUri('<a>.b'), false);
  assert.equal(U.isVeryLikelyUri('https://x.dk'), true);
  assert.equal(U.isVeryLikelyUri('https://localhost/x'), false, 'needs a dot in the authority');
  assert.equal(U.isVeryLikelyUri('/a b/c.html'), true, 'whitespace allowed with a known-good extension');
  assert.equal(U.isVeryLikelyUri('/a b/c'), false);
  assert.equal(U.isVeryLikelyUri('video/mp4'), false);
});

test('unescaping (Commons Lang semantics)', () => {
  assert.equal(unescapeHtml4('&aring;&oslash;&aelig; &amp; &#229; &#xE5; &amp &apos; &bogus;'), 'åøæ & å å &amp &apos; &bogus;');
  assert.equal(unescapeEcmaScript('\\u002fa\\/b\\x\\101\\n'), '/a/bxA\n');
  assert.throws(() => unescapeEcmaScript('\\u00zz'));
});

test('UURIFactory fixups', () => {
  const r = (x, b = DOC) => U.resolve(x, b).url ?? U.resolve(x, b).error;
  assert.equal(r('  \u00a0/x y\t\n '), 'https://example.dk/x%20y');
  assert.equal(r('a\\b\\c.html?q=a\\b'), 'https://example.dk/a/b/a/b/c.html?q=a\\b');
  assert.equal(r('https:////example.org//x'), 'https://example.org//x');
  assert.equal(r('https:rel.html'), 'https://example.dk/a/b/rel.html', 'same scheme: treated as relative');
  assert.equal(r('http:rel.html'), 'scheme-relative-mismatch');
  assert.equal(r('https://.Example.ORG./x#frag'), 'https://example.org/x');
  assert.equal(r(`/${'x'.repeat(2100)}`), 'uri-too-long');
  assert.equal(r('mailto:post@example.dk'), 'mailto:post@example.dk');
});

test('data: URIs and the outlink limit (duplicates count, as in Heritrix)', () => {
  assert.equal(rec('<img src="data:image/png;base64,AAA"><img src=" DATA:x">').length, 0);
  const x = new HeritrixUrlExtractor(DOC, { maxOutlinks: 3 });
  const res = x.extractHtml('<a href="/1">a</a><a href="/1">b</a><a href="/2">c</a><a href="/3">d</a>');
  assert.deepEqual(res.discoveries.map(d => d.url), ['https://example.dk/1', 'https://example.dk/1', 'https://example.dk/2']);
  assert.equal(res.outlinks.length, 2);
  assert.equal(res.stats.discarded, 1);
  assert.equal(res.outlinks[0].occurrences, 2);
  assert.equal(HERITRIX_DEFAULTS.maxOutlinks, 6000);
});

test('over-long attribute values are skipped whole (maxAttributeValLength)', () => {
  const long = `/x/${'a'.repeat(2100)}`;
  assert.equal(rec(`<a title="${long}" href="/ok">x</a>`).map(o => o.absoluteUrl).join(), 'https://example.dk/ok');
  assert.equal(rec(`<a href="${long}">x</a>`).length, 0);
});

test('standalone JS resolves against the via URI, falling back to the base', () => {
  const via = new HeritrixUrlExtractor('https://cdn.example.dk/js/app.js', {}, { viaUrl: 'https://example.dk/section/page.html' });
  assert.equal(via.processStandaloneJavascript("var a = 'img/x.png';").outlinks[0].absoluteUrl, 'https://example.dk/section/img/x.png');
  const noVia = new HeritrixUrlExtractor('https://cdn.example.dk/js/app.js');
  assert.equal(noVia.processStandaloneJavascript("var a = 'img/x.png';").outlinks[0].absoluteUrl, 'https://cdn.example.dk/js/img/x.png');
  const inline = byUrl('<base href="https://cdn.example.dk/js/"><script>var a = "img/x.png";</script>');
  assert.ok(inline['https://cdn.example.dk/js/img/x.png'], 'inline JS uses the current base');
});

test('robustness: hostile and large input', () => {
  const html = `<a href="/x">${'<'.repeat(20000)}</a><script>${'"a/b",'.repeat(20000)}</script><a href="/y">`;
  const t0 = Date.now();
  const res = extractHeritrixOutlinks(html, DOC);
  const r = Object.fromEntries(res.outlinks.map(o => [o.absoluteUrl, o]));
  assert.ok(Date.now() - t0 < 5000, 'linear-ish time');
  assert.ok(r['https://example.dk/x'] && r['https://example.dk/a/b/a/b']);
  // 20 000 duplicate JS strings fill the 6000-outlink collection, so — as in Heritrix — the later link is discarded
  assert.ok(!r['https://example.dk/y']);
  assert.equal(res.stats.discovered, 6000);
  assert.ok(res.stats.discarded > 10000);
  assert.deepEqual(rec(''), []);
  assert.deepEqual(rec(null), []);
});

// ---------------------------------------------------------------------------------------------
// Raw comparison basis
// ---------------------------------------------------------------------------------------------

test('buildRawBasis: set = all same-site hops, count = page-like ones', () => {
  const html = `<link rel="stylesheet" href="/s.css"><script src="/app.js"></script><img src="/i.jpg">
    <a href="/one">1</a><a href="/two">2</a><a href="https://other.example.org/x">ext</a><a href="mailto:a@b.dk">m</a>
    <script>var api = '/api/list.json', page = '/three', img = '/pics/p.png';</script><a title="a>b" href="/hidden">h</a>`;
  const result = extractHeritrixOutlinks(html, 'https://www.example.dk/');
  const basis = buildRawBasis(result, { rootDomain: 'example.dk', documentUrl: 'https://www.example.dk/', domAnchors: ['https://www.example.dk/one', 'https://www.example.dk/two', 'https://www.example.dk/hidden', 'https://other.example.org/x'] });
  assert.deepEqual(basis.links.sort(), ['/s.css', '/app.js', '/i.jpg', '/one', '/two', '/api/list.json', '/three', '/pics/p.png'].map(p => `https://www.example.dk${p}`).sort());
  assert.equal(basis.navigableCount, 3, '/one, /two (L) and /three (X, not an asset)');
  assert.deepEqual(basis.summary.byHop, { L: 2, E: 3, R: 0, X: 3 });
  assert.equal(basis.summary.nonHttpOutlinks, 1);
  assert.equal(basis.summary.domAnchorInternal, 3);
  assert.equal(basis.summary.domAnchorsMissedByHeritrix, 1, 'the href lost after title="a>b"');
  assert.equal(basis.records[0].hop, 'E');
});

test('scoring: URLs Heritrix finds in inline JS are not counted as "JS-generated"', () => {
  // The rendered page shows 60 links that the raw HTML only has as strings in a JSON/script block.
  const jsLinks = links('artikel', 60);
  const domOnly = raw({ links: [], internalLinkCount: 0 });                     // a DOM link scraper's view
  const heritrixView = raw({ links: jsLinks, internalLinkCount: 60 });         // what Heritrix discovers
  const r = rendered({ rawLinks: jsLinks });
  const codes = ev => ev.codes.map(c => c.code);
  assert.ok(codes(sampleEvidence(domOnly, r)).includes('JS_GENERATED_LINKS'));
  assert.ok(!codes(sampleEvidence(heritrixView, r)).includes('JS_GENERATED_LINKS'));
});
