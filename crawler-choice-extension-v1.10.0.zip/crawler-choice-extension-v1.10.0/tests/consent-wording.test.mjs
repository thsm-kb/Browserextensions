import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

// probe/consent.js is a classic content script; evaluate it in a sandbox and use its test hooks.
const ctx = vm.createContext({});
vm.runInContext(readFileSync(new URL('../probe/consent.js', import.meta.url), 'utf8'), ctx);
const { classifyLabel, normalizeLabel, PHRASES, CMP_RULES } = ctx.__ccConsent._test;

test('Danish and Nordic accept/reject labels', () => {
  for (const l of ['Accepter alle', 'Acceptér alle cookies', 'Tillad alle', 'Godkend alle', 'OK til alle', 'Godta alle', 'Acceptera alla']) assert.equal(classifyLabel(l), 'accept', l);
  for (const l of ['Afvis alle', 'Kun nødvendige', 'Tillad kun nødvendige cookies', 'Accepter kun nødvendige', 'Nej tak', 'Tillad valgte', 'Avvis alle', 'Endast nödvändiga']) assert.equal(classifyLabel(l), 'reject', l);
});

test('other European languages', () => {
  assert.equal(classifyLabel('Alle akzeptieren'), 'accept');
  assert.equal(classifyLabel('Nur notwendige Cookies'), 'reject');
  assert.equal(classifyLabel('Tout refuser'), 'reject');
  assert.equal(classifyLabel('Hyväksy kaikki'), 'accept');
  assert.equal(classifyLabel('Alles weigeren'), 'reject');
});

test('normalisation: case, whitespace, punctuation, arrows', () => {
  assert.equal(normalizeLabel('  ACCEPTER\n  ALLE ›'), 'accepter alle');
  assert.equal(classifyLabel('“Afvis alle”.'), 'reject');
  assert.equal(classifyLabel('✓ Tillad alle'), 'accept');
});

test('exact matching only: longer or unrelated labels do not count', () => {
  assert.equal(classifyLabel('Accepter alle vilkår for medlemskab'), '');
  assert.equal(classifyLabel('Læs mere om cookies'), '');
  assert.equal(classifyLabel('Indstillinger'), '');
  assert.equal(classifyLabel(''), '');
  assert.equal(classifyLabel('x'.repeat(80)), '');
});

test('notice labels are separate from accept/reject', () => {
  for (const l of ['OK', 'Forstået', 'Luk', 'Got it', '×']) assert.equal(classifyLabel(l), 'notice', l);
});

test('phrase lists are disjoint and CMP rules are well-formed', () => {
  const a = new Set(PHRASES.accept), r = new Set(PHRASES.reject), n = new Set(PHRASES.notice);
  for (const p of a) { assert.ok(!r.has(p), `accept/reject overlap: ${p}`); assert.ok(!n.has(p), `accept/notice overlap: ${p}`); }
  for (const p of r) assert.ok(!n.has(p), `reject/notice overlap: ${p}`);
  for (const p of [...a, ...r, ...n]) assert.equal(normalizeLabel(p), p, `phrase not normalised: ${p}`);
  const ids = new Set();
  for (const rule of CMP_RULES) {
    assert.ok(rule.id && rule.root, 'id and root required');
    assert.ok(!ids.has(rule.id), `duplicate rule ${rule.id}`);
    ids.add(rule.id);
  }
  for (const id of ['cookiebot', 'cookie-information', 'onetrust', 'usercentrics', 'didomi', 'sourcepoint']) assert.ok(ids.has(id), id);
});
