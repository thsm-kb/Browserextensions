import test from 'node:test';
import assert from 'node:assert/strict';
import { parseSitemapXml, parsePlainTextSitemap, parseRobots, robotsAllows } from '../lib/sitemaps.js';

test('urlset with CDATA, entities, namespace prefix and image:loc', () => {
  const xml = `<?xml version="1.0"?><ns0:urlset xmlns:ns0="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
    <ns0:url><ns0:loc><![CDATA[https://example.dk/a?x=1&y=2]]></ns0:loc><image:image><image:loc>https://cdn.example.dk/i.jpg</image:loc></image:image></ns0:url>
    <ns0:url><ns0:loc>https://example.dk/b?p=1&amp;q=2</ns0:loc><ns0:lastmod>2026-01-01</ns0:lastmod></ns0:url>
    <!-- <ns0:url><ns0:loc>https://example.dk/commented</ns0:loc></ns0:url> -->
  </ns0:urlset>`;
  const r = parseSitemapXml(xml, 'https://example.dk/sitemap.xml');
  assert.equal(r.type, 'urlset');
  assert.deepEqual(r.entries.map(e => e.url), ['https://example.dk/a?x=1&y=2', 'https://example.dk/b?p=1&q=2']);
  assert.equal(r.entries[1].lastmod, '2026-01-01');
});

test('sitemap index', () => {
  const r = parseSitemapXml('<sitemapindex><sitemap><loc>/s1.xml</loc></sitemap></sitemapindex>', 'https://example.dk/');
  assert.equal(r.type, 'index');
  assert.equal(r.entries[0].url, 'https://example.dk/s1.xml');
});

test('plain-text sitemap', () => {
  const r = parsePlainTextSitemap('https://example.dk/a\n# c\nhttps://example.dk/b\n', 'https://example.dk/sitemap.txt', 'text/plain');
  assert.equal(r.entries.length, 2);
});

test('robots.txt groups and longest-match', () => {
  const txt = 'User-agent: Googlebot\nDisallow: /\n\nUser-agent: *\nDisallow: /private/\nAllow: /private/open/\nSitemap: https://example.dk/sm.xml\n';
  const r = parseRobots(txt, 'https://example.dk');
  assert.deepEqual(r.sitemaps, ['https://example.dk/sm.xml']);
  assert.equal(robotsAllows(r.rules, 'https://example.dk/private/x'), false);
  assert.equal(robotsAllows(r.rules, 'https://example.dk/private/open/x'), true);
  assert.equal(robotsAllows(r.rules, 'https://example.dk/news'), true);
});
