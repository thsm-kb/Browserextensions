import test from 'node:test';
import assert from 'node:assert/strict';
import { chooseSamples } from '../lib/samples.js';

test('listing pages from rendered navigation are sampled; robots rules respected', () => {
  const nav = ['https://example.dk/nyheder/', 'https://example.dk/tag/politik', 'https://example.dk/om', 'https://example.dk/private/x'];
  const entries = Array.from({ length: 30 }, (_, i) => ({ url: `https://example.dk/nyheder/artikel-${i}`, lastmod: '2026-05-01' }));
  const s = chooseSamples({ entries, sitemapPools: [], currentUrl: 'https://example.dk/', renderedLinks: nav, rootDomain: 'example.dk', max: 7, robotsRules: [{ allow: false, path: '/private/' }] });
  assert.ok(s.some(x => x.role === 'listing'), JSON.stringify(s));
  assert.ok(!s.some(x => x.url.includes('/private/')));
  assert.equal(s[0].role, 'front-page+current-page');
  assert.ok(s.length <= 7);
});

test('other github.io tenants are never sampled', () => {
  const s = chooseSamples({ entries: [{ url: 'https://bob.github.io/x/y' }], currentUrl: 'https://alice.github.io/', renderedLinks: [], rootDomain: 'alice.github.io', max: 5 });
  assert.ok(s.every(x => x.url.startsWith('https://alice.github.io/')));
});
