import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSettings } from '../lib/settings.js';
import { browsertrixYaml, heritrixSeeds } from '../lib/export.js';

test('default scope is the whole site', () => {
  const s = normalizeSettings({});
  assert.equal(s.testScope, 'site');
  assert.equal(s.sampleCount, 7);
  assert.equal(s.earlyExit, true);
});

test('page scope forces one sample and disables site-only options', () => {
  const s = normalizeSettings({ testScope: 'page', sampleCount: 15, respectRobots: true, earlyExit: true });
  assert.deepEqual([s.testScope, s.sampleCount, s.respectRobots, s.earlyExit], ['page', 1, false, false]);
  assert.equal(normalizeSettings({ testScope: 'bogus' }).testScope, 'site');
});

test('page-scope exports seed only the analysed URL', () => {
  const bundle = {
    version: '1.5.1', generatedAt: '2026-10-01T00:00:00Z', settings: { testScope: 'page' },
    site: { url: 'https://example.dk/nyheder/a', origin: 'https://example.dk', host: 'example.dk', subdomainsSeen: false },
    decision: { decision: 'Browsertrix', confidence: 'high', path: 'decisive-measured-signal' },
    aggregate: { evidence: [{ side: 'Browsertrix', code: 'SCROLL_DISCOVERS_LINKS' }] },
    samples: [], warnings: [], sitemap: { documents: ['https://example.dk/sitemap.xml'], robotsSitemaps: [] },
  };
  const yaml = browsertrixYaml(bundle);
  assert.match(yaml, /url: "https:\/\/example\.dk\/nyheder\/a"/);
  assert.match(yaml, /scopeType: page/);
  // v1.7: the file may end with commented scope notes; the only seed is still the analysed URL.
  assert.deepEqual(heritrixSeeds(bundle).split('\n').filter(l => l && !l.startsWith('#')), ['https://example.dk/nyheder/a']);
});
