import { test } from 'node:test';
import assert from 'node:assert/strict';
import { browserUrlsOf, compareUniqueUrls, urlComparisonLines } from '../lib/url-comparison.js';
import { normalizeSettings, DEFAULT_SETTINGS, SETTINGS_VERSION } from '../lib/settings.js';

const R = 'example.dk';

test('browserUrlsOf: DOM links of all phases + requested URLs, same-site, fragment-free', () => {
  const rendered = {
    load: { links: ['https://www.example.dk/a', 'https://www.example.dk/a#top', 'https://other.org/x'], shadowLinks: ['https://www.example.dk/shadow'] },
    baseline: { dom: { newLinks: ['https://www.example.dk/ticker'] } },
    scroll: { dom: { newLinks: ['https://www.example.dk/more/1', 'https://www.example.dk/more/2'] } },
    clicks: [{ dom: { newLinks: ['https://www.example.dk/tab'] } }],
    menus: [{ dom: { newLinks: ['https://www.example.dk/menu/1'] } }, { error: 'x' }],
    requestLog: [
      { url: 'https://www.example.dk/' }, { url: 'https://cdn.example.dk/app.js' }, { url: 'https://api.example.dk/list.json' },
      { url: 'https://www.google-analytics.com/g' }, { url: 'https://www.example.dk/blocked', blocked: true }, { url: 'data:image/png;base64,AA' },
    ],
    autofetch: ['https://www.example.dk/img/a-800.jpg', 'https://www.example.dk/img/a-1600.jpg#x', 'https://cdn.other.org/i.jpg'],
  };
  const r = browserUrlsOf(rendered, R);
  assert.deepEqual(r.links.sort(), ['/a', '/menu/1', '/more/1', '/more/2', '/shadow', '/tab', '/ticker'].map(p => `https://www.example.dk${p}`).sort());
  assert.deepEqual(r.requests.sort(), ['https://api.example.dk/list.json', 'https://cdn.example.dk/app.js', 'https://www.example.dk/']);
  assert.deepEqual(r.srcset.sort(), ['https://www.example.dk/img/a-1600.jpg', 'https://www.example.dk/img/a-800.jpg']);
  assert.deepEqual(browserUrlsOf(null, R), { links: [], requests: [], srcset: [] });
});

test('compareUniqueUrls: union across samples, overlap and differences', () => {
  const c = compareUniqueUrls([
    { heritrix: ['https://x.dk/a', 'https://x.dk/b', 'https://x.dk/app.js', 'https://x.dk/spec'], browserLinks: ['https://x.dk/a', 'https://x.dk/c'], browserRequests: ['https://x.dk/app.js', 'https://x.dk/api.json'] },
    { heritrix: ['https://x.dk/a', 'https://x.dk/d#frag'], browserLinks: ['https://x.dk/d', 'https://x.dk/c', 'https://x.dk/e'], browserRequests: [] },
  ]);
  assert.deepEqual(
    [c.samples, c.browser, c.heritrix, c.both, c.browserOnly, c.heritrixOnly, c.browserLinks, c.browserRequests, c.browserOnlyLinks],
    [2, 6, 5, 3, 3, 2, 4, 2, 2]);
  assert.deepEqual(c.examples.browserOnly, ['https://x.dk/api.json', 'https://x.dk/c', 'https://x.dk/e']);
  assert.deepEqual(c.examples.heritrixOnly, ['https://x.dk/b', 'https://x.dk/spec']);
});

test('srcset counts on the browser side; Heritrix-only splits into attributes vs speculative', () => {
  const c = compareUniqueUrls([
    { heritrix: ['https://x.dk/a', 'https://x.dk/img-1x.jpg', 'https://x.dk/spec1', 'https://x.dk/spec2', 'https://x.dk/attr-only'],
      heritrixSpeculative: ['https://x.dk/spec1', 'https://x.dk/spec2'],
      browserLinks: ['https://x.dk/a'], browserRequests: [], browserSrcset: ['https://x.dk/img-1x.jpg', 'https://x.dk/img-2x.jpg'] },
    // spec2 is found in an ordinary attribute on another sample -> not speculative overall
    { heritrix: ['https://x.dk/spec2'], heritrixSpeculative: [], browserLinks: [], browserRequests: [], browserSrcset: [] },
  ]);
  assert.deepEqual([c.browser, c.heritrix, c.both, c.browserOnly, c.browserOnlySrcset, c.heritrixOnly, c.heritrixOnlyFromAttributes, c.heritrixOnlySpeculative],
    [3, 5, 2, 1, 1, 3, 2, 1]);
  assert.deepEqual(c.pool, ['https://x.dk/spec1']);
});

const C = { samples: 10, browser: 307, heritrix: 404, both: 88, browserOnly: 219, browserOnlyLinks: 2, browserOnlySrcset: 40, heritrixOnly: 316, heritrixOnlyFromAttributes: 186, heritrixOnlySpeculative: 130 };

test('report lines without a URL check', () => {
  const [a, b] = urlComparisonLines(C, { skipped: 'off in settings' });
  assert.equal(a, 'Unique same-site URLs found (10 samples tested both ways): browser 307 · Heritrix 404 (−97 for Heritrix)');
  assert.equal(b, 'Of these: 88 found by both · 219 only by the browser (2 page links, 40 srcset) · 316 only by Heritrix = 186 from HTML attributes + 130 speculative (URL check: off in settings).');
  assert.deepEqual(urlComparisonLines({ samples: 0 }), []);
  assert.deepEqual(urlComparisonLines(null), []);
});

test('report lines with an estimated URL check', () => {
  const check = { estimate: { tested: 60, fictive: 38, live: 20, unknown: 2, decided: 58, share: 38 / 58, estimate: 85, low: 72, high: 97, exact: false } };
  const [a, b] = urlComparisonLines(C, check);
  assert.equal(a, 'Unique same-site URLs found (10 samples tested both ways): browser 307 · Heritrix 404 → ~319 real after removing estimated fictive URLs (range 307–332) (−12 for Heritrix)');
  assert.match(b, /= 186 from HTML attributes \+ 130 speculative; URL check of 60 speculative: 38 fictive, 20 live, 2 unknown → ~66 % fictive\.$/);
});

test('report lines with an exact URL check (whole pool tested)', () => {
  const check = { estimate: { tested: 3, fictive: 2, live: 1, unknown: 0, decided: 3, share: 2 / 3, estimate: 2, low: 2, high: 2, exact: true } };
  const [a, b] = urlComparisonLines({ ...C, heritrixOnlySpeculative: 3 }, check);
  assert.match(a, /Heritrix 404 → 402 real after removing fictive URLs \(−95 for Heritrix\)$/);
  assert.match(b, /URL check of 3 speculative: 2 fictive, 1 live, 0 unknown\.$/);
});

test('Gemini Nano is off by default; pre-v1.9 settings are migrated once', () => {
  assert.equal(DEFAULT_SETTINGS.useAi, false);
  assert.equal(normalizeSettings({}).useAi, false);
  assert.equal(normalizeSettings({ useAi: true }).useAi, false, 'old saved settings: useAi was only the old default');
  assert.equal(normalizeSettings({ useAi: true, settingsVersion: SETTINGS_VERSION }).useAi, true, 'explicit choice since v1.9 is kept');
  assert.equal(normalizeSettings({ useAi: false, settingsVersion: SETTINGS_VERSION }).useAi, false);
  assert.equal(normalizeSettings({ useAi: 'yes', settingsVersion: SETTINGS_VERSION }).useAi, false, 'only a real true enables it');
});
