import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isConsentRequest } from '../lib/consent-guard.js';

test('known CMP endpoints are allowed during consent handling', () => {
  assert.equal(isConsentRequest('https://consent.cookiebot.com/logconsent.ashx', 'x.dk'), true);
  assert.equal(isConsentRequest('https://policy.app.cookieinformation.com/api/consent', 'x.dk'), true);
  assert.equal(isConsentRequest('https://cdn.privacy-mgmt.com/wrapper/v2/choice/consent-all', 'x.dk'), true);
  assert.equal(isConsentRequest('https://fundingchoicesmessages.google.com/a/consent', 'x.dk'), true);
});

test('same-site requests pass only when they are about consent', () => {
  assert.equal(isConsentRequest('https://www.x.dk/api/consent', 'x.dk'), true);
  assert.equal(isConsentRequest('https://cmp.x.dk/v2/choice', 'x.dk'), true);
  assert.equal(isConsentRequest('https://www.x.dk/wp-admin/admin-ajax.php', 'x.dk', 'action=cmplz_track_status&consented=1'), true);
  assert.equal(isConsentRequest('https://www.x.dk/api/comments', 'x.dk', '{"text":"hej"}'), false);
  assert.equal(isConsentRequest('https://www.x.dk/newsletter/subscribe', 'x.dk', 'email=a@b.dk'), false);
});

test('other third parties and odd URLs are refused', () => {
  assert.equal(isConsentRequest('https://evil.example/consent', 'x.dk'), false);
  assert.equal(isConsentRequest('https://www.google-analytics.com/g/collect', 'x.dk'), false);
  assert.equal(isConsentRequest('data:text/plain,consent', 'x.dk'), false);
  assert.equal(isConsentRequest('not a url', 'x.dk'), false);
  assert.equal(isConsentRequest('https://cookiebot.com.evil.example/x', 'x.dk'), false);
});
