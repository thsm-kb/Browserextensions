# Changelog

## 1.10.0
- **URL check** (`lib/url-check.js`, setting *Check Heritrix's speculative URLs*, on by default): the
  speculative Heritrix-only URLs (found only by JS-string, meta, value or flashvars heuristics) are
  sampled (seeded per site, up to 60) and probed with polite HEAD requests (GET ≤4 KB if HEAD is refused;
  never with cookies; same per-host queue; robots-aware; 45 s cap). A control probe with a made-up URL
  per host learns how the site answers "not found" (404, redirect home, soft-404 200, blocked); verdicts
  are live / fictive / unknown; the fictive share is extrapolated with a Wilson 95 % range and
  finite-population correction (exact when the whole pool was tested).
- **Short report:** two lines under the recommendation — browser total vs Heritrix total and Heritrix
  with estimated fictive URLs removed; then found by both / only by the browser (page links, srcset) /
  only by Heritrix split into "from HTML attributes" and "speculative", with the URL-check result.
- **Popup:** new *Checked URLs* box listing the control probes and every tested URL with verdict,
  HTTP status and redirect target. Evidence JSON: `urlCheck` (controls, results, estimate).
- **Browser side includes srcset:** an emulation of browsertrix-behaviors' `autofetcher` (same selector,
  shadow DOM, srcset/data-srcset split with its regex, data-src, src with srcset or in noscript),
  collected after load and after all interaction (`rendered.autofetch`).
- Tests: 163 (+ jsdom tests for autofetch).

## 1.9.0
- **Short report:** directly under the recommendation, a line compares the unique same-site URLs found
  by the browser with those the Heritrix emulation finds, over all samples tested both ways — totals,
  difference, found by both, only by the browser (and how many of those are page links), only by Heritrix.
  Browser side = DOM links of the load snapshot, open shadow roots and every interaction phase, plus every
  URL the browser requested; Heritrix side = every outlink of the emulation (any hop). Evidence JSON:
  `urlComparison` with up to 100 example URLs per "only" side (`lib/url-comparison.js`).
- **Gemini Nano is off by default.** Settings now carry `settingsVersion` 2; settings saved by earlier
  versions are reset to Gemini-off once, because their stored value was only the old default.
- **Guide:** close button (×, top right; also Esc), via `guide.js` because MV3 pages cannot run inline
  scripts. Guide text updated (settings table, unique-URL totals).
- Tests: 150.

## 1.8.0
- **Raw side = Heritrix 3.14.1.** The raw HTML of every sample is no longer reduced to a DOM
  `<a href>` scan. Its URLs come from a port of Heritrix 3.14.1's own link extraction
  (`lib/heritrix-extractor.js`): `ExtractorHTML` with Heritrix's regular expressions in source order
  (first `<base>` only affects later links), inline `ExtractorJS` (quoted strings, `unescapeEcmaScript`,
  `speculativeFixup` with the 2010 TLD list, `isVeryLikelyUri`) and `ExtractorCSS.processStyleCode`,
  link-rel rules, srcset splitting, GET-only form actions, object/applet codebase, meta refresh and
  speculative meta content, value/flashvars heuristics, `UsableURIFactory` fixups, `data:` exclusion and
  `maxOutlinks` 6000 (duplicates counted, as in Heritrix). Records carry rawValue, absoluteUrl,
  baseUrlUsed, sourceType, element, attribute, context, hopType/hop, extractor and speculative;
  `heritrixAbsoluteUrls()` returns only the URLs. Standalone `.js` mode (via URI) is included.
  Where the 3.14.1 code differs from common descriptions, the code is followed and commented.
- Data tables generated from the Heritrix / webarchive-commons 3.0.3 sources (`lib/heritrix-data.js`).
- **Comparison basis** (`lib/raw-basis.js`): membership uses all same-site Heritrix outlinks (any hop);
  counts use page-like ones (L, R, and speculative non-assets), comparable with rendered `<a href>`.
  "Discoverable in the raw HTML" for runtime-only resources is now the same Heritrix set.
- Meta robots nofollow follows the *Respect robots.txt* setting.
- Report line describing the basis per run; evidence JSON per sample: `raw.heritrix` summary and up to
  400 `raw.heritrixOutlinks` records; new numeric features for Gemini Nano.
- Guide: new section *Comparison basis* (raw side, rendered side, how they are compared, limits).
- Tests: 146, incl. Heritrix 3.14.1's own `ExtractorHTMLTest`, `ExtractorJSTest`, `ExtractorCSSTest` and
  `UriUtilsTest.testIsDataUri` cases ported as an oracle (with a mutation check), and the scoring effect.

## 1.7.3
- **Menu phase**: up to two menu triggers per sample — burger/off-canvas toggles (label, ARIA, id/class
  wording in several languages, `aria-controls` → nav/drawer, icon-only header toggles, CSS checkbox
  burgers) first, then navigation dropdowns — are opened, and up to two submenu controls revealed by
  them are clicked; each is a measured phase, then the menu is closed (Escape / toggle). Links that
  navigate, risky wording and search/cart/account/language toggles are never clicked; 10 s budget.
- Menu phases count new content inside fixed/sticky overlays (off-canvas drawers and dropdowns live
  there); before, such content was always discarded, and menu toggles inside sticky headers were never
  tested at all. Consent and ad containers stay excluded.
- New evidence: `MENU_LOADS_CONTENT` (strong), `MENU_RENDERS_LINKS` (weak); data-loading menus block
  `NO_INTERACTION_DYNAMICS`. Menus are no longer part of the generic click test. Browsertrix YAML suggests
  a custom menu behavior with the trigger selector. Evidence JSON: `rendered.menus`.
- Tests: 98.

## 1.7.2
- Guide: the author line now sits between the version label and the title.

## 1.7.1
- Heritrix seeds: runtime data (AJAX) hosts are now written as plain seed URLs (`https://api.x.dk/`;
  `http://` only if the host was never seen over https) instead of `+http://(…` SURT directives. Each
  seed has its own comment line above it (no trailing comments on seed lines); third-party hosts stay
  commented out (`#https://…`). `ajaxHosts` entries in the evidence JSON gain an `https` flag.

## 1.7.0
- **Second sitemap pattern**: whole-site runs now also include a page from the second most common
  sitemap URL pattern (role `secondary-pattern`), placed like the first; a sample covering the first
  pattern is never displaced by the second. `www.` and the apex host now count as one host when
  grouping. Export field `dominantPattern` is replaced by `sitemapPatterns` (array, by rank); samples
  carry `sitemapPattern`.
- **Consent banners** (new `probe/consent.js`, injected into every frame, so CMP iframes such as
  Sourcepoint are handled). Method modelled on *I don't care about cookies* (rule-based clicking,
  hiding, scroll unlocking, retried while the page loads) and Consent-O-Matic / DuckDuckGo autoconsent
  (present/showing detectors per CMP): ~28 CMP rules weighted towards Danish/European sites
  (Cookiebot, Cookie Information, OneTrust, Usercentrics, Didomi, Sourcepoint, Quantcast,
  consentmanager, Google FC, CookieYes, Complianz, Borlabs, …), exact-match button wording in
  da/nb/sv/is/en/de/nl/fr/fi/es/it/pl, open shadow roots, detect-and-click rounds that wait longer
  when a CMP script is present. *Try accept all* then hides a remaining banner/backdrop and unlocks
  scrolling. Only overlay-like banners with a recognised button are touched; links that navigate are
  never clicked. Default stays *Leave untouched*. Outcomes per sample and a report line.
- **Tighter request guard during consent** (`lib/consent-guard.js`): instead of allowing every non-GET
  request while a banner is handled, only CMP endpoints and recognisably consent-related same-site
  requests pass; each is logged as a security event.
- **Heritrix seeds** include the runtime data (XHR/fetch/EventSource) hosts seen in the browser tests
  (as SURT-prefix directives; replaced by seed URLs in 1.7.1): same-site hosts active, third-party hosts commented out,
  hosts already implied by the "/" seed noted. Also listed (as a comment) in the Browsertrix YAML and as
  `ajaxHosts` in the evidence JSON. Cookie Information and Sourcepoint endpoints added to the noise filter.
- Guide: author line, settings table, consent and pattern sections, updated protocol/security/export text.
- Tests: 89 (new: consent guard, consent wording, AJAX hosts/seeds, top-2 patterns).

## 1.6.0
- Whole-site runs always include one page from the **dominant sitemap URL pattern** (new pure
  module `lib/urlPattern.js`). Patterns drop the page name, truncate at identifier segments
  (`/produkt/48213/` → `/produkt/`), turn dates into placeholders (`/{yyyy}/{mm}/`), keep locale
  prefixes, and are counted over the full merged sitemap set after the usual sample filters.
- If a selected sample already matches the pattern nothing changes; otherwise the pick (seeded per
  site, newest half when `lastmod` exists) replaces the lowest-priority slot, never the front or
  current page. New sample role `dominant-pattern`, rendered right after the front/current page.
- The report and evidence export show the pattern, its share and how it was covered. Pattern
  labels come from sitemap URLs and are never sent to Gemini Nano.
- New tests: `tests/urlPattern.test.mjs`, `tests/samples-dominant.test.mjs`.

## 1.5.1
- New **Test scope** selector: *Whole site* (unchanged behaviour) or *Active tab URL only*. Single-page
  tests skip sitemap discovery and sampling, render only the active tab URL, and disable the sample
  count, robots.txt and early-exit options. Settings are normalised in the new pure `lib/settings.js`.
- In single-page mode the "multiple strong signals" rule needs two strong codes on that one sample
  (instead of two samples); decisive signals and the Nano rules are unchanged.
- Results, report, popup headline and history are labelled as page-only; Browsertrix YAML seeds the
  analysed URL with `scopeType: page`, Heritrix seeds contain only that URL.
- 4 new tests (42 total).

## 1.5.0

### Five headline features
1. **DevTools-protocol network measurement** (`lib/cdp.js`): complete request log for every frame and
   worker (auto-attached OOPIFs/workers), replacing the 250-entry Resource Timing buffer; request guard
   via `Fetch.requestPaused` that fails every non-GET/HEAD/OPTIONS request (read-only GraphQL excepted);
   focus emulation + active lifecycle state + fixed viewport so timers/rAF/IntersectionObserver run.
2. **Pre-request containment**: tab-scoped `declarativeNetRequest` session rules block off-scope
   top-level navigations before they are sent; attachment/non-HTML documents are failed at the response
   stage; *all* Incognito downloads during a session are cancelled and erased; popups/windows are closed;
   bundled **Public Suffix List** (ICANN + private) for scope.
3. **Scoring rework** (`lib/scoring.js`): 3 s idle baseline per sample subtracted from every phase;
   net-new nodes only (still connected, outside overlays/dialogs/consent/ad containers); new links must be
   absent from raw HTML and from the pre-phase DOM; per-sample evidence with prevalence weighting;
   symmetric Heritrix evidence; Nano can veto the non-decisive path; fixture-based regression tests.
4. **Lifecycle/state** (`lib/state.js`): in-memory state with serialized, throttled flushes to
   `storage.session`; Port-based popup updates (no polling); startup recovery (interrupted runs marked,
   orphan windows/rules/debugger sessions cleaned up); cancel button; global deadline; per-sample and
   per-probe timeouts; immediate rejection of a concurrent run; polite fetcher with 429/503 back-off.
5. **Export + sampling**: evidence JSON, Browsertrix YAML config hint, Heritrix seeds; listing/tag/
   category/archive pages sampled from rendered navigation and sitemaps; opt-in consent dismissal;
   scroll-lock detection; inner scroll-container support.

### Bug fixes from the v1.4 review
- Media segments are classified by MIME/resource type: `/_next/static/chunks/*.js`, `chunk-vendors.js`
  and `.ts` source files no longer produce `CONTINUOUS_STREAMING_MEDIA`.
- Challenge detection uses vendor-specific markers or challenge wording on small pages only: Akamai CDN
  URLs and reCAPTCHA scripts no longer produce `BROWSER_BYPASSES_CHALLENGE`; status-only blocks are
  ignored when our own requests were throttled.
- XML entity decoding is single-pass (`&amp;lt;` → `&lt;`), with numeric entities and CDATA support;
  namespaced `<ns:loc>`; `image:/video:/news:` locs ignored.
- Self-inflicted 429/503: bounded concurrency for raw and sitemap fetches, robots.txt before blind probes.
- `SCROLL_FETCHES_ELEMENTS` false positives (consent banners, carousels, analytics) fixed by baseline
  correction, overlay filtering and analytics filtering.
- Minimized/inactive tab throttling: default unfocused visible windows (one per worker, active tab) +
  focus emulation.
- `res.ok` is checked (non-2xx samples are not compared except as challenge evidence); `truncated` raw
  HTML disables raw-vs-rendered comparisons; charset-aware decoding.
- `NO_INTERACTION_DYNAMICS` no longer requires zero XHR/fetch.
- Evidence counted per sample instead of once per code; Heritrix maximum no longer structurally capped.
- Listing pages (`tag`, `page`, `media`…) are no longer excluded from sampling.
- Popup: HTTP check kept on re-render; unhandled `start()` rejection fixed; textareas only rewritten
  when content changes.

### Security
- No MAIN-world injection anywhere; DOM probes run in the isolated world.
- Network guard and navigation blocking no longer depend on page JavaScript or post-hoc `tabs.onUpdated`.
- Gemini Nano receives only numbers/booleans/whitelisted enums (no page text, labels or URLs).
- Redundant `tabs` and `activeTab` permissions removed; host permissions narrowed to `http(s)://*/*`.
- Messages accepted only from the extension's own pages.

### Gemini Nano
- Download from the popup (user activation) when `downloadable`; availability shown.
- Hard timeout with `AbortSignal`; input quota measured and payload trimmed to fit; policy sent once.
- Runs in the service worker when the Prompt API is exposed there, otherwise in the offscreen document,
  which is closed after each run. Offscreen `DOM_PARSER` reason is now accurate (it really parses HTML).

### Code quality
- 3 000-line `background.js` split into tested modules; probe helpers defined once in `probe/injected.js`.
- Dead code removed (`triggerSecurityAbort`, unused AI_RESULT handler, `MAX_SAMPLES`,
  `MAX_RUNTIME_RESOURCE_URLS`, unused content-length fields, duplicated state fields).
- Magic numbers collected in `CONFIG` / scoring thresholds `T`.
- 38 `node:test` tests incl. fixture replays of the v1.4 false positives.
- Page-language heuristic extended beyond Danish/English (nb, sv, de, nl, fr).
