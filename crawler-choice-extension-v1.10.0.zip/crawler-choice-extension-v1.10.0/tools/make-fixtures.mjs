// Writes the synthetic regression fixtures in tests/fixtures/ (re-run after changing helpers).
import { writeFileSync } from 'node:fs';
import { raw, rendered, links, dom, net } from '../tests/helpers.mjs';

const fx = (name, note, expectedDecision, samples, extra = {}) => writeFileSync(new URL(`../tests/fixtures/${name}.json`, import.meta.url),
  JSON.stringify({ synthetic: true, note, expectedDecision, samples, ...extra }, null, 2));

fx('nextjs-static-export', 'Next.js static export: chunk scripts everywhere, all content server-rendered. v1.4 flagged CONTINUOUS_STREAMING_MEDIA.', 'Heritrix',
  ['front-page', 'section', 'detail', 'detail'].map((role, i) => ({ url: `https://example.dk/p${i}`, role, raw: raw({ frameworks: ['Next.js'], scriptCount: 14 }), rendered: rendered({ load: { frameworks: ['Next.js'] }, networkAll: { segmentCount: 0, total: 40 } }) })),
  { forbiddenCodes: ['CONTINUOUS_STREAMING_MEDIA', 'PLAYBACK_STARTS_MEDIA_SEGMENTS'] });

fx('akamai-assets-recaptcha', 'News site on Akamai CDN with a reCAPTCHA newsletter form. v1.4 flagged BROWSER_BYPASSES_CHALLENGE.', 'Heritrix',
  ['front-page', 'section', 'detail'].map((role, i) => ({ url: `https://example.dk/q${i}`, role, raw: raw(), rendered: rendered() })),
  { forbiddenCodes: ['BROWSER_BYPASSES_CHALLENGE'] });

fx('consent-and-carousel', 'Cookie banner injected on load plus an auto-rotating teaser carousel. v1.4 flagged SCROLL_FETCHES_ELEMENTS (decisive).', 'Heritrix',
  ['front-page', 'section', 'detail'].map((role, i) => ({ url: `https://example.dk/c${i}`, role, raw: raw(), rendered: rendered({
    baseline: { durationMs: 3000, dom: dom({ netElements: 25, text: 400, newLinks: links('teaser', 3), overlayElements: 120 }), net: net({ data: 1 }) },
    scroll: { durationMs: 5000, info: { bottomLoads: 1 }, dom: dom({ netElements: 35, text: 600, newLinks: links('teaser', 4, 3), overlayElements: 40 }), net: net({ data: 2 }) },
  }) })),
  { forbiddenCodes: ['SCROLL_DISCOVERS_LINKS', 'SCROLL_FETCHES_CONTENT'] });

fx('infinite-scroll-listing', 'Listing page whose archive is only reachable by scrolling.', 'Browsertrix',
  [
    { url: 'https://example.dk/', role: 'front-page', raw: raw(), rendered: rendered() },
    { url: 'https://example.dk/nyheder/', role: 'listing', raw: raw({ links: links('a', 30) }), rendered: rendered({ rawLinks: links('a', 30), scroll: { durationMs: 9000, info: { bottomLoads: 4 }, dom: dom({ netElements: 900, text: 15000, newLinks: links('artikel', 60) }), net: net({ data: 4, api: 4 }) } }) },
  ],
  { expectedCodes: ['SCROLL_DISCOVERS_LINKS', 'INFINITE_SCROLL'] });

fx('spa-shell', 'Client-rendered SPA: empty shell + JSON API on every page.', 'Browsertrix',
  ['front-page', 'section', 'detail'].map((role, i) => ({ url: `https://example.dk/s${i}`, role,
    raw: raw({ textLength: 400, links: [], scriptCount: 8, frameworks: ['React'] }),
    rendered: rendered({ rawLinks: links('app', 45), load: { textLength: 14000 }, runtimeOnly: { api: 3, meaningful: 6 } }) })),
  { expectedCodes: ['CLIENT_RENDERED_FROM_RUNTIME_API', 'JS_GENERATED_LINKS'] });
console.log('fixtures written');
