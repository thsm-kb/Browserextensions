// Popup: subscribes to state over a Port (no polling), writes textareas only when they change
// (so scroll position and selection survive updates), and offers cancel + export.

const SETTINGS_KEY = 'crawlerChoiceSettings';
const SETTINGS_VERSION = 2; // keep in sync with lib/settings.js (v2: Gemini Nano off by default)
const SETTING_IDS = ['test-scope', 'sample-count-input', 'consent-mode', 'window-mode', 'max-minutes', 'respect-robots', 'use-ai', 'early-exit', 'check-urls'];
const SITE_ONLY_IDS = ['sample-count-input', 'respect-robots', 'early-exit'];
const el = id => document.getElementById(id);
let tabId = null, tabUrl = '', incognitoAllowed = false, isHttp = false, lastState = null;

init().catch(err => { el('detail').textContent = String(err?.message || err); });

async function send(msg) {
  try { return await chrome.runtime.sendMessage(msg); }
  catch (err) { return { ok: false, error: String(err?.message || err) }; }
}

async function init() {
  el('version').textContent = `v${chrome.runtime.getManifest().version}`;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id ?? null;
  tabUrl = tab?.url || '';
  isHttp = /^https?:/i.test(tabUrl);
  let host = '';
  try { host = new URL(tabUrl).hostname; } catch {}
  el('domain').textContent = host || 'Unknown page';

  await loadSettings();
  for (const id of SETTING_IDS) el(id).addEventListener('change', saveSettings);
  el('test-scope').addEventListener('change', applyScopeUi);
  applyScopeUi();

  incognitoAllowed = await chrome.extension.isAllowedIncognitoAccess();
  renderSecurityMode(tab);
  el('analyze').addEventListener('click', start);
  el('cancel').addEventListener('click', () => send({ type: 'CANCEL_ANALYSIS', tabId }));
  el('guide').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('guide.html') }));
  el('export-json').addEventListener('click', () => doExport('json'));
  el('export-yaml').addEventListener('click', () => doExport('yaml'));
  el('export-seeds').addEventListener('click', () => doExport('seeds'));
  el('nano-download').addEventListener('click', downloadNano);
  updateAnalyzeButton(null);

  if (host) {
    const last = await send({ type: 'GET_LAST_RESULT', host });
    if (last?.last) {
      const scope = last.last.testScope === 'page' ? `single page${last.last.url ? `: ${last.last.url}` : ''}` : 'whole site';
      el('last-result').textContent = `Last result for this host (${scope}): ${last.last.decision} (${last.last.confidence}) on ${new Date(last.last.at).toLocaleString()} · v${last.last.version}`;
    }
  }

  const port = chrome.runtime.connect({ name: 'state' });
  port.onMessage.addListener(msg => { if (msg?.type === 'STATE') render(msg.state); });
  if (tabId != null) port.postMessage({ type: 'SUBSCRIBE', tabId });

  refreshNanoStatus();
}

async function loadSettings() {
  const s = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY] || {};
  el('test-scope').value = s.testScope === 'page' ? 'page' : 'site';
  el('sample-count-input').value = String(clamp(s.sampleCount ?? 7, 5, 20, 7));
  el('consent-mode').value = s.consentMode || 'off';
  el('window-mode').value = s.windowMode || 'visible';
  el('max-minutes').value = String(clamp(s.maxRunMinutes ?? 6, 2, 20, 6));
  el('respect-robots').checked = !!s.respectRobots;
  // settings saved before v1.9 have no version: their useAi was just the old default, so start unchecked
  el('use-ai').checked = (Number(s.settingsVersion) || 1) >= SETTINGS_VERSION && s.useAi === true;
  el('early-exit').checked = s.earlyExit !== false;
  el('check-urls').checked = s.checkUrls !== false;
}

function readSettings() {
  return {
    settingsVersion: SETTINGS_VERSION,
    testScope: el('test-scope').value === 'page' ? 'page' : 'site',
    sampleCount: clamp(el('sample-count-input').value, 5, 20, 7),
    consentMode: el('consent-mode').value,
    windowMode: el('window-mode').value,
    maxRunMinutes: clamp(el('max-minutes').value, 2, 20, 6),
    respectRobots: el('respect-robots').checked,
    useAi: el('use-ai').checked,
    earlyExit: el('early-exit').checked,
    checkUrls: el('check-urls').checked,
  };
}

async function saveSettings() {
  const s = readSettings();
  el('sample-count-input').value = String(s.sampleCount);
  el('max-minutes').value = String(s.maxRunMinutes);
  await chrome.storage.local.set({ [SETTINGS_KEY]: s });
}

function clamp(v, min, max, fallback) {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}

async function start() {
  el('analyze').disabled = true;
  await saveSettings();
  const res = await send({ type: 'START_ANALYSIS', tabId, settings: readSettings() });
  if (!res?.ok) {
    el('detail').textContent = res?.error || 'Could not start the analysis.';
    updateAnalyzeButton(lastState);
  }
}

function updateAnalyzeButton(state) {
  const running = !!state?.running;
  el('analyze').hidden = running;
  el('cancel').hidden = !running;
  el('analyze').disabled = running || !isHttp || !incognitoAllowed || tabId == null;
  const pageOnly = el('test-scope').value === 'page';
  for (const id of SETTING_IDS) el(id).disabled = running || (pageOnly && SITE_ONLY_IDS.includes(id));
  el('analyze').textContent = pageOnly ? 'Analyze page' : 'Analyze site';
}

/** Sample count, robots.txt and early exit only apply to whole-site tests. */
function applyScopeUi() {
  const pageOnly = el('test-scope').value === 'page';
  for (const id of SITE_ONLY_IDS) {
    el(id).disabled = pageOnly || !!lastState?.running;
    const row = el(id).closest('label') || el(id).parentElement;
    row?.classList.toggle('inactive', pageOnly);
  }
  el('analyze').textContent = pageOnly ? 'Analyze page' : 'Analyze site';
}

function setIfChanged(id, value) {
  const node = el(id);
  if (node.value !== value) node.value = value;
}

function render(state) {
  lastState = state;
  updateAnalyzeButton(state);
  if (!state) return;
  const pct = Number(state.progress || 0);
  el('phase').textContent = state.phase || 'Ready';
  el('detail').textContent = state.detail || '';
  el('percent').textContent = `${pct}%`;
  el('bar').style.width = `${Math.max(0, Math.min(100, pct))}%`;
  el('bar').parentElement.classList.toggle('done', !!state.done && !!state.decision);

  const decision = el('decision');
  decision.className = 'decision';
  if (state.running) { decision.textContent = 'Analyzing…'; decision.classList.add('running'); }
  else if (state.decision) { decision.textContent = state.testScope === 'page' ? `${state.decision} · this page` : state.decision; decision.classList.add(state.decision.toLowerCase()); }
  else if (state.done) { decision.textContent = state.cancelled ? 'Stopped' : 'Error'; decision.classList.add(state.cancelled ? 'idle' : 'error'); }
  else decision.textContent = 'Not analyzed';

  const warnings = Array.isArray(state.warnings) ? state.warnings.filter(Boolean) : [];
  el('warning').textContent = warnings.join('\n\n');
  el('warning').hidden = !warnings.length;

  el('scores').textContent = state.scores
    ? `Browsertrix ${state.scores.browsertrix} · Heritrix ${state.scores.heritrix} · strong codes ${state.scores.strongCodes} on ${state.scores.strongSamples} sample(s) · ${state.scores.comparable} comparable · HF confidence ${state.confidence}`
    : '';

  setIfChanged('report', Array.isArray(state.report) ? state.report.join('\n') : '');
  const samples = Array.isArray(state.samples) ? state.samples : [];
  setIfChanged('sample-urls', samples.map(s => `[${s.role}${s.status ? ` · ${s.status}` : ''}]${s.codes?.length ? ` {${s.codes.join(', ')}}` : ''} ${s.url}`).join('\n'));
  el('sample-count').textContent = samples.length ? `(${samples.length})` : '';
  setIfChanged('url-check', typeof state.urlCheckList === 'string' ? state.urlCheckList : '');
  el('url-check-count').textContent = state.urlCheckCount ? `(${state.urlCheckCount} tested)` : '';
  const sitemaps = Array.isArray(state.sitemapPreview) ? state.sitemapPreview : [];
  setIfChanged('sitemaps', sitemaps.join('\n') + (state.sitemapCount > sitemaps.length ? `\n… ${state.sitemapCount - sitemaps.length} more (see evidence JSON export)` : ''));
  el('sitemap-count').textContent = state.sitemapCount ? `(${state.sitemapCount})` : '';
  el('export-section').hidden = !state.exportAvailable || !!state.running;
}

async function doExport(kind) {
  const res = await send({ type: 'GET_EXPORT', tabId });
  if (!res?.ok) { el('detail').textContent = res?.error || 'Export not available.'; return; }
  const files = {
    json: [`${res.base}.json`, res.json, 'application/json'],
    yaml: [`${res.base}.browsertrix.yaml`, res.yaml, 'text/yaml'],
    seeds: [`${res.base}.heritrix-seeds.txt`, res.seeds, 'text/plain'],
  };
  const [name, content, type] = files[kind];
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

async function refreshNanoStatus() {
  const box = el('nano-status');
  const LM = globalThis.LanguageModel;
  if (!LM) { box.textContent = 'Gemini Nano: Prompt API not available in this browser.'; return; }
  let availability = 'unavailable';
  try { availability = await LM.availability({ expectedInputs: [{ type: 'text', languages: ['en'] }], expectedOutputs: [{ type: 'text', languages: ['en'] }] }); } catch {}
  box.textContent = `Gemini Nano: ${availability}`;
  el('nano-download').hidden = !(availability === 'downloadable' || availability === 'downloading');
}

async function downloadNano() {
  const LM = globalThis.LanguageModel;
  if (!LM) return;
  el('nano-download').disabled = true;
  try {
    const session = await LM.create({
      expectedInputs: [{ type: 'text', languages: ['en'] }],
      expectedOutputs: [{ type: 'text', languages: ['en'] }],
      monitor(m) { m.addEventListener('downloadprogress', e => { el('nano-status').textContent = `Gemini Nano: downloading ${Math.round((e.loaded || 0) * 100)}%`; }); },
    });
    session.destroy?.();
  } catch (err) {
    el('nano-status').textContent = `Gemini Nano: download failed (${err?.message || err})`;
  } finally {
    el('nano-download').disabled = false;
    refreshNanoStatus();
  }
}

function renderSecurityMode(tab) {
  const box = el('security-mode');
  if (!incognitoAllowed) {
    box.textContent = 'Incognito access is required. Enable “Allow in Incognito” for this extension in chrome://extensions, then reopen the popup.';
    box.classList.add('required');
  } else if (tab?.incognito) {
    box.textContent = 'Open the page in a normal window to analyze it; tests run in their own Incognito windows.';
    box.classList.add('required');
  } else {
    box.textContent = 'Isolation: fresh Incognito windows, DevTools-level request guard (non-GET blocked), pre-request navigation blocking, all Incognito downloads cancelled. Chrome shows a “started debugging this browser” bar while tests run.';
    box.classList.remove('required');
  }
}
