// Crawler Choice v1.5 — service worker / orchestrator.
// Pure logic lives in lib/ (tested in tests/); this file wires Chrome APIs together.

import { registrableDomain, sameRegisteredDomain } from './lib/psl.js';
import { canonicalKey, shortUrl, sleep, withTimeout, mapLimit, mapLimitUntil, throwIfAborted, isUnsafeBrowserSampleUrl, AbortedError } from './lib/util.js';
import { detectSiteLanguage } from './lib/locale.js';
import { discoverSitemaps } from './lib/sitemaps.js';
import { chooseSamples, selectRenderTargets } from './lib/samples.js';
import { PoliteFetcher } from './lib/fetcher.js';
import { summarizeWindow, runtimeOnlyResources, detectPolling, collectAjaxHosts, mergeAjaxHosts } from './lib/network.js';
import { sampleEvidence, hasDecisive, aggregate, decide } from './lib/scoring.js';
import { buildAiPayload, runNano, nanoAvailability } from './lib/ai-core.js';
import { CdpSession, detachAll } from './lib/cdp.js';
import { StateStore } from './lib/state.js';
import { normalizeSettings } from './lib/settings.js';
import { browsertrixYaml, heritrixSeeds, exportFileBase } from './lib/export.js';
import { buildRawBasis } from './lib/raw-basis.js';
import { browserUrlsOf, compareUniqueUrls, urlComparisonLines } from './lib/url-comparison.js';
import { runUrlCheck, urlCheckListing, URL_CHECK_DEFAULTS } from './lib/url-check.js';
import { robotsAllows } from './lib/sitemaps.js';

const VERSION = chrome.runtime.getManifest().version;

const CONFIG = {
  MAX_SITEMAP_DOCS: 48,
  SITEMAP_POOL_URLS_PER_DOC: 10,
  MAX_SITEMAP_CHILD_FETCHES: 40,
  SITEMAP_CONCURRENCY: 3,
  SITEMAP_TIMEOUT_MS: 12_000,
  SITEMAP_EXPANSION_BUDGET_MS: 15_000,
  MAX_SITEMAP_LOCATIONS: 15_000,
  MAX_SITEMAP_URLS: 15_000,
  MAX_SITEMAP_BYTES: 12_000_000,
  MAX_HTML_BYTES: 4_000_000,
  RAW_CONCURRENCY: 3,
  RENDER_CONCURRENCY: 3,
  TAB_TIMEOUT_MS: 20_000,
  SAMPLE_TIMEOUT_MS: 90_000,
  PROBE_CALL_TIMEOUT_MS: 25_000,
  SETTLE_MS: 1500,
  IDLE_BASELINE_MS: 3000,
  SCROLL: { maxMs: 12_000, maxSteps: 60, stableBottomRounds: 2, maxBottomLoads: 8 },
  CLICK_TEST_MAX_CANDIDATES: 5,
  CLICK_SETTLE_MS: 1500,
  // Menu phase (v1.7.3): burger/off-canvas toggles and navigation dropdowns, then submenu items they reveal.
  MENU: { maxTriggers: 2, maxItemsPerTrigger: 2, settleMs: 1200, budgetMs: 10_000 },
  MEDIA: { maxElements: 2, playbackMs: 2500 },
  VIEWER_SETTLE_MS: 1800,
  // Consent handling (only when the setting is not "Leave untouched"). Rounds of detect + one click in
  // every frame; stops when no banner is showing. Waits longer when a CMP script is present but its
  // banner has not rendered yet.
  CONSENT: { pollMs: 400, quietMs: 2000, hintMs: 6000, maxMs: 10_000, afterClickMs: 900, maxActions: 4, callTimeoutMs: 6000 },
  VIEWER_MAX_FRAME_PROBES: 12,
  AI_TIMEOUT_MS: 45_000,
  KEEPALIVE_MS: 20_000,
  WINDOW: { width: 1366, height: 900 },
};

const ICONS = Object.fromEntries(['idle', 'running', 'heritrix', 'browsertrix', 'error'].map(n => [n, { 16: `icons/${n}16.png`, 32: `icons/${n}32.png`, 48: `icons/${n}48.png`, 128: `icons/${n}128.png` }]));
const ACTIVE_SESSION_KEY = 'activeSession';

const store = new StateStore();
let job = null;          // { tabId, controller, promise }
let session = null;      // isolated test session (windows, tabs, DNR rules, events)
let nextRuleId = 5000;
let offscreenCreating = null;

// ---------------------------------------------------------------------------------------------
// Lifecycle & recovery
// ---------------------------------------------------------------------------------------------

const ready = recover().catch(err => console.warn('recovery failed', err));
chrome.runtime.onStartup.addListener(() => { recover().catch(() => {}); });
chrome.runtime.onInstalled.addListener(() => { recover().catch(() => {}); });

/** Cleans up after a service-worker restart or crash mid-run. */
async function recover() {
  if (job) return;
  for (const st of await store.allRunStates()) {
    if (st?.running) {
      await store.replace(st.tabId, { ...st, running: false, done: true, phase: 'Analysis interrupted', detail: 'The extension was restarted during the analysis. Leftover test windows were closed; run it again.', decision: null, interrupted: true });
      setVisualState(st.tabId, 'error', '!').catch(() => {});
    }
  }
  const saved = (await chrome.storage.session.get(ACTIVE_SESSION_KEY))[ACTIVE_SESSION_KEY];
  for (const id of saved?.windowIds || []) await chrome.windows.remove(id).catch(() => {});
  await chrome.storage.session.remove(ACTIVE_SESSION_KEY).catch(() => {});
  const rules = await chrome.declarativeNetRequest.getSessionRules().catch(() => []);
  if (rules.length) await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: rules.map(r => r.id) }).catch(() => {});
  await detachAll().catch(() => {});
  await closeOffscreen();
}

async function persistSession() {
  if (!session) return chrome.storage.session.remove(ACTIVE_SESSION_KEY).catch(() => {});
  return chrome.storage.session.set({ [ACTIVE_SESSION_KEY]: { windowIds: [...session.windowIds], tabIds: [...session.tabIds], startedAt: session.startedAt } }).catch(() => {});
}

// ---------------------------------------------------------------------------------------------
// Messaging
// ---------------------------------------------------------------------------------------------

chrome.runtime.onConnect.addListener(port => { if (port.name === 'state') store.attachPort(port); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg?.type || msg.target === 'offscreen') return;
  if (sender.id !== chrome.runtime.id || sender.tab) return; // only our own extension pages (popup)

  const handlers = {
    START_ANALYSIS: () => startAnalysis(msg.tabId, msg.settings),
    CANCEL_ANALYSIS: async () => {
      if (!job || job.tabId !== msg.tabId) return { ok: false, error: 'No running analysis for this tab.' };
      job.controller.abort(new AbortedError('Cancelled by user'));
      return { ok: true };
    },
    GET_STATE: async () => ({ ok: true, state: await store.get(msg.tabId) }),
    GET_EXPORT: async () => {
      const bundle = await store.getExport(msg.tabId);
      if (!bundle) return { ok: false, error: 'No export available for this tab.' };
      return { ok: true, base: exportFileBase(bundle), json: JSON.stringify(bundle, null, 2), yaml: browsertrixYaml(bundle), seeds: heritrixSeeds(bundle) };
    },
    NANO_STATUS: async () => ({ ok: true, availability: await aiAvailability() }),
    GET_LAST_RESULT: async () => ({ ok: true, last: await store.lastFor(msg.host) }),
  };
  const h = handlers[msg.type];
  if (!h) return;
  ready.then(h).then(sendResponse, err => sendResponse({ ok: false, error: String(err?.message || err) }));
  return true;
});

async function startAnalysis(tabId, rawSettings) {
  if (!Number.isInteger(tabId)) return { ok: false, error: 'Invalid tab.' };
  if (job) return { ok: false, error: job.tabId === tabId ? 'An analysis is already running for this tab.' : 'Another analysis is already running in a different tab. Cancel it or wait for it to finish.' };
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab?.url || !/^https?:/i.test(tab.url)) return { ok: false, error: 'Only HTTP(S) pages can be analyzed.' };
  if (tab.incognito) return { ok: false, error: 'Start the analysis from a normal window; tests run in their own Incognito windows.' };
  if (isUnsafeBrowserSampleUrl(tab.url)) return { ok: false, error: 'This URL looks like a downloadable file rather than an HTML page.' };
  if (!(await chrome.extension.isAllowedIncognitoAccess())) return { ok: false, error: 'Enable “Allow in Incognito” for this extension in chrome://extensions.' };
  const existing = await chrome.windows.getAll();
  if (existing.some(w => w.incognito)) return { ok: false, error: 'Close all Incognito windows first, so the test session starts with an empty Incognito profile.' };

  const settings = normalizeSettings(rawSettings);
  const controller = new AbortController();
  job = { tabId, controller, promise: null };
  const keepalive = setInterval(() => chrome.runtime.getPlatformInfo().catch(() => {}), CONFIG.KEEPALIVE_MS);
  job.promise = runAnalysis(tabId, tab.url, settings, controller.signal)
    .catch(err => failAnalysis(tabId, err))
    .finally(() => { clearInterval(keepalive); job = null; closeOffscreen(); });
  return { ok: true, settings };
}

// ---------------------------------------------------------------------------------------------
// Tab / window / download containment while a test session is active
// ---------------------------------------------------------------------------------------------

function recordEvent(tabId, type, detail = '') {
  if (!session) return;
  const ev = { tabId: tabId ?? null, type, detail: String(detail || '').slice(0, 300), at: Date.now() };
  session.events.push(ev);
}

chrome.tabs.onCreated.addListener(tab => {
  if (!session || !tab.incognito) return;
  // Our own tabs are registered right after chrome.tabs.create resolves; give that a moment.
  setTimeout(() => {
    if (!session || session.tabIds.has(tab.id) || session.knownTabs.has(tab.id)) return;
    if (session.creatingTabs > 0 && session.windowIds.has(tab.windowId) && !tab.openerTabId) return;
    recordEvent(tab.openerTabId, 'popup-blocked', tab.pendingUrl || tab.url || 'new tab');
    chrome.tabs.remove(tab.id).catch(() => {});
  }, 400);
});

chrome.windows.onCreated.addListener(win => {
  if (!session || !win.incognito) return;
  setTimeout(() => {
    if (!session || session.windowIds.has(win.id) || session.creatingWindows > 0) return;
    recordEvent(null, 'popup-window-blocked', `window ${win.id}`);
    chrome.windows.remove(win.id).catch(() => {});
  }, 400);
});

chrome.downloads.onCreated.addListener(item => {
  // Every Incognito download during a session belongs to the test (other Incognito windows are
  // refused at start), so all of them are cancelled — not only those on the target domain.
  if (!session || !item?.incognito) return;
  chrome.downloads.cancel(item.id).catch(() => {});
  recordEvent(null, 'download-blocked', item.finalUrl || item.url || '');
  setTimeout(async () => {
    const [d] = await chrome.downloads.search({ id: item.id }).catch(() => []);
    if (d?.state === 'complete' && d.exists) await chrome.downloads.removeFile(item.id).catch(() => {});
    await chrome.downloads.erase({ id: item.id }).catch(() => {});
  }, 200);
});

chrome.tabs.onRemoved.addListener(tabId => {
  if (job?.tabId === tabId) job.controller.abort(new AbortedError('The analyzed tab was closed'));
  else store.remove(tabId).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url && job?.tabId !== tabId && !session?.tabIds.has(tabId)) {
    store.get(tabId).then(st => { if (st && !st.running) { store.remove(tabId); setVisualState(tabId, 'idle', '').catch(() => {}); } }).catch(() => {});
  }
});

// ---------------------------------------------------------------------------------------------
// Analysis pipeline
// ---------------------------------------------------------------------------------------------

async function progress(tabId, percent, phase, detail, extra = {}) {
  store.patch(tabId, { progress: Math.round(percent), phase, detail, ...extra });
  chrome.action.setBadgeText({ tabId, text: percent >= 100 ? '' : String(Math.max(0, Math.min(99, Math.round(percent)))) }).catch(() => {});
}

async function runAnalysis(rootTabId, originalUrl, settings, userSignal) {
  const deadline = AbortSignal.timeout(settings.maxRunMinutes * 60_000);
  const signal = AbortSignal.any([userSignal, deadline]);
  const startedAt = Date.now();
  await setVisualState(rootTabId, 'running', '0');
  await store.replace(rootTabId, {
    running: true, done: false, progress: 1, phase: 'Starting analysis', detail: 'Preparing page and domain checks…',
    decision: null, report: [], samples: [], sitemapPreview: [], sitemapCount: 0, scores: null, warnings: [], ai: { status: 'pending' },
    startedAt, url: originalUrl, settings, version: VERSION,
  });

  const rootUrl = new URL(originalUrl);
  const rootDomain = registrableDomain(rootUrl.hostname);
  const fetcher = new PoliteFetcher({ perHostConcurrency: 3, minGapMs: 250 });

  // 1. Read-only probe of the user's own tab (ISOLATED world; no scrolling, clicking or debugger).
  await progress(rootTabId, 4, 'Reading the current page', 'Collecting rendered links and page-language signals (read-only).');
  const current = await probeCurrentTab(rootTabId).catch(() => null);
  const languageProfile = detectSiteLanguage(current);
  const navLinks = (current?.links || []).filter(u => sameRegisteredDomain(u, rootDomain));
  store.patch(rootTabId, { detectedLocale: languageProfile.detectedLocale, languageDetectionSource: languageProfile.source });
  throwIfAborted(signal);

  const pageOnly = settings.testScope === 'page';
  let sitemap, samples;
  if (pageOnly) {
    // Single-page mode: no sitemap discovery and no sampling — only the active tab URL is tested.
    sitemap = { entries: [], documents: [], locations: [], robotsSitemaps: [], robotsRules: [], pools: [], childFetches: 0, maxChildFetches: 0, skippedLanguageSitemaps: 0, truncatedDocs: 0, elapsedMs: 0 };
    samples = [{ url: canonicalKey(originalUrl), role: 'current-page', current: true }];
    await progress(rootTabId, 24, 'Single-page test', 'Only the active tab URL will be tested; sitemap discovery and sampling are skipped.');
  } else {
    // 2. Sitemaps.
    await progress(rootTabId, 8, 'Discovering sitemap structure', 'robots.txt first, then common sitemap locations (polite, rate-limited).');
    sitemap = await discoverSitemaps({
      pageUrl: originalUrl, rootDomain, sampleCount: settings.sampleCount, languageProfile, fetcher, cfg: CONFIG, signal,
      onProgress: (done, total) => progress(rootTabId, 8 + Math.round((done / Math.max(total, 1)) * 14), 'Discovering sitemap structure', `${done}/${total} sitemap candidates checked.`),
    });
    store.patch(rootTabId, { sitemapCount: sitemap.locations.length, sitemapEntries: sitemap.entries.length, sitemapPreview: sitemap.locations.slice(0, 300) });

    // 3. Samples.
    await progress(rootTabId, 24, 'Selecting representative samples', 'Front page, current page, listing pages, sections and detail pages — never random.');
    samples = chooseSamples({
      entries: sitemap.entries, sitemapPools: sitemap.pools, currentUrl: originalUrl, renderedLinks: navLinks, rootDomain,
      max: settings.sampleCount, robotsRules: settings.respectRobots ? sitemap.robotsRules : null,
    });
  }
  store.patch(rootTabId, { samples: samples.map(s => ({ url: s.url, role: s.role, status: 'pending' })), testScope: settings.testScope });

  // 4. Raw HTTP preflight + DOMParser analysis.
  await progress(rootTabId, 28, 'Fetching raw HTML samples', `Fetching ${samples.length} samples (max ${CONFIG.RAW_CONCURRENCY} at a time).`);
  await ensureOffscreen();
  let rawDone = 0;
  const raws = await mapLimit(samples, CONFIG.RAW_CONCURRENCY, async sample => {
    const r = await analyzeRawSample(sample.url, rootDomain, fetcher, signal, { obeyMetaRobotsNofollow: !!settings.respectRobots }).catch(err => ({ ok: false, status: 0, error: String(err?.message || err), safety: { safe: false, reason: 'preflight-failed' } }));
    rawDone++;
    progress(rootTabId, 28 + Math.round((rawDone / Math.max(samples.length, 1)) * 14), 'Fetching raw HTML samples', `${rawDone}/${samples.length} fetched.`);
    return r;
  });
  throwIfAborted(signal);
  const rawByUrl = new Map(samples.map((s, i) => [canonicalKey(s.url), raws[i]]));
  const renderTargets = selectRenderTargets(samples.filter(s => rawByUrl.get(canonicalKey(s.url))?.safety?.safe), settings.sampleCount);
  if (!renderTargets.length) {
    if (pageOnly) {
      const r = rawByUrl.get(canonicalKey(originalUrl));
      throw new Error(`The active tab URL could not be confirmed as a renderable HTML page (${r?.safety?.reason || r?.error || 'preflight failed'}).`);
    }
    throw new Error('Security preflight could not confirm any sample as a renderable same-site HTML page (check HTTP status codes in the sample list).');
  }

  // 5. Isolated browser tests.
  await progress(rootTabId, 44, 'Preparing isolated browser tests', `${renderTargets.length} HTML samples will be tested in fresh Incognito windows with DevTools-level network control.`);
  const results = new Map();
  let earlyExit = null;
  try {
    await createTestSession(rootTabId, settings, Math.min(CONFIG.RENDER_CONCURRENCY, renderTargets.length));
    let doneCount = 0;
    // Aborts samples still in flight when another worker finds decisive evidence.
    const earlyExitCtl = new AbortController();
    const sampleSignal = AbortSignal.any([signal, earlyExitCtl.signal]);
    const scheduled = await mapLimitUntil(renderTargets, session.workerWindows.length, async (sample, _i, worker) => {
      throwIfAborted(signal);
      if (earlyExit) return { stop: true };
      const raw = rawByUrl.get(canonicalKey(sample.url));
      const windowId = session.workerWindows[worker];
      let rendered;
      try {
        rendered = await withTimeout(renderSample(sample, raw, windowId, rootDomain, settings, sampleSignal), CONFIG.SAMPLE_TIMEOUT_MS, 'Browser sample');
      } catch (err) {
        if (err instanceof AbortedError) {
          if (signal.aborted) throw err;
          return { stop: true }; // stopped because of early exit elsewhere
        }
        rendered = { error: String(err?.message || err) };
      }
      rendered.role = sample.role;
      const evidence = sampleEvidence(raw?.analysis || null, rendered, { fetcherThrottled: fetcher.wasThrottled(new URL(sample.url).host) });
      results.set(canonicalKey(sample.url), { rendered, evidence });
      doneCount++;
      const decisive = settings.earlyExit ? hasDecisive(evidence) : null;
      updateSampleStatus(rootTabId, sample.url, statusFor(rendered, evidence));
      if (decisive && !earlyExit) {
        earlyExit = { code: decisive.code, text: decisive.text, sampleUrl: sample.url, sampleRole: sample.role, testedSamples: doneCount };
        earlyExitCtl.abort(new AbortedError('early exit'));
        await progress(rootTabId, 80, 'Decisive Browsertrix evidence found', `${decisive.text} Remaining samples are skipped.`);
        return { value: true, stop: true };
      }
      await progress(rootTabId, 46 + Math.round((doneCount / renderTargets.length) * 34), 'Rendering, scrolling and interaction-testing samples', `${doneCount}/${renderTargets.length} complete: ${shortUrl(sample.url)}`);
      return { value: true, stop: !!earlyExit };
    });
    void scheduled;
  } finally {
    await destroyTestSession();
  }
  throwIfAborted(signal);

  // 6. Scoring, AI, decision.
  await progress(rootTabId, 84, 'Scoring evidence', 'Baseline-corrected, per-sample evidence weighted by prevalence.');
  const scoredSamples = samples.map(s => ({ url: s.url, role: s.role, evidence: results.get(canonicalKey(s.url))?.evidence || { comparable: false, codes: [], limits: ['not-browser-tested'] } }));
  const agg = aggregate(scoredSamples, { sitemapEntries: sitemap.entries.length, sectionSamples: samples.filter(s => s.role === 'section').length });

  let ai = { status: 'disabled' };
  if (agg.decisive.length) ai = { status: 'skipped-decisive' };
  else if (settings.useAi) {
    await progress(rootTabId, 90, 'Gemini Nano second opinion', 'The model receives only numeric measurements (no page text, labels or URLs).');
    const payload = buildAiPayload(agg, scoredSamples.map(s => s.evidence.features), { sitemapEntries: sitemap.entries.length });
    ai = await classifyWithNano(payload).catch(err => ({ status: 'error', error: String(err?.message || err) }));
  }
  const final = decide(agg, ai, { minStrongSamples: pageOnly ? 1 : 2 });
  const spaDetected = [...results.values()].some(r => (r.rendered?.spa?.routeEvents || 0) > 0);
  const streaming = agg.evidence.some(e => /MANIFEST|SEGMENTS|STREAMING/.test(e.code));
  const lockedSamples = [...results.values()].filter(r => r.evidence?.limits?.includes('scroll-locked-overlay')).length;
  const fetchSummary = fetcher.summary();
  const warnings = [
    ...(final.decision === 'Browsertrix' && spaDetected ? ['Client-side routing (SPA) observed. A custom behavior or ArchiveWeb.page may be needed for in-app navigation.'] : []),
    ...(streaming ? ['Streaming media detected; crawler capture of audio/video may be incomplete.'] : []),
    ...(lockedSamples ? [`${lockedSamples} sample(s) had a scroll-locking overlay (often a consent banner). Results may under-detect dynamic loading; consider the consent-dismissal setting.`] : []),
    ...(fetchSummary.throttled ? [`The site rate-limited raw requests (${fetchSummary.throttled}×). Requests were slowed down and status-only blocking was not counted as WAF evidence.`] : []),
    ...(pageOnly ? ['Single-page test: the result describes this URL only, not the whole site. Use “Whole site” before choosing a crawler for a full domain crawl.']
      : agg.comparableSamples < 3 ? [`Only ${agg.comparableSamples} sample(s) could be compared; the recommendation is less reliable.`] : []),
  ];
  // Unique-URL totals, browser vs Heritrix emulation, over samples tested both ways.
  const urlComparison = compareUniqueUrls(samples.map(s => {
    const r = results.get(canonicalKey(s.url))?.rendered;
    const a = rawByUrl.get(canonicalKey(s.url))?.analysis;
    if (!r?.seenUrls || !a?.links) return null;
    return { heritrix: a.links, heritrixSpeculative: a.speculativeLinks || [], browserLinks: r.seenUrls.links, browserRequests: r.seenUrls.requests, browserSrcset: r.seenUrls.srcset || [] };
  }).filter(Boolean));

  // URL check: probe a seeded random sample of the speculative Heritrix-only URLs (polite HEAD).
  const { pool: checkPool, ...urlComparisonExport } = urlComparison;
  let urlCheck = null;
  if (!settings.checkUrls) urlCheck = { skipped: 'off in settings' };
  else if (!checkPool.length) urlCheck = { skipped: 'no speculative Heritrix-only URLs' };
  else {
    await progress(rootTabId, 92, 'Checking speculative URLs', `Polite HEAD requests to up to ${URL_CHECK_DEFAULTS.sampleSize} of the ${checkPool.length} URLs only Heritrix's heuristics found.`);
    const budget = AbortSignal.any([signal, AbortSignal.timeout(URL_CHECK_DEFAULTS.budgetMs)]);
    try {
      urlCheck = await runUrlCheck(checkPool, {
        seed: rootUrl.origin,
        sampleSize: URL_CHECK_DEFAULTS.sampleSize,
        allowed: u => !settings.respectRobots || robotsAllows(sitemap.robotsRules, u),
        probe: u => fetcher.probe(u, { timeoutMs: URL_CHECK_DEFAULTS.timeoutMs, signal: budget }),
        signal: budget,
      });
      if (budget.aborted && !signal.aborted) urlCheck.budgetExceeded = true;
    } catch (err) {
      if (signal.aborted) throw err;
      urlCheck = { skipped: `failed (${String(err?.message || err).slice(0, 80)})` };
    }
  }
  const report = buildReport(final, agg, ai, sitemap, samples, earlyExit, languageProfile, settings.testScope, {
    urlComparison: urlComparisonLines(urlComparison, urlCheck), consent: summarizeConsent(results, settings.consentMode), rawBasis: summarizeRawBasis(rawByUrl) });

  const finalSamples = samples.map(s => {
    const r = results.get(canonicalKey(s.url));
    const raw = rawByUrl.get(canonicalKey(s.url));
    let status = r ? statusFor(r.rendered, r.evidence) : null;
    if (!status && raw && !raw.safety?.safe) status = `not-browser-tested:${raw.safety?.reason || 'unknown'}`;
    if (!status) status = earlyExit ? 'skipped-after-early-exit' : 'not-browser-tested';
    return { url: s.url, role: s.role, status, codes: (r?.evidence?.codes || []).map(c => c.code) };
  });

  const bundle = {
    version: VERSION,
    generatedAt: new Date().toISOString(),
    site: { url: originalUrl, origin: rootUrl.origin, host: rootUrl.hostname, rootDomain, subdomainsSeen: samples.some(s => new URL(s.url).hostname !== rootUrl.hostname) },
    settings, languageProfile,
    sitemap: { documents: sitemap.documents, locations: sitemap.locations, robotsSitemaps: sitemap.robotsSitemaps, entries: sitemap.entries.length, pools: sitemap.pools.length, truncatedDocs: sitemap.truncatedDocs, elapsedMs: sitemap.elapsedMs },
    fetcher: fetchSummary,
    samples: samples.map(s => {
      const r = results.get(canonicalKey(s.url));
      const raw = rawByUrl.get(canonicalKey(s.url));
      return { url: s.url, role: s.role, raw: raw?.analysis ? compactRaw(raw.analysis) : { ok: false, status: raw?.status || 0, error: raw?.error || '', safety: raw?.safety }, rendered: compactRendered(r?.rendered), evidence: r?.evidence || null };
    }),
    sitemapPatterns: patternSummary(samples),
    urlComparison: urlComparisonExport,
    urlCheck,
    ajaxHosts: mergeAjaxHosts([...results.values()].map(r => r.rendered?.ajaxHosts || []), {
      rootDomain,
      // Only a "/" seed implies a whole host (+ subdomains) in Heritrix; page-only runs seed a path.
      rootSeedHosts: settings.testScope === 'page' ? [] : [rootUrl.hostname],
    }),
    aggregate: agg, ai, decision: final, earlyExit, warnings, report,
  };
  await store.setExport(rootTabId, bundle).catch(err => console.warn('export store failed', err));

  await store.replace(rootTabId, {
    ...(await store.get(rootTabId)),
    running: false, done: true, progress: 100, phase: 'Analysis complete',
    detail: earlyExit
      ? `${final.decision} selected after decisive evidence on ${shortUrl(earlyExit.sampleUrl)}.`
      : pageOnly
        ? `${final.decision} selected for this page only (${agg.comparableSamples ? 'compared' : 'not comparable'}).`
        : `${final.decision} selected. ${agg.comparableSamples} comparable samples, ${sitemap.locations.length} sitemap locations, ${sitemap.entries.length} sitemap URLs.`,
    decision: final.decision, confidence: final.confidence, decisionPath: final.path, report, samples: finalSamples, ai, warnings, earlyExit,
    urlCheckList: urlCheckListing(urlCheck), urlCheckCount: urlCheck?.results?.length || 0,
    scores: { browsertrix: agg.browsertrixScore, heritrix: agg.heritrixScore, strongCodes: agg.strongCodes, strongSamples: agg.strongSamples, comparable: agg.comparableSamples },
    exportAvailable: true, finishedAt: Date.now(),
  });
  await store.remember(rootUrl.hostname, { decision: final.decision, confidence: final.confidence, at: Date.now(), version: VERSION, testScope: settings.testScope, url: originalUrl });
  await setVisualState(rootTabId, final.decision === 'Browsertrix' ? 'browsertrix' : 'heritrix', final.decision === 'Browsertrix' ? 'B' : 'H');
}

function compactRendered(r) {
  if (!r) return null;
  const { seenUrls, ...rest } = r;
  return seenUrls ? { ...rest, autofetch: (rest.autofetch || []).slice(0, 200), seenUrlCounts: { links: seenUrls.links.length, requests: seenUrls.requests.length, srcset: (seenUrls.srcset || []).length } } : rest;
}

function compactRaw(a) {
  return { ...a, links: (a.links || []).slice(0, 3000), speculativeLinks: (a.speculativeLinks || []).slice(0, 1000), staticUrls: (a.staticUrls || []).slice(0, 3000) };
}

function statusFor(rendered, evidence) {
  if (!rendered) return null;
  if (rendered.error) return 'browser-test-failed';
  if (rendered.limited) return `browser-test-limited:${rendered.limited}`;
  const parts = ['browser-tested'];
  if (evidence?.limits?.length) parts.push(evidence.limits.join(','));
  if (rendered.securityEvents?.length) parts.push(`${rendered.securityEvents.length} safeguard event(s)`);
  return parts.join(' · ');
}

function updateSampleStatus(tabId, url, status) {
  store.get(tabId).then(st => {
    const samples = (st?.samples || []).map(s => (canonicalKey(s.url) === canonicalKey(url) ? { ...s, status } : s));
    store.patch(tabId, { samples });
  }).catch(() => {});
}

async function failAnalysis(tabId, err) {
  const cancelled = err instanceof AbortedError || err?.name === 'AbortError' || err?.name === 'TimeoutError';
  const timedOut = err?.name === 'TimeoutError' || /signal timed out/i.test(String(err?.message || ''));
  const message = timedOut ? 'The analysis exceeded the maximum run time and was stopped.' : String(err?.message || err);
  if (!cancelled) console.error(err);
  await store.patch(tabId, {
    running: false, done: true, progress: 100, phase: cancelled ? 'Analysis stopped' : 'Analysis failed', detail: message,
    decision: null, cancelled, report: [cancelled ? 'The analysis was stopped.' : 'The analysis could not be completed.', message.slice(0, 220)],
  }, { immediate: true }).catch(() => {});
  await setVisualState(tabId, cancelled ? 'idle' : 'error', cancelled ? '' : '!').catch(() => {});
}

async function setVisualState(tabId, state, badgeText = '') {
  await Promise.all([
    chrome.action.setIcon({ tabId, path: ICONS[state] }),
    chrome.action.setBadgeText({ tabId, text: String(badgeText).slice(0, 4) }),
    chrome.action.setBadgeBackgroundColor({ tabId, color: state === 'running' ? '#F59E0B' : state === 'error' ? '#DC2626' : state === 'idle' ? '#6B7280' : '#16A34A' }),
  ]).catch(() => {});
}

// ---------------------------------------------------------------------------------------------
// Raw HTTP
// ---------------------------------------------------------------------------------------------

/**
 * @param {object} heritrixConfig  overrides of HERITRIX_DEFAULTS; meta-robots nofollow follows the
 *   extension's robots setting (Heritrix's own default policy "obey" honours it; legal deposit usually not)
 */
async function analyzeRawSample(url, rootDomain, fetcher, signal, heritrixConfig = {}) {
  if (isUnsafeBrowserSampleUrl(url)) return { ok: false, status: 0, safety: { safe: false, reason: 'file-like-url' } };
  const res = await fetcher.fetchText(url, { maxBytes: CONFIG.MAX_HTML_BYTES, accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.1', timeoutMs: 15_000, signal });
  const finalUrl = res.finalUrl || url;
  const ct = String(res.contentType || '').toLowerCase();
  const safety = (() => {
    if (isUnsafeBrowserSampleUrl(finalUrl)) return { safe: false, reason: 'redirected-to-file' };
    if (!sameRegisteredDomain(finalUrl, rootDomain)) return { safe: false, reason: 'redirect-outside-domain' };
    if (/\battachment\b/i.test(res.contentDisposition || '')) return { safe: false, reason: 'content-disposition-attachment' };
    if (/(?:application\/(?:pdf|msword|vnd\.|octet-stream|zip|x-7z|x-rar|x-tar)|image\/|audio\/|video\/|font\/)/.test(ct)) return { safe: false, reason: 'non-html-mime' };
    const sniffed = /^\s*(?:<!doctype\s+html|<html|<head|<body)|<(?:html|head|body|main|article|div)[\s>]/i.test(String(res.text || '').slice(0, 12000));
    if (!(/text\/html|application\/xhtml\+xml/.test(ct) || ((!ct || ct.startsWith('text/plain')) && sniffed))) return { safe: false, reason: 'html-not-confirmed' };
    // Non-2xx pages are still rendered when they look like challenge pages (WAF evidence), otherwise skipped.
    if (!res.ok && ![403, 429, 503].includes(res.status)) return { safe: false, reason: `http-${res.status}` };
    return { safe: true, reason: 'confirmed-html' };
  })();
  let analysis = null;
  if (safety.safe || [403, 429, 503].includes(res.status)) {
    // Heritrix fetches a redirect target as its own CrawlURI, so the final URL is the document URI.
    const parsed = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'ANALYZE_HTML', html: res.text, url: finalUrl, status: res.status, heritrixConfig });
    if (!parsed?.ok) throw new Error(`HTML analysis failed: ${parsed?.error || 'no response from parser'}`);
    const { heritrix, domAnchors, ...a } = parsed.result;
    const basis = buildRawBasis(heritrix, { rootDomain, documentUrl: finalUrl, domAnchors });
    analysis = {
      ...a,
      links: basis.links,                       // same-site URLs Heritrix would discover (any hop)
      speculativeLinks: basis.speculativeLinks, // of which found only heuristically (checked by the URL check)
      internalLinkCount: basis.navigableCount,  // page-like ones, comparable with rendered <a href>
      heritrix: basis.summary,
      heritrixOutlinks: basis.records,
      ok: res.ok, status: res.status, finalUrl, truncated: !!res.truncated, charset: res.charset, throttled: !!res.throttled,
    };
  }
  return { ok: res.ok, status: res.status, finalUrl, safety, analysis };
}

// ---------------------------------------------------------------------------------------------
// Isolated test session
// ---------------------------------------------------------------------------------------------

async function createTestSession(rootTabId, settings, workers) {
  const existing = await chrome.windows.getAll();
  if (existing.some(w => w.incognito)) throw new Error('An Incognito window was opened during the analysis. Close all Incognito windows and run it again.');
  session = { rootTabId, windowIds: new Set(), workerWindows: [], tabIds: new Set(), knownTabs: new Set(), events: [], startedAt: Date.now(), creatingWindows: 0, creatingTabs: 0 };
  for (let i = 0; i < workers; i++) {
    session.creatingWindows++;
    try {
      const opts = { url: 'about:blank', incognito: true, focused: false, type: 'normal' };
      if (settings.windowMode === 'minimized') opts.state = 'minimized';
      else Object.assign(opts, { state: 'normal', width: CONFIG.WINDOW.width, height: CONFIG.WINDOW.height, left: 40 + i * 30, top: 40 + i * 30 });
      const win = await chrome.windows.create(opts);
      session.windowIds.add(win.id);
      for (const t of win.tabs || []) session.knownTabs.add(t.id);
      session.workerWindows.push(win.id);
    } finally { session.creatingWindows--; }
  }
  await persistSession();
  // Give focus back to the user's window (windows.create can steal focus on some platforms).
  const root = await chrome.tabs.get(rootTabId).catch(() => null);
  if (root?.windowId != null) chrome.windows.update(root.windowId, { focused: true }).catch(() => {});
}

async function destroyTestSession() {
  if (!session) return;
  const s = session;
  for (const id of s.windowIds) await chrome.windows.remove(id).catch(() => {});
  await detachAll().catch(() => {});
  const rules = await chrome.declarativeNetRequest.getSessionRules().catch(() => []);
  if (rules.length) await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: rules.map(r => r.id) }).catch(() => {});
  session = null;
  await persistSession();
}

/** Blocks off-scope top-level navigations in one test tab before the request is sent. */
async function addNavigationRule(tabId, rootDomain) {
  const id = nextRuleId++;
  if (nextRuleId > 900_000) nextRuleId = 5000;
  await chrome.declarativeNetRequest.updateSessionRules({
    addRules: [{ id, priority: 1, action: { type: 'block' }, condition: { tabIds: [tabId], resourceTypes: ['main_frame'], excludedRequestDomains: [rootDomain] } }],
  });
  return id;
}

async function waitForTabComplete(tabId, timeoutMs, signal) {
  const t = await chrome.tabs.get(tabId).catch(() => null);
  if (t?.status === 'complete' && t.url && t.url !== 'about:blank') return;
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { cleanup(); reject(new Error('Render timeout')); }, timeoutMs);
    const onAbort = () => { cleanup(); reject(new AbortedError()); };
    const listener = (id, info, tab) => { if (id === tabId && info.status === 'complete' && tab.url !== 'about:blank') { cleanup(); resolve(); } };
    function cleanup() { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener); signal?.removeEventListener('abort', onAbort); }
    chrome.tabs.onUpdated.addListener(listener);
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

async function injectProbe(tabId, allFrames = false) {
  await chrome.scripting.executeScript({ target: { tabId, allFrames }, world: 'ISOLATED', files: ['probe/injected.js'] });
}

async function callProbe(tabId, name, args = [], { frameIds, timeoutMs = CONFIG.PROBE_CALL_TIMEOUT_MS } = {}) {
  const run = () => chrome.scripting.executeScript({
    target: frameIds ? { tabId, frameIds } : { tabId },
    world: 'ISOLATED',
    func: (n, a) => (globalThis.__ccProbe ? globalThis.__ccProbe[n](...a) : { __missing: true }),
    args: [name, args],
  });
  let res = await withTimeout(run(), timeoutMs, `probe ${name}`);
  if (!frameIds && res?.[0]?.result?.__missing) {
    await injectProbe(tabId);
    res = await withTimeout(run(), timeoutMs, `probe ${name}`);
  }
  return frameIds ? res : res?.[0]?.result;
}

async function probeCurrentTab(tabId) {
  await injectProbe(tabId);
  return callProbe(tabId, 'snapshot', [{ withTextSample: true }], { timeoutMs: 10_000 });
}

function sameSiteDom(dom, rootDomain) {
  return { ...dom, newLinks: (dom?.newLinks || []).filter(u => sameRegisteredDomain(u, rootDomain)) };
}

async function renderSample(sample, raw, windowId, rootDomain, settings, signal) {
  session.creatingTabs++;
  let tab;
  try { tab = await chrome.tabs.create({ windowId, url: 'about:blank', active: true }); }
  finally { session.creatingTabs--; }
  session.tabIds.add(tab.id);
  await persistSession();
  let ruleId = null;
  const cdp = new CdpSession(tab.id, { rootDomain });
  const tabEvents = () => [...cdp.events, ...session.events.filter(e => e.tabId === tab.id)];
  try {
    ruleId = await addNavigationRule(tab.id, rootDomain);
    await cdp.attach();
    const navStart = Date.now();
    await chrome.tabs.update(tab.id, { url: sample.url });
    const limits = [];
    await waitForTabComplete(tab.id, CONFIG.TAB_TIMEOUT_MS, signal).catch(err => { if (err instanceof AbortedError) throw err; limits.push('load-timeout'); });
    const finalTab = await chrome.tabs.get(tab.id);
    if (!finalTab.url || !/^https?:/i.test(finalTab.url) || !sameRegisteredDomain(finalTab.url, rootDomain)) {
      return { limited: 'navigated-out-of-scope', finalUrl: finalTab.url || '', securityEvents: tabEvents() };
    }
    if (cdp.detachedReason) return { limited: `debugger-detached:${cdp.detachedReason}`, securityEvents: tabEvents() };
    await injectProbe(tab.id);

    let consent = null;
    if (settings.consentMode !== 'off') {
      const navBefore = cdp.mainNavigations;
      cdp.guardMode = 'consent';
      try { consent = await handleConsent(tab.id, settings.consentMode, signal); } finally { cdp.guardMode = 'strict'; }
      if (cdp.mainNavigations > navBefore) {
        // Some banners reload the page after a choice; measure the reloaded page.
        consent.reloaded = true;
        await waitForTabComplete(tab.id, CONFIG.TAB_TIMEOUT_MS, signal).catch(err => { if (err instanceof AbortedError) throw err; limits.push('load-timeout-after-consent'); });
        const t = await chrome.tabs.get(tab.id);
        if (!t.url || !sameRegisteredDomain(t.url, rootDomain)) return { limited: 'navigated-out-of-scope', finalUrl: t.url || '', securityEvents: tabEvents() };
        await injectProbe(tab.id);
      }
    }
    await sleep(CONFIG.SETTLE_MS, signal);
    const loadEnd = Date.now();

    // Idle control window: what the page does on its own (carousels, consent banners, ads, hydration).
    await callProbe(tab.id, 'startPhase');
    const b0 = Date.now();
    await sleep(CONFIG.IDLE_BASELINE_MS, signal);
    const bDom = await callProbe(tab.id, 'endPhase');
    const b1 = Date.now();
    const baseline = { durationMs: b1 - b0, dom: sameSiteDom(bDom, rootDomain), net: summarizeWindow(cdp.log(), b0, b1, rootDomain) };

    const loadSnap = await callProbe(tab.id, 'snapshot', [{}]);
    const load = {
      ...loadSnap,
      links: (loadSnap?.links || []).filter(u => sameRegisteredDomain(u, rootDomain)),
      shadowLinks: (loadSnap?.shadowLinks || []).filter(u => sameRegisteredDomain(u, rootDomain)),
    };
    load.linkCount = load.links.length;
    // Browsertrix autofetch (srcset/data-src) as seen right after load; collected again at the end.
    const autofetchAtLoad = (await callProbe(tab.id, 'autofetchUrls').catch(() => [])) || [];
    const preInteraction = Date.now();

    // Scroll.
    await callProbe(tab.id, 'startPhase');
    const s0 = Date.now();
    const scrollInfo = await callProbe(tab.id, 'scroll', [CONFIG.SCROLL], { timeoutMs: CONFIG.SCROLL.maxMs + 10_000 });
    const sDom = await callProbe(tab.id, 'endPhase');
    const s1 = Date.now();
    const scroll = { durationMs: s1 - s0, info: scrollInfo, dom: sameSiteDom(sDom, rootDomain), net: summarizeWindow(cdp.log(), s0, s1, rootDomain) };
    throwIfAborted(signal);

    // Controlled clicks (non-href, non-dangerous; the CDP guard blocks non-GET requests).
    const clicks = [];
    const controls = (await callProbe(tab.id, 'findControls', [CONFIG.CLICK_TEST_MAX_CANDIDATES]).catch(() => [])) || [];
    for (const ctl of controls) {
      throwIfAborted(signal);
      const routeBefore = cdp.routeEvents, navBefore = cdp.mainNavigations;
      try {
        await callProbe(tab.id, 'startPhase');
        const c0 = Date.now();
        await callProbe(tab.id, 'click', [ctl.i, CONFIG.CLICK_SETTLE_MS]);
        const cDom = await callProbe(tab.id, 'endPhase');
        const c1 = Date.now();
        const net = summarizeWindow(cdp.log(), c0, c1, rootDomain);
        clicks.push({ type: ctl.type, label: ctl.label, selector: ctl.selector, durationMs: c1 - c0, dom: sameSiteDom(cDom, rootDomain), net, dataLoaded: net.data > 0, routeChanged: cdp.routeEvents > routeBefore });
      } catch (err) {
        clicks.push({ type: ctl.type, label: ctl.label, selector: ctl.selector, error: String(err?.message || err) });
      }
      if (cdp.mainNavigations > navBefore) { limits.push('click-caused-navigation'); break; }
    }

    // Menus: open each trigger and up to N newly revealed (non-link) submenu items, each as its own
    // measured phase. Menu phases count new content inside fixed/sticky overlays (off-canvas drawers),
    // still excluding consent and ad containers.
    const menus = [];
    try {
      const menuStart = Date.now();
      const triggers = (await callProbe(tab.id, 'findMenuTriggers', [CONFIG.MENU.maxTriggers]).catch(() => [])) || [];
      const menuPhase = async (fn, args, meta) => {
        await callProbe(tab.id, 'startPhase', [{ menu: true }]);
        const t0 = Date.now();
        const res = await callProbe(tab.id, fn, args);
        const mDom = await callProbe(tab.id, 'endPhase');
        const t1 = Date.now();
        const mNet = summarizeWindow(cdp.log(), t0, t1, rootDomain);
        menus.push({ ...meta, durationMs: t1 - t0, dom: sameSiteDom(mDom, rootDomain), net: mNet, dataLoaded: mNet.data > 0 });
        return res;
      };
      menuLoop: for (const trig of triggers) {
        throwIfAborted(signal);
        if (Date.now() - menuStart > CONFIG.MENU.budgetMs) { limits.push('menu-budget-exhausted'); break; }
        const navBefore = cdp.mainNavigations;
        try {
          const opened = await menuPhase('openMenu', [trig.i, CONFIG.MENU.settleMs], { level: 'trigger', type: trig.type, label: trig.label, selector: trig.selector });
          if (cdp.mainNavigations > navBefore) { limits.push('menu-caused-navigation'); break; }
          for (const item of (opened?.items || []).slice(0, CONFIG.MENU.maxItemsPerTrigger)) {
            if (Date.now() - menuStart > CONFIG.MENU.budgetMs) break;
            await menuPhase('clickMenuItem', [item.i, CONFIG.MENU.settleMs], { level: 'item', type: trig.type, label: item.label, selector: item.selector, parent: trig.selector });
            if (cdp.mainNavigations > navBefore) { limits.push('menu-caused-navigation'); break menuLoop; }
          }
        } catch (err) {
          if (err instanceof AbortedError) throw err;
          menus.push({ level: 'trigger', type: trig.type, label: trig.label, selector: trig.selector, error: String(err?.message || err) });
        }
        await callProbe(tab.id, 'closeMenu', [trig.i]).catch(() => {});
      }
    } catch (err) {
      if (err instanceof AbortedError) throw err;
      limits.push('menu-probe-failed');
    }

    // Media playback.
    let media = null;
    try {
      const before = summarizeWindow(cdp.log(), navStart, Date.now(), rootDomain);
      await callProbe(tab.id, 'startPhase');
      const m0 = Date.now();
      const mres = await callProbe(tab.id, 'media', [CONFIG.MEDIA]);
      await callProbe(tab.id, 'endPhase');
      const m1 = Date.now();
      media = { ...mres, durationMs: m1 - m0, before: { manifestCount: before.manifestCount, segmentCount: before.segmentCount }, net: summarizeWindow(cdp.log(), m0, m1, rootDomain) };
    } catch (err) { limits.push('media-probe-failed'); }

    // Browsertrix autofetch also reacts to DOM changes: union of the URLs at load and at the end.
    const autofetchAtEnd = (await callProbe(tab.id, 'autofetchUrls').catch(() => [])) || [];
    const autofetch = [...new Set([...autofetchAtLoad, ...autofetchAtEnd])].filter(u => sameRegisteredDomain(u, rootDomain)).slice(0, 3000);

    // Page-flipper / viewer probe across all frames.
    let viewer = { detected: false, tested: 0, strongFrames: [] };
    try { viewer = await probeViewers(tab.id, cdp, rootDomain); } catch (err) { limits.push('viewer-probe-limited'); }

    const log = cdp.log().filter(e => e.t >= navStart);
    const renderedResult = {
      finalUrl: finalTab.url,
      consent,
      load,
      baseline,
      scroll,
      clicks,
      menus,
      media,
      viewer,
      networkAll: summarizeWindow(log, navStart, Infinity, rootDomain),
      loadNet: summarizeWindow(log, navStart, loadEnd, rootDomain),
      runtimeOnly: runtimeOnlyResources(log.filter(e => e.t <= preInteraction), raw?.analysis?.staticUrls || [], rootDomain),
      polling: detectPolling(log, rootDomain),
      ajaxHosts: collectAjaxHosts(log),
      autofetch,
      spa: { routeEvents: cdp.routeEvents, mainNavigations: cdp.mainNavigations },
      limitsObserved: limits,
      securityEvents: tabEvents(),
      networkLog: log.slice(0, 500).map(e => ({ url: e.url, method: e.method, type: e.type, t: e.t - navStart, status: e.status, mime: e.mime, bytes: e.bytes, blocked: !!e.blocked })),
    };
    // Unique same-site URLs the browser found (DOM links of all phases + requested URLs, full log).
    renderedResult.seenUrls = browserUrlsOf({ ...renderedResult, requestLog: log }, rootDomain);
    return renderedResult;
  } catch (err) {
    if (err instanceof AbortedError) throw err;
    return { error: String(err?.message || err), securityEvents: tabEvents() };
  } finally {
    await cdp.detach();
    if (ruleId != null) await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] }).catch(() => {});
    session?.tabIds.delete(tab.id);
    await chrome.tabs.remove(tab.id).catch(() => {});
    await persistSession();
  }
}

async function probeViewers(tabId, cdp, rootDomain) {
  await injectProbe(tabId, true).catch(() => {});
  const found = await withTimeout(chrome.scripting.executeScript({
    target: { tabId, allFrames: true }, world: 'ISOLATED',
    func: () => (globalThis.__ccProbe ? globalThis.__ccProbe.viewerFind() : null),
  }), CONFIG.PROBE_CALL_TIMEOUT_MS, 'viewer find');
  const frames = found.filter(f => f.result).map(f => ({ frameId: f.frameId, ...f.result }));
  const candidates = frames.filter(f => f.hasCandidate).slice(0, CONFIG.VIEWER_MAX_FRAME_PROBES);
  const strongFrames = [];
  for (const f of candidates) {
    const v0 = Date.now();
    const res = await callProbe(tabId, 'viewerClick', [CONFIG.VIEWER_SETTLE_MS], { frameIds: [f.frameId] }).catch(() => null);
    const v1 = Date.now();
    const r = res?.[0]?.result;
    if (!r?.tested) continue;
    const net = summarizeWindow(cdp.log(), v0, v1, rootDomain);
    const loadedPageAssets = net.pageAssetCount > 0 || (r.newImages || []).length > 0;
    if (r.viewerish && (r.explicitNext || r.structural) && loadedPageAssets && (r.visualChanged || r.routeChanged)) {
      strongFrames.push({ frameId: f.frameId, frameUrl: r.frameUrl, pageAssets: net.pageAssets.slice(0, 6), newImages: r.newImages, canvasChanged: r.canvasChanged, routeChanged: r.routeChanged });
    }
  }
  return { detected: frames.some(f => f.viewerish), tested: candidates.length, strongFrames };
}

// ---------------------------------------------------------------------------------------------
// Offscreen document & Gemini Nano
// ---------------------------------------------------------------------------------------------

async function ensureOffscreen() {
  const url = chrome.runtime.getURL('offscreen.html');
  const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
  if (contexts.length) return;
  if (offscreenCreating) return offscreenCreating;
  offscreenCreating = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['DOM_PARSER'],
    justification: 'Parse fetched raw HTML with DOMParser (without executing it) to compare it with the rendered page.',
  });
  try { await offscreenCreating; } finally { offscreenCreating = null; }
}

async function closeOffscreen() {
  try {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts.length) await chrome.offscreen.closeDocument();
  } catch {}
}

async function aiAvailability() {
  if (globalThis.LanguageModel) return nanoAvailability(globalThis.LanguageModel);
  return 'unavailable-in-service-worker';
}

async function classifyWithNano(payload) {
  // Prefer the service worker when the Prompt API is exposed there; otherwise use the offscreen page.
  if (globalThis.LanguageModel) return runNano(globalThis.LanguageModel, payload, { timeoutMs: CONFIG.AI_TIMEOUT_MS });
  await ensureOffscreen();
  const res = await withTimeout(chrome.runtime.sendMessage({ target: 'offscreen', type: 'AI_CLASSIFY', payload, timeoutMs: CONFIG.AI_TIMEOUT_MS }), CONFIG.AI_TIMEOUT_MS + 5000, 'Gemini Nano');
  return res || { status: 'no-response' };
}

// ---------------------------------------------------------------------------------------------
// Report
// ---------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------
// Consent banners (probe/consent.js runs in every frame; see that file for the method)
// ---------------------------------------------------------------------------------------------

async function consentInAllFrames(tabId, fn, args = []) {
  await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: 'ISOLATED', files: ['probe/consent.js'] }).catch(() => {});
  const res = await withTimeout(chrome.scripting.executeScript({
    target: { tabId, allFrames: true }, world: 'ISOLATED',
    func: (name, a) => (globalThis.__ccConsent ? globalThis.__ccConsent[name](...a) : null),
    args: [fn, args],
  }), CONFIG.CONSENT.callTimeoutMs, `consent ${fn}`).catch(() => []);
  return (res || []).map(r => r?.result).filter(Boolean);
}

/**
 * Detect-and-click rounds across all frames (frames that appear late, such as CMP iframes, are
 * picked up because the handler is re-injected each round). "accept" mode ends with the cosmetic
 * fallback when a banner is still visible or the page is still scroll-locked.
 */
async function handleConsent(tabId, mode, signal) {
  const C = CONFIG.CONSENT;
  const started = Date.now();
  const out = { mode, dismissed: false, outcome: 'no-banner', actions: [], cmps: [], rounds: 0, cosmetic: null, stillVisible: false, stillLocked: false };
  const cmps = new Set();
  let seen = false, hint = false;
  while (Date.now() - started < C.maxMs) {
    throwIfAborted(signal);
    out.rounds++;
    const frames = await consentInAllFrames(tabId, 'step', [mode]);
    frames.forEach(f => { (f.cmps || []).forEach(c => cmps.add(c)); hint ||= !!f.hint; });
    const acted = frames.filter(f => f.acted);
    const showing = frames.some(f => f.showing);
    seen ||= showing || acted.length > 0;
    if (acted.length) {
      for (const f of acted) out.actions.push({ ...f.acted, frame: f.frame });
      if (out.actions.length >= C.maxActions) break;
      await sleep(C.afterClickMs, signal);
      continue;
    }
    if (!showing) {
      if (out.actions.length) break;                                   // dismissed
      if (Date.now() - started >= (hint ? C.hintMs : C.quietMs)) break; // nothing (yet) — stop waiting
    } else if (out.actions.length >= C.maxActions) break;
    await sleep(C.pollMs, signal);
  }
  const after = await consentInAllFrames(tabId, 'state');
  out.stillVisible = after.some(f => f.showing);
  out.stillLocked = after.some(f => f.locked);
  if (mode === 'accept' && (out.stillVisible || out.stillLocked)) {
    const hidden = await consentInAllFrames(tabId, 'cosmetic');
    out.cosmetic = { hidden: hidden.reduce((n, f) => n + (f.hidden || 0), 0), unlocked: hidden.some(f => f.unlocked) };
    const final = await consentInAllFrames(tabId, 'state');
    out.stillVisible = final.some(f => f.showing);
    out.stillLocked = final.some(f => f.locked);
  }
  out.cmps = [...cmps];
  const hiddenAny = (out.cosmetic?.hidden || 0) > 0 || out.cosmetic?.unlocked;
  out.dismissed = out.actions.length > 0 || !!hiddenAny;
  out.outcome = out.actions.length
    ? (out.stillVisible ? 'clicked-still-visible' : hiddenAny ? 'clicked+hidden' : 'clicked')
    : hiddenAny ? 'hidden' : out.stillVisible ? 'not-dismissed' : seen ? 'disappeared' : 'no-banner';
  out.elapsedMs = Date.now() - started;
  return out;
}

/** One report line describing the raw side of the comparison (Heritrix 3.14.1 extraction emulation). */
function summarizeRawBasis(rawByUrl) {
  const hs = [...rawByUrl.values()].map(r => r?.analysis?.heritrix).filter(Boolean);
  if (!hs.length) return '';
  const avg = k => Math.round(hs.reduce((n, h) => n + (h[k] || 0), 0) / hs.length);
  const parts = [`${avg('internalNavigable')} page-like of ${avg('internalOutlinks')} same-site URLs per sample (${avg('internalSpeculative')} speculative, from inline JS, meta and form values)`];
  parts.push(`a plain <a href> scan finds ${avg('domAnchorInternal')}`);
  const missed = hs.reduce((n, h) => n + (h.domAnchorsMissedByHeritrix || 0), 0);
  if (missed) parts.push(`${missed} anchor URL(s) across the samples are invisible to Heritrix's parser`);
  const aborted = hs.filter(h => h.abortedByMetaRobots).length;
  if (aborted) parts.push(`meta robots nofollow stopped extraction on ${aborted} sample(s)`);
  return `Raw side = Heritrix 3.14.1 link-extraction emulation (${hs.length} sample${hs.length === 1 ? '' : 's'}): ${parts.join('; ')}.`;
}

const CONSENT_MODE_LABEL = { accept: 'try “accept all”', reject: 'try “reject all”' };

/** One report line summarising consent handling across the browser-tested samples. */
function summarizeConsent(results, mode) {
  if (!mode || mode === 'off') return '';
  const outcomes = [...results.values()].map(r => r.rendered?.consent).filter(Boolean);
  if (!outcomes.length) return `Consent banners (${CONSENT_MODE_LABEL[mode]}): no sample reached the consent step.`;
  const count = o => outcomes.filter(x => x.outcome === o).length;
  const via = [...new Set(outcomes.flatMap(x => x.actions.map(a => a.cmp)))].filter(Boolean);
  const parts = [];
  const clicked = count('clicked') + count('clicked+hidden');
  if (clicked) parts.push(`dismissed on ${clicked}${via.length ? ` via ${via.join(', ')}` : ''}`);
  if (count('clicked+hidden') || count('hidden')) parts.push(`hidden/unlocked on ${count('clicked+hidden') + count('hidden')}`);
  if (count('clicked-still-visible')) parts.push(`still visible after clicking on ${count('clicked-still-visible')}`);
  if (count('not-dismissed')) parts.push(`not dismissed on ${count('not-dismissed')}`);
  if (count('disappeared')) parts.push(`went away without a click on ${count('disappeared')}`);
  if (count('no-banner')) parts.push(`no banner on ${count('no-banner')} (a choice persists across samples in the test session)`);
  return `Consent banners (${CONSENT_MODE_LABEL[mode]}): ${parts.join('; ')}.`;
}

/** Pattern annotations from chooseSamples(), in rank order (empty for page-only runs). */
function patternSummary(samples) {
  return (samples || []).filter(s => s.sitemapPattern)
    .map(s => ({ ...s.sitemapPattern, sampleUrl: s.url, sampleRole: s.role }))
    .sort((a, b) => a.rank - b.rank);
}

function buildReport(final, agg, ai, sitemap, samples, earlyExit, languageProfile, testScope = 'site', extra = {}) {
  const lines = [`Recommendation${testScope === 'page' ? ' for this page' : ''}: ${final.decision} (HF confidence: ${final.confidence}; rule: ${final.path}).`];
  if (earlyExit) lines.push(`• Early exit: ${earlyExit.code} on ${earlyExit.sampleRole} sample.`);
  const side = final.decision;
  for (const e of agg.evidence.filter(x => x.side === side).slice(0, 5)) {
    lines.push(`• ${e.text} [${e.code}; ${e.count}/${agg.comparableSamples} samples]`);
  }
  if (side === 'Heritrix' && !agg.evidence.some(e => e.side === 'Heritrix')) lines.push('• No clear evidence that JavaScript execution is required for discovery or capture.');
  const counter = agg.evidence.filter(x => x.side !== side).slice(0, 2);
  if (counter.length) lines.push(`• Counter-evidence: ${counter.map(e => `${e.code} (${e.count})`).join(', ')}.`);
  if (testScope === 'page') lines.push(`• Basis: single-page test of the active tab URL (${agg.comparableSamples ? 'comparable' : 'not comparable'}); no sitemap discovery; locale ${languageProfile.detectedLocale}.`);
  else lines.push(`• Basis: ${samples.length} samples (${agg.comparableSamples} comparable); ${sitemap.documents.length} sitemap docs, ${sitemap.entries.length} sitemap URLs; locale ${languageProfile.detectedLocale}.`);
  const RANK_LABEL = { 1: 'Most common', 2: 'Second most common' };
  for (const p of patternSummary(samples)) {
    const how = p.covered ? `already covered by the ${p.sampleRole} sample` : `guaranteed sample${p.replacedRole ? ` (took the ${p.replacedRole} slot)` : ''}`;
    lines.push(`• ${RANK_LABEL[p.rank] || `Rank ${p.rank}`} sitemap pattern: ${p.pattern} — ${Math.round(p.share * 100)}% of ${Number(p.total).toLocaleString('en')} eligible sitemap URLs; ${how}.`);
  }
  if (ai?.status === 'ok') lines.push(`• Gemini Nano: ${ai.needsHighFidelity ? 'high-fidelity needed' : 'not needed'} (${ai.confidence})${final.aiVeto ? ' — vetoed the non-decisive Browsertrix path' : ''}.`);
  else lines.push(`• Gemini Nano: ${ai?.status || 'unavailable'}; measurement-based decision used.`);
  if (extra.urlComparison?.length) lines.splice(1, 0, ...extra.urlComparison.map(l => `• ${l}`)); // right under the recommendation
  if (extra.rawBasis) lines.push(`• ${extra.rawBasis}`);
  if (extra.consent) lines.push(`• ${extra.consent}`);
  return lines.slice(0, 17);
}
